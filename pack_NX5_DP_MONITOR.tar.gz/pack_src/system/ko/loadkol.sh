#!/bin/sh
# Useage: ./load3521a [ -r|-i|-a ]
#         -r : rmmod all modules
#         -i : insmod all modules
#    default : rmmod all moules and then insmod them
#

####################Variables Definition##########################

mem_total=128;		# 128M, total mem
mem_start=0x40000000;	# phy mem start

os_mem_size=96;	# 96M, os mem
mmz_start=0x46000000;	# mmz start addr
mmz_size=32M;		# 32M, mmz size

##################################################################
#ulimit -s 2048
report_error()
{
	echo "******* Error: There's something wrong, please check! *****"
	exit 1
}


calc_mmz_info()
{
        mmz_start=`echo "$mem_start $os_mem_size" |
        awk 'BEGIN { temp = 0; }
        {
                temp = $1/1024/1024 + $2;
        }
        END { printf("0x%x00000\n", temp); }'`

        mmz_size=`echo "$mem_total $os_mem_size" |
        awk 'BEGIN { temp = 0; }
        {
                temp = $1 - $2;
        }
        END { printf("%dM\n", temp); }'`
        echo "mmz_start: $mmz_start, mmz_size: $mmz_size"
}




# lcm =
#   0. disabled
#   1. mcu ili9806e
#   2. rgb variable size
#   3. mipi hik 1024x600
# following lcd info:
#   w=1024 h=600 fps=60
insert_ko()
{

	# driver load
	insmod mmz.ko mmz=anonymous,0,$mmz_start,$mmz_size anony=1 || report_error
	./sdio_wifi.sh
	devmem 0x1b040000 32 0x4
	insmod asix.ko
	insmod fy_media.ko
	insmod fybase.ko logbuflen=512
	insmod sys.ko
	#insmod lcm.ko lcm=0
	insmod lcm.ko lcm=3 width=1024 height=600 fps=60
	#insmod lcm.ko lcm=2 width=800 height=480 fps=60 bits="rgb888"
	insmod vou.ko keeplogo=1 restore=1
	insmod jpeg.ko
	insmod vdu.ko
	insmod vppu.ko wkbuf=100
	insmod fyfb.ko lcm_width=1024 lcm_height=600
	#insmod fyfb.ko video="vram0_size:3100,vram1_size:0,vram4_size:0,vram2_size:10,vram3_size:0,vram4_size:0" fbc=0
	insmod acw.ko
	#insmod gt911.ko
	insmod dp_gt911_oncell.ko
	#insmod xr829.ko
	insmod xradio_mac.ko
	insmod xradio_core.ko
	insmod xradio_wlan.ko
	#insmod spidev.ko bufsiz=8192
	#insmod em30918.ko
	#insmod oncell_HRT_CE.ko
	#adc key
	#insmod dpchip-lradc-keys.ko 
	#check voltage cat at /sys/bus/iio/devices/iio:device0/in_voltage0_raw
	#insmod dpchip_saradc.ko
	#insmod 8188eu.ko  rtw_drv_log_level=3
	#devmem 0x34400024 32 0x10002
        #devmem 0x34400028 32 0x10002
	#devmem 0x3440002c 32 0x10002
	#devmem 0x34400030 32 0x10002
	#devmem 0x34400034 32 0x10002
	#devmem 0x34400038 32 0x10002
	#devmem 0x3440003c 32 0x10002
	#devmem 0x3f000018 32 0x2
	#devmem 0x3f00001c 32 0x2
	#devmem 0x3f000020 32 0x2
	#devmem 0x3f000024 32 0x2
	#devmem 0x3f000028 32 0x2
	#devmem 0x3f00002c 32 0x2
	#devmem 0x3f000030 32 0x2
	
	#insmod hgicf.ko
	#insmod hgic_sdio.ko
	#insmod safe.ko
	#cd /system/test
	#./av_test f 
}

remove_ko()
{
	rmmod fyfb
	rmmod vppu
	rmmod vdu
	rmmod jpeg
	rmmod sys
	rmmod fybase
	rmmod fy_media
	rmmod mmz
	#rmmod acw.ko
}

load_usage()
{
	echo "Usage:  ./loadko.sh [-option]"
	echo "options:"
	echo "    -i                       insert modules"
	echo "    -r                       remove modules"
	echo "    -a                       remove modules first, then insert modules"
	echo "    -h                       help information"
	echo -e "for example: ./loadko.sh -i\n"
}



######################parse arg###################################
b_arg_insmod=0
b_arg_remove=0


for arg in $@
do
	case $arg in
		"-i")
			b_arg_insmod=1;
			;;

		"-r")
			b_arg_remove=1;
			;;
		"-a")
			b_arg_insmod=1;
			b_arg_remove=1;
			;;

		"-h")
			load_usage;
			;;
	esac
done
#######################parse arg end########################
if [ $os_mem_size -ge $mem_total ] ; then
        echo "[err] os_mem[$os_mem_size], over total_mem[$mem_total]"
        exit;
fi

calc_mmz_info;


#######################Action###############################
if [ $b_arg_remove -eq 1 ]; then
	remove_ko;
fi
if [ $b_arg_insmod -eq 1 ]; then
	insert_ko;
fi

