local language = {
    ["测试语言模块"] = "Test language module",
    ["切换语言"] = "change langugae",
    ["测试语言模块1"] = "Test language module1",
    ["测试语言模块2"] = "Test language module2",
    ["设置文本"]     = "set content",
    ["删除 %d 张图片"] = "delete %d pictures",

    ["拼接"] = "splicing",
    ["文本"] = "context",

    ["加载进度线形控件"] = "Loading progress linear control",
    ["美国"] = "U.S.A",

}

return language
