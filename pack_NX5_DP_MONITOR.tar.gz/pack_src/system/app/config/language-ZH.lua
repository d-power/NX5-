--[=[
/******************************************************************************
Copyright(c) 2011-2021 Digital Power Inc.
File name: language-ZH.lua
Author: LiuZhengzhong
Version: 1.0.0
Date: 2020/12/7
Description:
History:
Bug report: liuzhengzhong@d-power.com.cn
******************************************************************************/
]=]

local language =
{
    
}

return language
