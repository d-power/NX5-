--[=[
/******************************************************************************
Copyright(c) 2011-2021 Digital Power Inc.
File name: shared1.lua
Author: liuzhengzhong
Version: 1.0.0
Date: 2021/1/3
Description:
History:
Bug report: liuzhengzhong@d-power.com.cn
******************************************************************************/
]=]

local shared =
{
    shared_color = function(obj)
        return {
            {
                type = "text",
                position = {x = obj.x, y = obj.y},
                attr = {
                    w = 128, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT,
                    c = 0xffffffff, content = obj.content, },
                name = obj.name
            },
            {
                type = "btn",
                position = {align = utils_align.OUT_BOTTOM_LEFT, alignx = 340, aligny = 20, ref = obj.name},
                attr = {res_rel = "setting/add_rel.png", res_clk = "setting/add_pre.png",},
                action = {bind = {up = "color_change"}},
                name = obj.name .. "^add"
            },
            {
                type = "btn",
                position = {align = utils_align.OUT_BOTTOM_LEFT, alignx = -4, aligny = 20, ref = obj.name},
                attr = {res_rel = "setting/reduce_rel.png", res_clk = "setting/reduce_rel.png",},
                action = {bind = {up = "color_change"}},
                name = obj.name .. "^reduce"
            },
            {
                type = "slider",
                position = {align = utils_align.OUT_RIGHT_MID, alignx = 30, ref = obj.name .. "^reduce"},
                attr = {w = obj.w or 240, h = 16, c = 0xff1d1d1d, c_act = 0xffffffff, c_knob = 0xFFFFFFFF, round = true,
                        spin = false, min = 0, max = 100, value = "{{"..obj.name.."_value}}", mode = utils_slider.MODE_NORMAL},
                action = {bind = {change = "color_change"}},
                name = obj.name .. "^slider"
            },
            {
                type = "text",
                position = {align = utils_align.OUT_BOTTOM_RIGHT, aligny = 10, ref = obj.name .. "^slider"},
                attr = {
                    w = 320, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_RIGHT,
                    c = 0xffffffff, content = "100", }
            },
            {
                type = "text",
                position = {align = utils_align.OUT_BOTTOM_LEFT, aligny = 10, ref = obj.name .. "^slider"},
                attr = {
                    w = 320, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT,
                    c = 0xffffffff, content = "0", }
            },
        }
    end,

    shared_delay = function(obj)
        return {
            {
                type = "btn",
                position = {x = obj.x, y = obj.y},
                attr = {res_rel = "setting/reduce_rel.png", res_clk = "setting/reduce_rel.png",},
                action = {bind = {up = "delay_change"}},
                name = obj.name .. "^reduce"
            },
            {
                type = "slider",
                position = {align = utils_align.OUT_RIGHT_MID, alignx = 30, ref = obj.name .. "^reduce"},
                attr = {w = obj.w or 240, h = 16, c = 0xff1d1d1d, c_act = 0xffffffff, c_knob = 0x00FFFFFF, round = true,
                        spin = false, min = tonumber(obj.min) or 0, max = tonumber(obj.max) or 100, value = "{{"..obj.name.."_delay}}", mode = utils_slider.MODE_NORMAL},
                action = {bind = {change = "delay_change"}},
                name = obj.name .. "^slider"
            },
            {
                type = "btn",
                position = {align = utils_align.OUT_RIGHT_MID, alignx = 30, ref = obj.name .. "^slider"},
                attr = {res_rel = "setting/add_rel.png", res_clk = "setting/add_pre.png",},
                action = {bind = {up = "delay_change"}},
                name = obj.name .. "^add"
            },
            {
                type = "text",
                position = {align = utils_align.OUT_BOTTOM_RIGHT, aligny = 10, ref = obj.name .. "^slider"},
                attr = {
                    w = 320, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_RIGHT,
                    c = 0xffffffff, content = obj.max, }
            },
            {
                type = "text",
                position = {align = utils_align.OUT_BOTTOM_LEFT, aligny = 10, ref = obj.name .. "^slider"},
                attr = {
                    w = 320, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT,
                    c = 0xffffffff, content = obj.min, }
            },
            {
                type = "text",
                position = {align = utils_align.OUT_LEFT_MID, alignx = - 32, ref  = obj.name .. "^reduce"},
                attr = {
                    w = 320, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_RIGHT,
                    c = 0xffffffff, content = obj.content, }
            },
            {
                type = "img",
                position = {align = utils_align.IN_LEFT_MID, alignx = "{{"..obj.name .."_x}}", ref  = obj.name .. "^slider"},
                attr = {res = "setting/round.png"},
                name = obj.name .. "_round"
            },
            {
                type = "text",
                position = {align = utils_align.CENTER,},
                attr = {
                    w = 40, h = 12, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = obj.name .. "_round",
                    c = 0xff000000, content = "{{"..obj.name .."_txt}}", }
            },
        }
    end,

}

return shared
