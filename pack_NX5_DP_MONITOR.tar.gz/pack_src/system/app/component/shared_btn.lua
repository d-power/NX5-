local shared_btn = {
    ctrl_btn = function(obj)
        return {
            {
                type = "btn",
                position = {x = obj.x, y = obj.y},
                attr = {res_rel = obj.rel, 
                        res_chk_rel = obj.chk_rel, 
                        chk = obj.chk_rel ~= nil, state = obj.state,
                        parent = obj.parent, hidden = obj.hidden},
                action = {bind = {up = obj.act_up}},
                name = obj.name,
                user_data = obj.user_data
            },
            {
                type = "text",
                position = {align = utils_align.CENTER},
                attr = {
                    w = 128, h = obj.txt_height or 16, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = obj.name,
                    c = obj.txt_color or 0xffffffff, content = obj.content, }
            },
        }
    end,

    home_shared_moudle = function(obj)
        return {
            {
                type = "img",
                position = {x = obj.x, y = 12},
                attr = {res = "home/moudle_bar.png", parent = obj.parent},
                name = obj.name
            },
            {
                type = "img",
                position = {align = utils_align.IN_TOP_MID, aligny = 60},
                attr = {res = "home/line.png", parent = obj.name}
            },
            {
                type = "text",
                position = {align = utils_align.IN_TOP_MID, aligny = 16},
                attr ={ w = 240, h = 22, align = utils_text.ALIGN_CENTER, mode = utils_text.MODE_CROP,
                        c = 0xffffffff, content = obj.text, parent = obj.name}
            },
            {
                type = "img",
                position = {align = utils_align.IN_BOTTOM_MID, aligny = -60},
                attr = {res = "home/line.png", parent = obj.name}
            },
            {
                type = "blank",
                position = {align = utils_align.IN_BOTTOM_MID},
                attr = {w = 237, h = 60, c = 0x00000000, parent = obj.name},
                action = {bind = {up = "goto_more"}},
                next_page = obj.next_page
            },
            {
                type = "text",
                position = {align = utils_align.IN_BOTTOM_MID, aligny = -20},
                attr ={ w = 240, h = 18, align = utils_text.ALIGN_CENTER, mode = utils_text.MODE_CROP,
                        c = 0xffffffff, content = obj.content or "更多 >", parent = obj.name}
            },
        }
    end,

    set_shart_btn = function(obj)
        return {
            {
                type = "btn",
                position = {x = obj.x, y = obj.y},
                attr = {res_rel = "setting/set_bg.png", parent = obj.parent},
                action  = {bind = {up = "goto_next_page"}},
                name = obj.next_page
            },
            {
                type = "img",
                position = {align = utils_align.IN_TOP_MID, aligny = 27},
                attr = {res = "setting/img_bg.png", parent = obj.next_page},
                name = obj.next_page .. "img_bg"
            },
            {
                type = "img",
                position = {align = utils_align.CENTER, ref = obj.next_page .. "img_bg"},
                attr = {res = obj.img, parent = obj.next_page},
            },
            {
                type = "text",
                position = {align = utils_align.OUT_BOTTOM_MID, aligny = 15, ref = obj.next_page .. "img_bg"},
                attr ={ w = 1024, h = 20, c = 0xffffffff, align = utils_text.ALIGN_CENTER, mode = utils_text.MODE_CROP,
                        content = obj.text, parent = obj.next_page },
            },
        }
    end
}

return shared_btn
