--[=[
/******************************************************************************
Copyright(c) 2011-2021 Digital Power Inc.
File name: shared1.lua
Author: liuzhengzhong
Version: 1.0.0
Date: 2021/1/3
Description:
History:
Bug report: liuzhengzhong@d-power.com.cn
******************************************************************************/
]=]

local shared =
{
    door_module = function(obj)
        return {
            {
                type = "img",
                position = {x = obj.x, y = obj.y},
                attr = {res = "door_bg.png", parent = obj.parent},
                name = obj.name
            },
            {
                type = "text",
                position = {x = 30, y = 32},
                attr ={ w = 280, h = 24, c = 0xFFFFFFFF, align = utils_text.ALIGN_LEFT, mode = utils_text.MODE_CROP,
                        content = obj.community, parent = obj.name },
            },
            {
                type = "text",
                position = {x = 30, y = 74},
                attr ={ w = 280, h = 20, c = 0xFFFFFFFF, align = utils_text.ALIGN_LEFT, mode = utils_text.MODE_CROP,
                        content = obj.addr, parent = obj.name },
            },
            {
                type = "btn",
                position = {align = utils_align.IN_RIGHT_MID, alignx = -20},
                attr = {res_rel = obj.open_state_img, parent = obj.name},
                name = obj.name .. "state",
                action = {bind = {up = "open_door_act"}},
                user_data = obj.user_data
            },
            {
                type = "text",
                position = {align = utils_align.CENTER},
                attr ={ w = 120, h = 20, c = 0xFFFFFFFF, align = utils_text.ALIGN_CENTER, mode = utils_text.MODE_CROP,
                        content = obj.open_content, parent = obj.name .. "state" },
            },
        }
    end
}

return shared
