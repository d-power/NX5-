local _M = {}

function _M.monitor(ip, username, password)
    return cfun.ipc("monitor", ip, username, password)
end

function _M.hangup(...)
    return cfun.ipc("hangup", ...)
end

function _M.photo(...)
    return cfun.ipc("photo", ...)
end


return _M
