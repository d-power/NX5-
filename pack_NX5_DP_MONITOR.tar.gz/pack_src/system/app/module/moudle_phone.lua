local _M = {}

function _M.accpet(session_id)
    return cfun.phone("accept", session_id)
end

function _M.hangup(session_id)
    return cfun.phone("hangup", session_id)
end

function _M.unlock(session_id)
    return cfun.phone("unlock", session_id)
end

function _M.monitor(sn)
    return cfun.phone("monitor", sn)
end

function _M.phone_management()
    return cfun.phone("mange")
end

function _M.phone_talk_volume(session_id, volume)
    return cfun.phone("talk_volume", session_id, volume)
end

function _M.capture(session_id, position)
    return cfun.phone("capture", session_id, position)
end

return _M 
