local _M = {}

function _M.arm(index)
    return decode(cfun.safe("arm", index)) or {}
end

function _M.disarm(index)
    return decode(cfun.safe("disarm", index))
end

function _M.tantou_status()
    return decode(cfun.safe("tantou_status"))
end

function _M.check_is_alarming()
    return decode(cfun.safe("check_is_alarming"))
end

return _M
