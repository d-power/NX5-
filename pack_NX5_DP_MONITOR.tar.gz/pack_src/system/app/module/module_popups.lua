local _M = {}

_M.popups_default_timeout = 3

function _M.show_popups(_content, _timeout, w, h)
    set_data({
        popups_content = _content,
        popups_w = w and w or -1,
        popups_h = h and h or (w and 129 or -1),
    })
    set_data({
        popups_hidden  = false,
        popups_content = _content,
        timeout = (_timeout or _M.popups_default_timeout) * 10,
    })
end

function _M.hidden_popups()
    set_data({popups_hidden = true})
end

function _M.show_popups_with_select(title, contect,timeout)
    set_data({
        popups_with_select_hidden = false,
        popups_title = title or "",
        popups_text = contect or "",
        select_timeout = (timeout or _M.popups_default_timeout) * 10
    })
end

function _M.hidden_popups_with_select()
    set_data({
        popups_with_select_hidden = true,
        popups_title = "",
        popups_text = ""
    })
end

function _M.show_upgrade_schedule(schedule)
    set_data({
        popups_upgrade = false,
        schedule_value = schedule
    })
end

function _M.hidden_upgrade_schedule(schedule)
    set_data({
        popups_upgrade = true,
        schedule_value = 0
    })
end

return _M
