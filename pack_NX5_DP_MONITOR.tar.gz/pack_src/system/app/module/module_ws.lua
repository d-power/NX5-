local _M = {}

function _M.sos()
    cfun.ws("sos")
end

function _M.sync_time()
    cfun.ws("sync_time")
end


function _M.unlock(...)
    cfun.ws("unlock", ...)
end

function _M.get_door_list()
    cfun.ws("get_door_list")
end

function _M.check_upgrade()
    cfun.ws("check_upgrade")
end

function _M.down_upgrade(url)
    cfun.ws("down_upgrade", url)
end

function _M.get_notice()
    cfun.ws("get_notice")
end

return _M
