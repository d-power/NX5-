local LOG_LEVEL_DEBUG = 0
local LOG_LEVEL_INFO = 1
local LOG_LEVEL_WARN = 2
local LOG_LEVEL_ERROR = 3

local log_level = LOG_LEVEL_DEBUG

function split(s, p)
    local result = {}
    string.gsub(
        s,
        "[^" .. p .. "]+",
        function(w)
            table.insert(result, w)
        end
    )
    return result
end

local function get_file()
    local _path = split(debug.getinfo(3).source, "/")
    return _path and _path[#_path] or debug.getinfo(2).source
end

function log_line()
    print(
        "\027[1;36m" ..
            string.format(
                "[LGUI3.0.0   @   %s]\t[%s:%d]\t(debug) ",
                get_file(),
                debug.getinfo(2).name,
                debug.getinfo(2).linedefined
            ) .. "\027[0m", "======================================="
    )
end

function log_debug(...)
    if log_level > LOG_LEVEL_DEBUG then
        return
    end

    print(
        "\027[1;36m" ..
            string.format(
                "[LGUI3.0.0   @   %s]\t[%s:%d]\t(debug) ",
                get_file(),
                debug.getinfo(2).name,
                debug.getinfo(2).linedefined
            ) ..
                "\027[0m",
        ...
    )
end

function log_info(...)
    if log_level > LOG_LEVEL_INFO then
        return
    end

    print(
        "\027[1;32m" ..
            string.format(
                "[LGUI3.0.0   @   %s]\t[%s:%d]\t(info) ",
                get_file(),
                debug.getinfo(2).namewhat,
                debug.getinfo(2).currentline
            ) ..
                "\027[0m",
        ...
    )
end

function log_warn(...)
    if log_level > LOG_LEVEL_WARN then
        return
    end
    print(
        "\027[1;33m" ..
            string.format(
                "[LGUI3.0.0   @   %s]\t[%s:%d]\t(warn) ",
                get_file(),
                debug.getinfo(2).name,
                debug.getinfo(2).linedefined
            ) ..
                "\027[0m",
        ...
    )
end

function log_error(...)
    if log_level > LOG_LEVEL_ERROR then
        return
    end
    print(
        "\027[1;31m" ..
            string.format(
                "[LGUI3.0.0   @   %s]\t[%s:%d]\t(error) ",
                get_file(),
                debug.getinfo(2).name,
                debug.getinfo(2).linedefined
            ) ..
                "\027[0m",
        ...
    )
end
