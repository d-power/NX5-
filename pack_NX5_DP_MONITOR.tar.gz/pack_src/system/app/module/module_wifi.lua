local _M = {}

_M.sta = {}

function _M.sta.scan()
    return cfun.sta("scan")
end

function _M.sta.connect(ssid, pwd, security)
    return cfun.sta("connect", ssid, pwd, security)
end

function _M.sta.get_ip()
    return cfun.sta("get_ip_addr")
end


return _M
