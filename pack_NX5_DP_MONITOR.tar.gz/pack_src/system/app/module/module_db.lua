local _M = {}


local db_conf = {
    "sys_config",
    "status",  
    "sound",   
    "security",
    "password",
    "net",     
    "hw",      
    "delay",   
    "cloud"
}

for i = 1, #db_conf do
    _M["get_" .. db_conf[i]] = function()
        return cfun.db(db_conf[i], "query")
    end

    _M["set_" .. db_conf[i]] = function(param)
        return cfun.db(db_conf[i], "update", param)
    end
end

function _M.get_call_record()
    local result = cfun.db("call_record", "query")
    return decode(result or "{}")
end

function _M.delete_call_record(id)
    return cfun.db("call_record", "delete", id)
end

function _M.set_call_record(param)
    return cfun.db("call_record", "update", param)
end

function _M.get_safe_record()
    local result = cfun.db("safe_record", "query")
    return decode(result or "{}")
end

function _M.delete_safe_record(id)
    return cfun.db("safe_record", "delete", id)
end

function _M.get_alarm_record()
    local result = cfun.db("alarm_record", "query")
    return decode(result or "{}")
end

function _M.delete_alarm_record(id)
    return cfun.db("alarm_record", "delete", id)
end

function _M.get_photo_record()
    local result = cfun.db("photo_record", "query")
    return decode(result or "{}")
end

function _M.delete_photo_record(id)
    return cfun.db("photo_record", "delete", id)
end

function _M.get_message_record()
    local result = cfun.db("message_record", "query")
    return decode(result or "{}")
end

function _M.delete_message_record(id)
    return cfun.db("message_record", "delete", id)
end

function _M.set_message_record(notice)
    return cfun.db("message_record", "update", notice)
end

function _M.get_quick_record()
    local result = cfun.db("quick_record", "query")
    return decode(result or "{}")
end

function _M.delete_quick_record(id)
    return cfun.db("quick_record", "delete", id)
end

function _M.get_security()
    return cfun.db("security", "query")
end

function _M.set_security(param)
    return cfun.db("security", "update", param)
end

function _M.get_ipc()
    return cfun.db("ipc_record", "query")
end

function _M.update_ipc(param)
    return cfun.db("ipc_record", "update", param)
end

function _M.delete_ipc(param)
    return cfun.db("ipc_record", "delete", param)
end

function _M.insert_ipc(param)
    return cfun.db("ipc_record", "insert", param)
end

return _M
