--[=[
/******************************************************************************
Copyright(c) 2011-2021 Digital Power Inc.
File name: app.lua
Author: liuzhengzhong
Version: 1.0.0
Date: 2020/12/7
Description:
History:
Bug report: liuzhengzhong@d-power.com.cn
******************************************************************************/
]=]

require "module.module_log"
require "module.module_jtot"
require "module.module_zh"

lfs     = require "lfs"
kb      = require "module.module_kb"
popups  = require "module.module_popups"
cfun    = require "libcbell7mxroom"
ws      = require "module.module_ws"
phone   = require "module.moudle_phone"
wifi    = require "module.module_wifi"
db      = require "module.module_db"
safe    = require "module.module_safe"
ipc     = require "module.module_ipc"

function split(s, p)
    local result = {}
    string.gsub(s,'[^'..p..']+', function(w) table.insert(result, w) end)
    return result
end

function no_fun(...) end

function reboot() 
    -- 使用硬件看门狗重启， "reboot" 会死机不能重启
    cfun.reboot()
end

function check_ip(ip)
    local t_ip = split(ip, ".")
    if #t_ip == 4 then
        for index, value in ipairs(t_ip) do
            if #value > 3 or ((tonumber(value) or 257) > 255) then
                return false
            end
        end
    else
        return false
    end

    return true
end

function check_screen_off()
    local page_name = get_now_page_name()
    if page_name == "call" or page_name == "call_out" or common.popups.data.popups_upgrade == false then
        return false
    end

    return true
end

local app =
{
    security_status = {
        SECURITY_STATUS_OFF = 0,
        SECURITY_STATUSING = 1,
        SECURITY_STATUS_ON = 2,
    },
    
    password = { project_passwd = "", safe_passwd = "", hostage_passwd = "", user_passwd = "", },

    sys_config = { 
        screen_saver = 0 , 
        enable_defence = 0 , 
        language = 0, 
        position = "",
        auto_time = 1, 
        last_time = "",
    },

    status = {
        software_name = "" ,
        software_version = "" ,
        hardware_name = "" ,
        hardware_version = "" ,
        system_name = "" ,
        system_version = "" ,
        protocol_version = "" 
    },
    sound = {
        talk_vol = 0 ,
        call_in_ring_name = "" ,
        key_vol_name = "" ,
        ring_vol = 0 ,
        enable_mute = 0 ,
        call_out_ring_name = ""
    },

    hw = {
        display_brightness = 100 ,
        video_hue = 60 ,
        video_brightness = 50 ,
        video_saturation = 80 ,
        video_contrast = 50 
    },

    net = {
        eth_dns1 = "" ,
        wifi_security = 0,
        wifi_password = "" ,
        hotspot_password = "" ,
        hotspot_name = "" ,
        enable_wifi = 0 ,
        wifi_name = "" ,
        eth_ip = "" ,
        eth_dns0 = "" ,
        enable_hotspot = 0 ,
        eth_mask = "" ,
        enable_eth = 1 ,
        eth_gateway = "" ,
        enable_eth_priority = 0 ,
        enable_eth_dhcp = 0 ,
        network_interface = "" ,
        internet_interface = ""
    },

    -- 机器的位置
    position = "",
    -- 升级地址
    upgrade_url = "",

    state = {net1 = false, net2 = false, wifi = false, link = false},
    login_fail_reason = "",

    door_list = {},
    wifi_map = {},

    open_quick = {addr = "", sn = ""},
    monitor_quick = {name = "", addr = "", sn = "", community = ""},

    smart_info  = {
        {name = "睡眠模式", img = "smart_home/sleep.png"},
        {name = "全关模式", img = "smart_home/close.png"},
        {name = "娱乐模式", img = "smart_home/entertainment.png"},
        {name = "在家模式", img = "smart_home/home.png"},
        {name = "聚餐模式", img = "smart_home/eat.png"},
        {name = "影视模式", img = "smart_home/movie.png"},
    },

    ipc_group = { },

    -- security 相关
    area_map = {"厨房", "卧室", "大厅", "窗户", "大门", "阳台", "客厅"},
    type_map = {"紧急", "烟感", "煤气", "门磁", "红外", "窗磁", "玻璃"},
    state_map = {"未启用", "已启用", "已布防", "已报警"},
    level_map = {"常闭", "常开"},
    onoff_map = {"security/off_bg.png", "security/on_bg.png"},
    img_map = {
        -- 紧急
        {"security/sos_off.png",  "security/sos_on.png",  "security/sos_alarm.png"},
        -- 烟感
        {"security/fire_off.png", "security/fire_on.png", "security/fire_alarm.png"},
        -- 煤气
        {"security/gas_off.png",  "security/gas_on.png",  "security/gas_alarm.png"},
        -- 门磁
        {"security/door_off.png",  "security/door_on.png",  "security/door_alarm.png"},
        -- 红外
        {"security/infrared_off.png",  "security/infrared_on.png",  "security/infrared_alarm.png"},
        -- 窗磁
        {"security/magnet_off.png",  "security/magnet_on.png",  "security/magnet_alarm.png"},
        -- 玻璃
        {"security/grass_off.png",  "security/grass_on.png",  "security/grass_alarm.png"},
    },

    security = {
        onoff = {off = 0, on = 1},
        state = {off = 0, on = 1, alarm = 2},
        alarm = {off = 0, on = 1},
    },

    security_group = {
        {area = 0, type = 0, state = 0, onoff = 1, level = 0,},
        {area = 1, type = 1, state = 0, onoff = 0, level = 0,},
        {area = 2, type = 2, state = 0, onoff = 0, level = 0,},
        {area = 3, type = 3, state = 0, onoff = 0, level = 0,},
        {area = 4, type = 4, state = 0, onoff = 0, level = 0,},
        {area = 5, type = 5, state = 0, onoff = 0, level = 0,},
        {area = 6, type = 6, state = 0, onoff = 0, level = 0,},
        {area = 4, type = 4, state = 0, onoff = 0, level = 0,},
    },

    delay = {
        alarm_delay = 60 ,
        alarm_duration = 5 ,
        call_delay = 30 ,
        screen_delay = 60 ,
        safe_delay = 60 
    },

    call_info = { session_id = -1, position = "", unlock = false, lift = false, cancel_alarm = false},
}

function check_web_net_link()
    if app.net.internet_interface == "wlan0" then
        return app.state.wifi
    elseif app.net.internet_interface == "eth0" then
        return app.state.net1
    elseif app.net.internet_interface == "eth1" then
        return app.state.net2
    end
end

function login_out_reset()
    app.open_quick = {addr = "", sn = ""}
    app.monitor_quick = {name = "", addr = "", sn = ""}
end

function get_security_info(info_str)
    log_info(info_str)
    local info_t = decode(info_str)
    if type(info_t) ~= "table" then return end

    for index, value in pairs(info_t.security_param) do
        app.security_group[index].area = value.area
        app.security_group[index].type = value.type
        app.security_group[index].onoff = value.onoff
        app.security_group[index].state = value.state

        app.security_group[index].level = value.level
    end

end

function arm_fail_handle(result)
    if result.reason == 0 then
        popups.show_popups("报警中请先撤防")

    elseif result.reason == 1 then
        local popups_content = ""
        for index, value in ipairs(result.tantou_info) do
            popups_content =
                popups_content ..
                value.pos .. "-" .. app.area_map[value.area + 1] .. "-" .. app.type_map[value.type + 1] .. "\n"
        end
        popups_content = popups_content .. "防区异常"
        popups.show_popups(popups_content, 3, 360, #result.tantou_info * 120)
    elseif result.reason == 2 then
        popups.show_popups("已布防")
    elseif result.reason == 3 then
        popups.show_popups("未启用")
    end
end

return app
