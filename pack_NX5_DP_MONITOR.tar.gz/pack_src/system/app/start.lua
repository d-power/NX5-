--[=[
/******************************************************************************
Copyright(c) 2011-2021 Digital Power Inc.
File name: start.lua
Author: LiuZhengzhong
Version: 1.0.0
Date: 2020/12/7
Description:
History:
Bug report: liuzhengzhong@d-power.com.cn
******************************************************************************/
]=]

-- 声明为全局变量，方便使用
utils_align     = require "utils.align"
utils_btn       = require "utils.btn"
utils_btnm      = require "utils.btnm"
utils_clock     = require "utils.clock"
utils_list      = require "utils.list"
utils_roller    = require "utils.roller"
utils_spinner   = require "utils.spinner"
utils_swiper    = require "utils.swiper"
utils_text      = require "utils.text"
utils_slider    = require "utils.slider"
utils_page      = require "utils.page"
utils_chart     = require "utils.chart"
utils_combobox  = require "utils.combobox"

-- default first page to show

os.execute("date '2021-01-01 12:00:00'")

local app = get_app()

common_add("popups")
common_add("set_bar")
common_hidden("set_bar")
common_add("uvoice")
common_hidden("uvoice")

cfun.init()

app.delay = db.get_delay()
app.password = db.get_password()
app.sys_config = db.get_sys_config()
app.status = db.get_status()
app.sound = db.get_sound()
app.hw = db.get_hw()
app.net = db.get_net()
app.cloud = db.get_cloud()

cfun.screen_set_bright(app.hw.display_brightness)

set_screensaver_time(app.delay.screen_delay)

if app.sys_config.auto_time == 0 then
    os.execute("date '" .. app.sys_config.last_time .. "'")
end

get_security_info(db.get_security())

set_page("home")
