local phone = {}
local app = get_app()

function phone.callring(xparam, yparam, zparam)
    log_debug(xparam, y, z)
    -- {"cmd":"callring","session_id":1000,"position":"LCH测试01栋01单元123"}
    local result = decode(xparam)
    if result then
        (this.callring or no_fun)()
        app.call_info.position = result.position
        app.call_info.unlock = result.unlock
        app.call_info.lift = result.lift
        app.call_info.cancel_alarm = result.cancel_alarm
        set_page("call")
        app.call_info.session_id = result.session_id
    end

end

function phone.callimage(xparam)
    log_debug(xparam)
    local result = decode(xparam)
    if result and result.path and get_now_page_name() == "call" then
        set_data({who_img = result.path})
    end
end

function phone.callaccept(xparam, y, z)
    log_debug(xparam)
    local result = decode(xparam)
    if result then
        (this.callaccept or no_fun) ()
        set_data({now_set = "通话中...", img_hidden = true, vdec_hidden = false})
    end
end

function phone.callhangup(xparam, y, z)
    log_debug(xparam, y, z)
    local result = decode(xparam)
    if result then
        set_page("home")
    end
end

function phone.monitor_ack(xparam)
    log_debug(xparam)
    local result = decode(xparam)
    if result then
        (this.monitor_ack or no_fun)(result)
    end
end

function phone.capture_ack(result)
    if result then
        (this.capture_ack or no_fun)(result)
    end
end

function phone.accept_ack(result)
    log_debug("result", result)
    if result then
        (this.accept_ack or no_fun)(result)
    end
end

function phone.hangup_ack(result)
    if result then
        (this.hangup_ack or no_fun)(result)
    end
end

function phone.callout_ack(xparam)
    log_debug(xparam)
    local result = decode(xparam)
    if result then
        (this.callout_ack or no_fun) (result.result)
    end
end

return phone
