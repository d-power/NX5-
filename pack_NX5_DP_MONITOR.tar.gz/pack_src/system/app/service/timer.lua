--[=[
/******************************************************************************
Copyright(c) 2011-2021 Digital Power Inc.
File name: timer.lua
Author: liuzhengzhong
Version: 1.0.0
Date: 2020/12/16
Description:
History:
Bug report: liuzhengzhong@d-power.com.cn
******************************************************************************/
]=]

local timer =
{
    [c.event.lgui_event_timer] = function(x, y, z)
        
        if cfun then
            cfun.wdt()
        end

        for key, value in pairs(common) do
            if value.timer then value.timer() end 
        end

        if this.show and this.timer then
            this.timer()
        end
    end,

    lgui_event_screensaver = function()
        log_debug("-----------------lgui_event_screensaver-----------------")
        log_debug("is upgrade ??", not common.popups.data.popups_upgrade)
        if this.data.no_screen_off == true or common.popups.data.popups_upgrade == false then
            return 
        end

        cfun.screen_onoff(0)
        set_page("screen_off")
    end,

    lgui_event_gesture = function(dir)
        print("gesture dir :",dir)
    end,

    lgui_event_release = function(ind)
        if get_type_by_index(ind) == "roller" or 
            get_type_by_index(ind) == "btnm"  or
            get_type_by_index(ind) == "mark"  or
            get_type_by_index(ind) == "slider"  or
            get_type_by_index(ind) == "swiper" then
            return 
        end
    
        cfun.play_key_tone(volume)
    end,
    
    lgui_event_changevalue = function(ind)
        if get_type_by_index(ind) == "btnm" then
            cfun.play_key_tone(volume)
        end
    end
}

return timer