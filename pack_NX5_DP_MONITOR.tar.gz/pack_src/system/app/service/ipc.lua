local ipc = {}
local app = get_app()

function ipc.ipc_result(result)
    if result == "discover_fail" then
        popups.show_popups("搜索IPC失败")
    end
end

return ipc
