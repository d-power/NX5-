local sys = {}
local app = get_app()

function sys.connect(interface)
    local _config = interface == "eth0" and "net1" or "net2"
    app.state[_config] = true
    if get_now_page_name() == "hardware_network" then
        set_data({
            [_config .. "_status"] = "网口".. _config:sub(-1,-1) .."：网络已连接",
            [_config .. "_color"] = 0xffffffff
        })
    else 
        set_data({[_config] = false})
    end
end

function sys.disconnect(interface)
    local _config = interface == "eth0" and "net1" or "net2"
    app.state[_config] = false
    if get_now_page_name() == "hardware_network" then
        set_data({
            [_config .. "_status"] = "网口".. _config:sub(-1,-1) .."：网络未连接",
            [_config .. "_color"] = 0xffff0000
        })
    else 
        set_data({[_config] = true})
    end
end

function sys.app_upgrade(status, schedule)
    log_debug(status, schedule)

    if status == "down_start" then
        set_data({update_schedule = "系统升级中",})
        popups.show_upgrade_schedule(0)
        if get_now_page_name() ~= "systemset_upgrade" then
            set_page("home")
        end
    elseif status == "down_schedule" then
        if schedule ~= "nan" then
            popups.show_upgrade_schedule(math.floor(tonumber(schedule)))
        end

    elseif status == "down_success" then
    elseif status == "untar_success" then
        popups.show_upgrade_schedule(75)
    elseif status == "rename_success" then
        -- 升级成功，重启
        popups.show_upgrade_schedule(100)
        set_data({update_schedule = "升级成功,即将重启", schedule_value = 100})

        reboot()
    elseif status == "down_fail" 
        or status == "untar_fail" 
        or status == "rename_fail"
        or status == "check_fail"
        or status == "backup_fail" then

        local show_error = {
            check_fail = "升级包错误，请重新升级",
            down_fail  = "下载失败，请检查网络"
        }

        app.upgrade_url = ""
        lgui_screensaver_reset()
        
        set_data({update_schedule = show_error[status] or "升级失败", schedule_value = 100, hidden_timeout = 10})
    end
end

return sys
