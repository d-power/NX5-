local _service = {}

function _service.alarm(xparam)
    local alarm_act = decode(xparam or "{}")
    if type(alarm_act) == "table" and not (this.alarm or no_fun) (alarm_act) then
        set_page("security")
    end
end

function _service.safe_alarm(xparam)
    local alarm_act = decode(xparam or "{}")
    if type(alarm_act) == "table" and not (this.alarm or no_fun) (alarm_act)  then
        set_page("security")
    end
end

return _service
