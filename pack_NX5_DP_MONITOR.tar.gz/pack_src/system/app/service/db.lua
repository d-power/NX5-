local s_db = {}

function s_db.quick_record_update()
    (this.quick_record_update or no_fun)()
end

return s_db

