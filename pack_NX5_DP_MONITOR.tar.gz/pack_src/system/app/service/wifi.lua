local s_wifi = {}
local app = get_app()

local function connect(_, ch_errno)
    app.state.wifi = true
    (this.connect_result or no_fun)(ch_errno)
    set_data({wifi = false})
end

local function disconnect(_, ch_errno)
    app.state.wifi = false
    -- (this.connect_result or no_fun)(ch_errno)
    set_data({wifi = true})
end

local function scan_result(xparam)
    log_debug(xparam)
    local _result = decode(xparam)
    if _result then
        for key, value in pairs(_result.sta_info) do
            app.wifi_map[key] = value
        end
        (this.scan_result or no_fun)()
    end
end

local function connect_result(_, ch_errno)
    (this.connect_result or no_fun)(ch_errno)
end

local function auto_connect_fail()
    app.net = db.get_net()
    wifi.sta.connect(app.net.wifi_name, app.net.wifi_password, app.net.wifi_security)
end

local function wifi_connect_fail(_, ch_errno)
    app.net = db.get_net()
    -- wifi.sta.connect(app.net.wifi_name, app.net.wifi_password, app.net.wifi_security)
    if this.connect_result then this.connect_result(ch_errno) end
end

local wifi_event = {
    {errno = "wifi is not exist",      func = connect_result,           ch_errno = "网络不存在",},
    {errno = "wifi passwd error",      func = connect_result,           ch_errno = "密码错误",},
    {errno = "wifi connect reject",    func = connect_result,           ch_errno = "WiFi连接被拒绝",},
    {errno = "wifi dhcp abort",        func = connect_result,           ch_errno = "WiFi连接终止DHCP功能！",},
    {errno = "wifi dhcp error",        func = connect_result,           ch_errno = "WIFI dhcp错误",},
    {errno = "wifi dhcp timeout",      func = connect_result,           ch_errno = "WiFi获取IP地址超时！",},
    {errno = "wifi start fail",        func = nil,                      ch_errno = "WiFi启动失败",},
    {errno = "wifi connect fail",      func = wifi_connect_fail,        ch_errno = "WIFI连接失败",},
    {errno = "wifi close fail",        func = nil,                      ch_errno = "WIFI关闭失败",},
    {errno = "wifi scan fail",         func = nil,                      ch_errno = "WIFI扫描失败",},
    {errno = "wifi scan result",       func = scan_result,              ch_errno = "WIFI扫描结果（后面的参数为json,扫描结果）",},
    {errno = "wifi get ip addr",       func = connect_result,           ch_errno = "正在获取IP",},
    {errno = "wifi connected",         func = connect,                  ch_errno = "WIFI连接成功!",},
    {errno = "wifi disconnect",        func = disconnect,               ch_errno = "WIFI连接已断开!",},
    {errno = "wifi close successful",  func = nil,                      ch_errno = "WIFI关闭成功",},
    {errno = "wifi auto connect fail", func = auto_connect_fail,        ch_errno = "自动连接失败"},
}

function s_wifi.wifi_tips(errno, cmd_str)
    log_info(errno)
    for i = 1, #wifi_event do
        if wifi_event[i].errno == errno then
            (wifi_event[i].func or no_fun)(cmd_str, wifi_event[i].ch_errno)
        end
    end
end

function s_wifi.wifi_state(state)
    app.state.wifi = state == "true"
    (this.wifi_state_change or no_fun)(state)
    set_data({wifi = not app.state.wifi})
end

return s_wifi
