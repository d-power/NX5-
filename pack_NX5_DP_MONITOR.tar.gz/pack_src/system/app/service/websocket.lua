local websocket = {}
local app = get_app()

function websocket.doorlist(xparam)
    log_debug(xparam)
    local door_list_result = decode(xparam)
    login_out_reset()
    if door_list_result and door_list_result.result == "ok" then
        for i = 1, #door_list_result.doors do
            app.door_list[i] = {}
            app.door_list[i].sn = door_list_result.doors[i].sn
            app.door_list[i].community = door_list_result.doors[i].community
            app.door_list[i].name = door_list_result.doors[i].name
            app.door_list[i].kind = door_list_result.doors[i].kind
            app.door_list[i].addr = door_list_result.doors[i].building .. (door_list_result.doors[i].building == "" and "" or "栋") .. 
                                    door_list_result.doors[i].unit .. (door_list_result.doors[i].unit == "" and "" or "单元") .. door_list_result.doors[i].name
        end

        if #door_list_result.doors > 0 then
            if app.open_quick.addr == "" then
                app.open_quick.addr = app.door_list[1].addr
                app.open_quick.sn   = app.door_list[1].sn
                set_data({open_door_addr = app.open_quick.addr})
            end

            if app.monitor_quick.name == "" then
                app.monitor_quick.addr = app.door_list[1].addr
                app.monitor_quick.name = app.door_list[1].name
                app.monitor_quick.sn   = app.door_list[1].sn
                app.monitor_quick.community = app.door_list[1].community
                set_data({moniter_default = app.monitor_quick.addr})
            end
        end

        (this.door_list_refresh or no_fun)()
    else
        app.door_list = {}
    end
end

function websocket.sos(x, y, z)
    log_debug(x, y, z)
    local result = decode(x)
    set_data({
        sos_hint_txt =  result.result == "fail" and "报警失败" or "报警成功", 
        sos_status_img = result.result == "fail" and "home/sos_fail.png" or "home/sos_success.png",
        sos_reciprocal_hidden = true, sos_hint = false,
    })
    this.data.sos_reciprocal_timeout = 30

end

function websocket.unlock(xparam)
    log_debug(xparam)
    local result = decode(xparam)
    if result then
        (this.unlock_result or no_fun)(result.result)
    end
end


function websocket.login(xparam, yparam)
    app.state.link = xparam == "ok"

    if app.state.link then
        ws.get_door_list()
    else
        app.login_fail_reason = "nothing"
    end
    
    set_data({link = not app.state.link})
end

function websocket.unlogin(xparam)
    app.state.link = false
    login_out_reset()
    set_data({link = true});

    (this.unlogin or no_fun)()
end

function websocket.upgrade(xparam)
    local result = decode(xparam)
    if result then
        if get_now_page_name() == "systemset_upgrade" then
            if result.should then
                popups.show_popups_with_select("软件升级", "检测到最新版本V".. result.version ..",是否更新", 5)
                app.upgrade_url = result.url
            else
                popups.hidden_popups_with_select()
                popups.show_popups("此版本已最新版本", 3, 360)
            end
        else
            if result.should then
                app.upgrade_url = result.url
                ws.down_upgrade(app.upgrade_url)
            end
        end
        -- set_data({
        --     -- TODO:修改
        --     upgrade_info = result.should and "检测到最新版本\n是否更新" or "此版本已最新版本\n无需更新",
        --     upgrade_schedule = result.should and "更新" or "已更新",
        -- })
    end
end

function websocket.lift_call(xparam)
    log_debug(xparam)
    local result = decode(xparam)
    if result then
        (this.lift_call or no_fun)(result.result)
    end
end

function websocket.notice_list(xparam)
    log_debug(xparam)
    local result = decode(xparam)
    if result then
        (this.notice_update or no_fun)(result)
    end
end

return websocket
