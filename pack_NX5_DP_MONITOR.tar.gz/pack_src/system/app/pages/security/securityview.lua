local view = {
    {
        type        = "page",
        position    = {align = utils_align.IN_TOP_MID, alignx = 10, aligny = 90},
        attr        = {w = 960, h = 500, c = 0x00000000, c_bar = 0x00808080, layout = utils_page.LAYOUT_GRID,
                       round = false, mode = utils_page.MODE_OFF},
        name        = "page0",
        action       = {bind = {change = function(v, posx, posy) log_debug(3, "pos ",  posx, posy) end}}
    },
    
    {
        type = "shared",
        attr = {file = "shared_btn", func = "ctrl_btn", 
                obj = {x = 852, y = 512, name = "save", 
                        rel = "setting/btn_ok.png", act_up = "security_act",
                        content = "一键布防"}},
    },
    {
        type = "shared",
        attr = {file = "shared_btn", func = "ctrl_btn", 
                obj = {x = 680, y = 512, name = "save", 
                        rel = "setting/btn_cancel.png", act_up = "security_cancel",
                        content = "一键撤防"}},
    }
}

local app =  get_app()
local security_group = app.security_group

if type(security_group) == "table" then
    for i = 1, #security_group do
        view[#view + 1] = {
            type = "btn",
            position = {x = 0, y = 0},
            attr = {
                res_rel = "security/bg.png",  parent = "page0"
            },
            action = {bind = {up = "security_change"}},
            user_data = i,
            name = "security" .. i
        }

        view[#view + 1] = {
            type = "text",
            position = {x = 20, y = 20},
            attr = {
                w = 128, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT, parent = "security" .. i,
                c = 0xffffffff, content = app.area_map[security_group[i].area + 1] .. ":" .. app.type_map[security_group[i].type + 1], }
        }

        view[#view + 1] = {
            type = "img",
            position = {align = utils_align.CENTER, aligny = 10},
            attr = { res = "security/round.png", parent = "security" .. i},
        }

        view[#view + 1] = {
            type = "img",
            position = {align = utils_align.CENTER, aligny = 10},
            attr = { res = "{{security_img"..i.."}}", parent = "security" .. i},
        }

        view[#view + 1] = {
            type = "text",
            position = {x = 0, y = 130},
            attr = {
                w = 200, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_RIGHT, parent = "security" .. i,
                c = 0xffffffff, content = "{{security_state" .. i .."}}", }
        }

        view[#view + 1] = {
            type = "text",
            position = {x = 0, y = 20},
            attr = {
                w = 200, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_RIGHT, parent = "security" .. i,
                c = 0xffffffff, content = "{{timeout"..i.."}}", }
        }
    end
end

view[#view + 1] = {
    type = "mark",
    position = {align = utils_align.CENTER},
    attr = {w = 1024, h = 600, c = 0x202C2C2C, hidden = "{{security_popups_hidden}}"},
    name = "security_popups_bg"
}
view[#view + 1] = {
    type = "img",
    position = {align = utils_align.CENTER},
    attr = {res = "security/security_popup.png", parent = "security_popups_bg"},
    name = "security_popups_text_bg"
}
view[#view + 1] = {
    type = "text",
    position = {align = utils_align.CENTER, aligny = -30},
    attr = {
        w = 246, h = 32, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = "security_popups_text_bg",
        c = 0xffffffff, content = "{{security_popups_content}}", }
}


view[#view + 1] = {
    type = "shared",
    attr = {file = "shared_btn", func = "ctrl_btn", 
            obj = {x = 446, y = 344, name = "save", 
                    rel = "setting/btn_ok.png", act_up = "security_close", parent = "security_popups_bg",
                    content = "取消布防"}},
}

return view
