local app = get_app()

-- 同步状态
get_security_info(db.get_security())

local security_group = app.security_group
local default_timeout = app.delay.safe_delay * 10
local default_content = app.delay.safe_delay .. "S"

local security_timeout = {}
local all_timeout = -1

local security_state = safe.tantou_status()

local controller = {
    data = {
        security_popups_hidden = true,
        security_popups_content = ""
    },
    onload = function()
        common_show("set_bar")
        set_data({now_set = "家庭安防", return_page = "home"})
        log_debug("security/security onload")
    end,
    onshow = function()
        set_data({return_msg = {show_act = 0}})
        cfun.screen_onoff(1)
        log_debug("security/security onshow")
    end,
    ondestroy = function()
        log_debug("security/security ondestroy")
    end,
    
    ret_act = function()
        return not this.data.security_popups_hidden
    end,
    -- 一键布防
    security_act = function()
        local have_not_armed = false

        local result = safe.arm(#app.security_group)
        if result.result == "ok" then
            for i = 1, #security_group do
                set_data({["timeout" .. i] = ""})
            end

            for index, value in ipairs(result.tantou_info) do
                security_timeout[value.pos] = default_timeout
            end

            all_timeout = default_timeout
            set_data(
                {
                    security_popups_hidden = false,
                    security_popups_content = default_content
                }
            )
        else
            arm_fail_handle(result)
        end
    end,
    
    -- 取消布防
    security_close = function(v)
        local result = safe.disarm(#app.security_group)
        if result.result == "ok" then
            for i = 1, #security_group do
                security_timeout[i] = -1
            end
            all_timeout = -1
            set_data({security_popups_hidden = true})
        else
        end
    end,

    ret_act = function(v)
        for index, value in ipairs(security_group) do
            if value.state == app.security.state.alarm then
                return true
            end
        end
        return false
    end,

    -- 一键撤防
    security_cancel = function(v)
        local have_armed = false
        for i = 1, #security_group do
            if security_group[i].state == app.security.state.alarm 
            or (security_group[i].state == app.security.state.on and security_group[i].type > 2) then
                have_armed = true
            end
        end
        if have_armed then
            set_page("security_pwd")
        else
            popups.show_popups("未布防")
        end
    end,
    
    security_change = function(v)
        if app.security_group[v.user_data].onoff == app.security.onoff.on then
            if security_timeout[v.user_data] == -1 then
                if app.security_group[v.user_data].state == app.security.state.off then
                    local result = safe.arm(v.user_data - 1)
                    table.print(result)
                    if result.result == "ok" then
                        security_timeout[v.user_data] = default_timeout
                        set_data({["timeout" .. v.user_data] = default_content})
                    else
                        arm_fail_handle(result)
                    end
                else
                    set_page("security_pwd", {disarm_number = v.user_data})
                end
            else
                if app.security_group[v.user_data].state == app.security.state.alarm then
                    set_page("security_pwd", {disarm_number = v.user_data})
                else
                    local result = safe.disarm(v.user_data - 1)
                    if result.result == "ok" then
                        security_timeout[v.user_data] = -1
                        set_data({["timeout" .. v.user_data] = ""})
                    else
                        arm_fail_handle(result)
                    end
                end
            end
        end
    end,
   
    timer = function()
        if all_timeout > 0 then
            all_timeout = all_timeout - 1
            if all_timeout % 10 == 0 then
                set_data(
                    {
                        security_popups_hidden = false,
                        security_popups_content = math.floor(all_timeout / 10) .. "S"
                    }
                )
            end
        elseif all_timeout == 0 then
            all_timeout = -1
            set_data({security_popups_hidden = true})
            popups.show_popups("布防成功", 3)
        end

        for i = 1, #security_timeout do
            if security_timeout[i] > 0 then
                security_timeout[i] = security_timeout[i] - 1
                if security_timeout[i] % 10 == 0 and all_timeout == -1 then
                    set_data({["timeout" .. i] = math.floor(security_timeout[i] / 10) .. "S"})
                end
            elseif security_timeout[i] == 0 then
                app.security_group[i].state = app.security_group[i].state < 2 and app.security_group[i].state + 1 or 2
                set_data(
                    {
                        ["timeout" .. i] = "",
                        ["security_img" .. i] = app.img_map[security_group[i].type + 1][security_group[i].state + 1],
                        ["security_state" .. i] = app.state_map[security_group[i].onoff + security_group[i].state + 1]
                    }
                )
                security_timeout[i] = -1
            end
        end
    end
}

if security_group == nil then
    return controller
end

for i = 1, #security_group do
    local state = 0
    controller.data["timeout" .. i] = ""
    security_timeout[i] = -1

    if security_state.tantou_info[i].state == 0 then
        security_group[i].state = 0
    elseif security_state.tantou_info[i].state == 1 then
        security_group[i].state = 1
    elseif security_state.tantou_info[i].state == 2 then
        controller.data["timeout" .. i] = math.floor(security_state.tantou_info[i].delay / 1000) .. "S"
        security_timeout[i] = math.floor(security_state.tantou_info[i].delay / 100)
        security_group[i].state = 0
    elseif security_state.tantou_info[i].state == 3 then
        controller.data["timeout" .. i] = math.floor(security_state.tantou_info[i].delay / 1000) .. "S"
        security_timeout[i] = math.floor(security_state.tantou_info[i].delay / 100)
        security_group[i].state = 2
    elseif security_state.tantou_info[i].state == 4 then
        security_group[i].state = 2
    end

    controller.data["security_img" .. i] = app.img_map[security_state.tantou_info[i].type + 1][security_group[i].state + 1]
    controller.data["security_state" .. i] = app.state_map[security_state.tantou_info[i].onoff + security_group[i].state + 1]
end

return controller
