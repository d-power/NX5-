local view = {
    -- 
    {
        type = "img",
        position = {align = utils_align.IN_TOP_LEFT, alignx = 31, aligny = 85},
        attr = {res = "setting/pwdset_bg.png"}
    },
    {
        type = "text",
        position = {align = utils_align.IN_TOP_LEFT, aligny = 128, alignx = 63},
        attr ={ w = 240, h = 20, c = 0xffffffff, content = "请输入撤防密码"},
        name = "pwd_txt"
    },
    {
        type = "textarea",
        position = {align = utils_align.OUT_RIGHT_MID, alignx = 15, aligny = 0, ref = "pwd_txt"},
        attr = {w = 288, h_content = 32, curor = 500, max = 6, align = 1, pwd = 500, radius = 8,
                c_content = 0xFFFFFFFF, c = 0xff1d1d1d, c_cursor = 0xFFFFFFFF, content = "{{input_pwd}}",single = true}, 
        action      = {bind = {up = "ta_change"}},
    },
    {
        type = "btnm",
        position = {align = utils_align.IN_TOP_LEFT, alignx = 540, aligny = 80,},
        attr =
        {
            w = 450, h = 410, h_content = 25,
            -- 背景，按键常态，按键按下，按键禁用，按键选中的颜色
            c = 0x00ffffff, c_def = 0xff1d1d1d, c_clk = 0xff526178, c_dis = 0xff808080, c_chk = 0xff526178, radius = 8,
            -- 文本，文本按下，文本禁用，文本选中的颜色
            c_content = 0xffffffff, c_content_clk = 0xffffffff, c_content_dis = 0xff000000, c_content_chk = 0xffffffff,
            map =
            {
                "1","2","3","\n",
                "4","5","6","\n",
                "7","8","9","\n",
                "0"," ","确定",
            },
            map_ctrl =
            {
                1, 1, 1,
                1, 1, 1,
                1, 1, 1, 
                1, 1, 1,
            },
        },
        action = {bind = {change = "btnm_action"}},
    },
    {
        type = "img",
        position = {align = utils_align.IN_TOP_LEFT, alignx = 746, aligny = 423},
        attr = {res = "setting/del.png"}
    },
}

return view;
