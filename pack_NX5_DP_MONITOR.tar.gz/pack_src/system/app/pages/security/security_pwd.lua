local app = get_app()

local security_group = app.security_group

local controller =
{
    data = {
        input_pwd = "",
        disarm_number = 0
    },
    onload = function()
        set_data({now_set = "家庭安防", return_page = "security"})
        log_debug('systemset/input_pwd onload') 
    end,
    onshow = function()
        log_debug('systemset/input_pwd onshow') 
    end,
    ondestroy = function()
        log_debug('systemset/input_pwd ondestroy') 
    end,

    btnm_action = function(v, txt)

        local function disarm()
            if this.data.disarm_number == 0 then
                for index, value in ipairs(app.security_group) do
                    value.state = app.security.state.off
                end
                safe.disarm(#app.security_group)
            elseif this.data.disarm_number > 0 then
                app.security_group[this.data.disarm_number].state = app.security.state.off
                safe.disarm(this.data.disarm_number - 1)
            end
            set_page(common.set_bar.data.return_page)
        end

        if txt == " " then
            set_data({input_pwd = this.data.input_pwd:sub(1, -2) })
        elseif txt == "确定" then
            if this.data.input_pwd == app.password.safe_passwd then
                disarm()
            elseif this.data.input_pwd == app.password.hostage_passwd then
                log_info("挟持密码")
                disarm()
            else
                popups.show_popups("密码错误")
                set_data({input_pwd = ""})
            end
        elseif this.data.input_pwd:len() < 6 then
            set_data({input_pwd = this.data.input_pwd .. txt })
        end
    end
}
return controller