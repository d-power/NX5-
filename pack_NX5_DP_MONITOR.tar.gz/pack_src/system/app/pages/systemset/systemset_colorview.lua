local view = {
    {
        type = "shared",
        attr = {file = "shared_btn", func = "ctrl_btn", 
                obj = {x = 852, y = 512, name = "save", 
                        rel = "setting/btn_ok.png", act_up = "config_act",
                        content = "保存"}},
    },
    {
        type = "shared",
        attr = {file = "shared", func = "shared_color", 
                obj = {x = 64, y = 96, name = "contrast", content = "对比度"}},
    },
    {
        type = "shared",
        attr = {file = "shared", func = "shared_color", 
                obj = {x = 570, y = 96, name = "saturation", content = "饱和度"}},
    },
    {
        type = "shared",
        attr = {file = "shared", func = "shared_color", 
                obj = {x = 64, y = 246, name = "colorfulness", content = "视频色彩度"}},
    },
    {
        type = "shared",
        attr = {file = "shared", func = "shared_color", 
                obj = {x = 570, y = 246, name = "light", content = "视频亮度"}},
    },
    {
        type = "shared",
        attr = {file = "shared", func = "shared_color", 
                obj = {x = 64, y = 396, name = "contrast_video", content = "视频对比度"}},
    },
    {
        type = "shared",
        attr = {file = "shared", func = "shared_color", 
                obj = {x = 570, y = 396, name = "saturation_video", content = "视频饱和度"}},
    },
}

return view
