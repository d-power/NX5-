local view = {
    {
        type        = "page",
        position    = {align = utils_align.IN_TOP_MID, alignx = 10, aligny = 80},
        attr        = { w = 1000, h = 500, c = 0x00000000, c_bar = 0x00808080, hidden = "{{ipc_show}}",
                        layout = utils_page.LAYOUT_GRID, round = false, mode = utils_page.MODE_OFF},
        name        = "page_ipc"
    },
    {
        type = "shared",
        attr = {file = "shared_btn", func = "ctrl_btn", 
                obj = {x = 852, y = 512, name = "delete",
                        rel = "record/delete.png", act_up = "delete", hidden = "{{del_hidden}}",
                        content = "删除"}},
    },
}

local app = get_app()

app.ipc_group = decode(db.get_ipc() or "{}").ipc_record or {}

for i = 1, #app.ipc_group do
    view[#view + 1] =    {
        type = "blank",
        position = {x = 0, y = 0},
        attr = {w = 148, h = 200, c = 0x00383838, hidden = "{{delete"..i.."}}", parent = "page_ipc"},
        name = "camera" .. i
    }

    view[#view + 1] =    {
        type = "btn",
        position = {align = utils_align.IN_TOP_MID},
        attr = {res_rel = "setting/camera.png", parent = "camera" .. i},
        action = {bind = {up = "camera_select"}},
        user_data = i
    }

    view[#view + 1] =    {
        type = "img",
        position = {x = 110, y = 100},
        attr = {res =  "{{selete_img"..i.."}}", w = 20, h = 20, hidden = "{{selete"..i.."}}", parent = "camera" .. i}
    }

    view[#view + 1] =    {
        type = "text",
        position = {align = utils_align.IN_TOP_MID, aligny = 140},
        attr ={ w = 240, h = 20, c = 0xffffffff, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER,
                content = app.ipc_group[i].name, parent = "camera" .. i},
    }

    view[#view + 1] =    {
        type = "text",
        position = {align = utils_align.IN_TOP_MID, aligny = 170},
        attr ={ w = 240, h = 14, c = 0xffffffff, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER,
                content = app.ipc_group[i].ip, parent = "camera" .. i},
    }
end


view[#view + 1] =    {
    type = "mark",
    position = {x = 0, y = 0},
    attr = {w = 148, h = 200, c = 0x00383838, parent = "page_ipc"},
    name = "camera_add",
}

view[#view + 1] =    {
    type = "btn",
    position = {align = utils_align.IN_TOP_MID},
    attr = {res_rel = "setting/ipc_add.png", parent = "camera_add"},
    action = {bind = {up = "camera_add"}},
}

view[#view + 1] =    {
    type = "text",
    position = {align = utils_align.IN_TOP_MID, aligny = 140},
    attr ={ w = 240, h = 20, c = 0xffffffff, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER,
            content = "添加", parent = "camera_add"},
}

return view
