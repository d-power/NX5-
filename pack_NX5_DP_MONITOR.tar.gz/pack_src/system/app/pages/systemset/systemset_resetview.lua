local view = {
    {
        type = "img",
        position = {align = utils_align.CENTER},
        attr = {res = "setting/system_reset_bg.png", hidden = "{{bg_hidden}}"},
        name = "bg",
    },
    {
        type = "text",
        position = {align = utils_align.IN_TOP_MID, aligny = 56},
        attr ={ w = 400, h = 24, c = 0xffffffff, mode = utils_text.MODE_SROLL, 
                align = utils_text.ALIGN_CENTER, content = "恢复出厂设置", parent = "bg"},
    },
    {
        type = "text",
        position = {align = utils_align.IN_TOP_MID, aligny = 112},
        attr ={ w = 400, h = 16, c = 0xffffffff, mode = utils_text.MODE_SROLL, 
                align = utils_text.ALIGN_CENTER, content = "请确认是否要恢复出厂设置？", parent = "bg"},
    },
    {
        type = "btn",
        position = {align = utils_align.IN_BOTTOM_MID, alignx = 86, aligny = -38},
        attr = {res_rel = "setting/btn_ok.png", parent = "bg"},
        action = {bind = {up ="reset"}},
        name = "ok_act"
    },
    {
        type = "text",
        position = {align = utils_align.CENTER},
        attr ={ w = 120, h = 20, c = 0xffffffff, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, content = "确定", parent = "ok_act"},
    },
    {
        type = "btn",
        position = {align = utils_align.IN_BOTTOM_MID, alignx = -86, aligny = -38},
        attr = {res_rel = "setting/btn_cancel.png", parent = "bg"},
        action = {bind = {up = function() set_page("setting", {show_tab = "system_set"}) end}},
        name = "cancel_act"
    },
    {
        type = "text",
        position = {align = utils_align.CENTER},
        attr ={ w = 120, h = 20, c = 0xffffffff, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, content = "取消", parent = "cancel_act"},
    },
}
return view