local app = get_app()

app.ipc_group = decode(db.get_ipc() or "{}").ipc_record or {}

local ipc_total = #app.ipc_group
local selete_index = {}
local delete_en = false

local controller =
{
    data = {
        ipc_show = false,
        del_hidden = #app.ipc_group == 0
    },
    
    onload = function()
        log_debug('systemset/systemset_ipc onload') 
    end,

    onshow = function()
        set_data({return_page = "setting", now_set = "网络摄像机", return_msg = {show_tab = "system_set",}})
        log_debug('systemset/systemset_ipc onshow') 
    end,
    
    ondestroy = function()
        log_debug('systemset/systemset_ipc ondestroy') 
    end,

    camera_add = function ()
        set_page("systemset_addipc")
    end,

    camera_select = function (v)

        if not delete_en then
            set_page("systemset_addipc", {
                ipc_name_txt = app.ipc_group[v.user_data].name,
                ipc_ip_txt = app.ipc_group[v.user_data].ip,
                ipc_user_txt = app.ipc_group[v.user_data].username,
                ipc_pwd_txt = app.ipc_group[v.user_data].password,
                modify = v.user_data
            })
        else
            set_data({
                ["selete_img" .. v.user_data] = this.data["selete_img" .. v.user_data] == "setting/bg_select.png" 
                                                and "setting/bg_noselect.png" or "setting/bg_select.png" 
            })

            if this.data["selete_img" .. v.user_data] == "setting/bg_select.png" then
                table.insert(selete_index, v.user_data)
            else
                for i = 1, #selete_index do
                    if selete_index[i] == v.user_data then
                        table.remove(selete_index, i)
                        break
                    end
                end
            end
        end
    end,

    delete = function ()
        if not delete_en then
            delete_en = true
            local set_table = {}
            for i = 1, ipc_total do
                set_table["selete" .. i] = false
                set_table["selete_img" .. i] = "setting/bg_noselect.png"
            end
            set_data(set_table)
        else
            table.sort(selete_index, function(a,b) return a > b end)
            for i = 1, #selete_index do
                set_data({["delete" .. selete_index[i]] = true})
                -- 删除ipc
                db.delete_ipc(app.ipc_group[selete_index[i]].id)
                table.remove(app.ipc_group, selete_index[i])
            end
            selete_index = {}
            delete_en = false
            local set_table = {}
            set_table.del_hidden = #app.ipc_group == 0
            for i = 1, ipc_total do
                set_table["selete" .. i] = true
            end
            set_data(set_table)
        end
    end
}

for i = 1, ipc_total do
    controller.data["selete" .. i] = true
    controller.data["selete_img" .. i] = "setting/bg_noselect.png"
    controller.data["delete" .. i] = false
end

return controller
