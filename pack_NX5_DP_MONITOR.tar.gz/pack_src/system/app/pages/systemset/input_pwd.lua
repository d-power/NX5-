local app = get_app()

local controller =
{
    data = {
        input_pwd = ""
    },
    onload = function()
        set_data({now_set = "工程密码", return_msg = {show_tab = "user_set"}})
        log_debug('systemset/input_pwd onload') 
    end,
    onshow = function()
        log_debug('systemset/input_pwd onshow') 
    end,
    ondestroy = function()
        log_debug('systemset/input_pwd ondestroy') 
    end,

    btnm_action = function(v, txt)
        if txt == " " then
            set_data({input_pwd = this.data.input_pwd:sub(1, -2) })
        elseif txt == "确定" then
            print(this.data.input_pwd, app.password.project_passwd )
            if this.data.input_pwd == app.password.project_passwd then
                set_page("setting", {show_tab = "system_set"})
            else
                popups.show_popups("密码错误")
                set_data({input_pwd = ""})
            end
        elseif this.data.input_pwd:len() < 6 then
            set_data({input_pwd = this.data.input_pwd .. txt })
        end
    end
}
return controller