local view = {
    {
        type        = "page",
        position    = {align = utils_align.IN_TOP_MID, alignx = 0, aligny = 80},
        attr        = { w = 320, h = 480, c = 0xFF1d1d1d, c_bar = 0x00808080, hidden = "{{ipc_select}}",
                        layout = utils_page.LAYOUT_OFF, round = true, mode = utils_page.MODE_OFF},
        name        = "page_upgrade"
    },
    {
        type = "img",
        position = {align = utils_align.CENTER, aligny = -50},
        attr = {res = "setting/update_bg.png", parent = "page_upgrade"},
        name = "update_bg",
    },
    {
        type = "img",
        position = {align = utils_align.CENTER,},
        attr = {res = "{{upgrade_img}}", parent = "update_bg"},
    },
    {
        type = "btn",
        position = {align = utils_align.IN_BOTTOM_MID,  aligny = -40},
        attr = {res_rel = "setting/update_act.png", parent = "page_upgrade", hidden = "{{upgrade_hidden}}"},
        action = {bind = {up = "upgrade_action"}},
        name = "update_act"
    },
    {
        type = "text",
        position = {align = utils_align.IN_BOTTOM_MID,  aligny = -160},
        attr ={ w = 300, h = 16, c = 0xffffffff, mode = utils_text.MODE_BREAK, 
                align = utils_text.ALIGN_CENTER, content = "{{upgrade_info}}", parent = "page_upgrade"},
    },
    {
        type = "text",
        position = {align = utils_align.IN_BOTTOM_MID,  aligny = -50},
        attr ={ w = 300, h = 20, c = 0xffffffff, mode = utils_text.MODE_SROLL, 
                align = utils_text.ALIGN_CENTER, content = "{{upgrade_schedule}}", parent = "page_upgrade"},
    },
}
return view