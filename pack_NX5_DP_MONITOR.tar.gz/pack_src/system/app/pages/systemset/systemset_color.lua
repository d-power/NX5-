local controller =
{
    data = {
        contrast_value = 50,
        saturation_value = 50,
        colorfulness_value = 50,
        light_value = 50,
        contrast_video_value = 50,
        saturation_video_value = 50,
    },
    onload = function()
        set_data({now_set = "色彩调整", return_msg = {show_tab = "system_set",}})
        log_debug('systemset/systemset_color onload') 
    end,
    onshow = function()
        log_debug('systemset/systemset_color onshow') 
    end,
    ondestroy = function()
        log_debug('systemset/systemset_color ondestroy') 
    end,

    color_change = function(v)
        local change_cfg = split(v.name, "^")
        local change_value = change_cfg[1] .. "_value"

        print(v.name, this.data[change_value])

        if change_cfg[2] == "add" and this.data[change_value] < 100 then
            set_data({[change_value] = this.data[change_value] + 1})
        elseif change_cfg[2] == "reduce" and this.data[change_value] > 0 then
            set_data({[change_value] = this.data[change_value] - 1})
        end
    end,

    config_act = function(v)
        -- 保存配置
        table.print(this.data)
    end
}
return controller