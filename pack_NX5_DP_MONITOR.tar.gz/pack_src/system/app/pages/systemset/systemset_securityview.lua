local view = {
    {
        type = "img",
        position = {align = utils_align.IN_TOP_MID, aligny = 88},
        attr = {res = "setting/bg.png"}
    },
    {
        type = "text",
        position = {x = 48,  y = 110},
        attr ={ w = 230, h = 22, c = 0xffffffff, mode = utils_text.MODE_BREAK, 
                align = utils_text.ALIGN_CENTER, content = "防区", parent = "page_upgrade"},
    },

    {
        type = "text",
        position = {x = 278,  y = 110},
        attr ={ w = 230, h = 22, c = 0xffffffff, mode = utils_text.MODE_BREAK, 
                align = utils_text.ALIGN_CENTER, content = "类型", parent = "page_upgrade"},
    },

    {
        type = "text",
        position = {x = 508,  y = 110},
        attr ={ w = 230, h = 22, c = 0xffffffff, mode = utils_text.MODE_BREAK, 
                align = utils_text.ALIGN_CENTER, content = "是否启用", parent = "page_upgrade"},
    },

    {
        type = "text",
        position = {x = 738,  y = 110},
        attr ={ w = 230, h = 22, c = 0xffffffff, mode = utils_text.MODE_BREAK, 
                align = utils_text.ALIGN_CENTER, content = "触发电平", parent = "page_upgrade"},
    },

    {
        type = "list",
        position = {x = 48, y = 150},
        attr =
        {
            w = 920, h = 350, h_line = 50, c = 0x00bcc3cd, c_def = 0x00000000, c_clk = 0x00000000, keep = true, c_bar = 0x00181818,
            map = "{{list_map}}", slidepos = 0, c_edge = 0x003d3d3d,
            map_ctrl =
            {
                {
                    type = utils_list.TYPE_TEXT, x = 0, y = 16, w = 230, h = 30, c = 0xffffffff,
                    content_h = 16, content_algin = utils_list.TEXT_ALIGN_CENTER, content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
                {
                    type = utils_list.TYPE_BTN, x = 0, y = 0, w = 230, h = 50,
                },
                {
                    type = utils_list.TYPE_TEXT, x = 230, y = 16, w = 230, h = 20, c = 0xffffffff,
                    content_h = 16, content_algin = utils_list.TEXT_ALIGN_CENTER, content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
                {
                    type = utils_list.TYPE_BTN, x = 230, y = 0, w = 230, h = 50,
                },
                {
                    type = utils_list.TYPE_TEXT, x = 460, y = 16, w = 230, h = 30, c = 0xffffffff,
                    content_h = 16, content_algin = utils_list.TEXT_ALIGN_CENTER, content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
                {
                    type = utils_list.TYPE_BTN, x = 460, y = 0, w = 230, h = 50,
                },
                {
                    type = utils_list.TYPE_TEXT, x = 690, y = 16, w = 230, h = 20, c = 0xffffffff,
                    content_h = 16, content_algin = utils_list.TEXT_ALIGN_CENTER, content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
                {
                    type = utils_list.TYPE_BTN, x = 690, y = 0, w = 230, h = 50,
                },
                {
                    type = utils_list.TYPE_IMG, x = 62, y = 69
                },
            },
        },
        action = {bind = {change = "list", up = "list_up"}}
    },
    {
        type = "shared",
        attr = {file = "shared_btn", func = "ctrl_btn", 
                obj = {x = 852, y = 512, name = "save", 
                        rel = "setting/btn_ok.png", act_up = "config_act",
                        content = "保存"}},
    },
}

return view