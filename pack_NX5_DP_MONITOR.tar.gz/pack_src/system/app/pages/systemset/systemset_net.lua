local app = get_app()
app.net = db.get_net()

local _net_map = {
    "云聆", "home/right.png", "setting/list_line.png",
    "楼宇", "home/right.png", "setting/list_line.png",
}

local _yunling_map = {
    "LAN1", app.net.internet_interface == "eth0" and "setting/ring_select.png" or "setting/ring_noselect.png", "setting/list_line.png",
    "LAN2", app.net.internet_interface == "eth1" and "setting/ring_select.png" or "setting/ring_noselect.png", "setting/list_line.png",
    "WIFI", app.net.internet_interface == "wlan0" and "setting/ring_select.png" or "setting/ring_noselect.png", "setting/list_line.png",
}

local _local_map = {
    "LAN1", app.net.network_interface == "eth0" and "setting/ring_select.png" or "setting/ring_noselect.png", "setting/list_line.png",
    "LAN2", app.net.network_interface == "eth1" and "setting/ring_select.png" or "setting/ring_noselect.png", "setting/list_line.png",
}

local correspond_map = {
    eth0 = "LAN1",
    eth1 = "LAN2",
    wlan0 = "WIFI",
}

local now_set = ""
local now_choose = ""

-- TODO:保存网络配置

local controller =
{
    data = {
        net_map = _net_map,
        hidden_save = true
    },
    
    onload = function()
        set_data({now_set = "网络设置", return_msg = {show_tab = "system_set",}})
        log_debug('systemset/systemset_net onload') 
    end,
    
    onshow = function()
        log_debug('systemset/systemset_net onshow') 
    end,

    ondestroy = function()
        log_debug('systemset/systemset_net ondestroy') 
    end,

    ret_act = function()
        if now_set == "" then 
            return false
        else
            set_data({net_map = _net_map, hidden_save = true})
            now_set=  ""
            return true
        end
    end,

    config_act = function()
        
        print(now_choose, app.net.internet_interface)

        if now_set == "local" then
            if now_choose == app.net.internet_interface then
                popups.show_popups(correspond_map[now_choose] .. ",已被占用")
            else
                app.net.network_interface = now_choose
                print(app.net.network_interface)
                if db.set_net(app.net) == 0 then
                    popups.show_popups("设置成功")
                else
                    popups.show_popups("设置失败")
                end
            end
        elseif now_set == "yunling" then
            if now_choose == app.net.network_interface then
                popups.show_popups(correspond_map[now_choose] .. ",已被占用")
            else
                app.net.internet_interface = now_choose
                if db.set_net(app.net) == 0 then
                    popups.show_popups("设置成功")
                else
                    popups.show_popups("设置失败")
                end
            end
        end
    end,

    list_up = function(v, line)

        _local_map = {
            "LAN1", "setting/ring_noselect.png", "setting/list_line.png",
            "LAN2", "setting/ring_noselect.png", "setting/list_line.png",
        }

        _yunling_map = {
            "LAN1", "setting/ring_noselect.png", "setting/list_line.png",
            "LAN2", "setting/ring_noselect.png", "setting/list_line.png",
            "WIFI", "setting/ring_noselect.png", "setting/list_line.png",
        }

        if now_set == "" then
            if line == "2" then
                local show_line = app.net.network_interface == "eth0" and 0 or 1
                _local_map[show_line * 3 + 2] = "setting/ring_select.png"
                set_data({net_map = _local_map, hidden_save = false})
                now_set = "local"
                now_choose = app.net.network_interface
            else
                local show_line = app.net.internet_interface == "eth0" and 0 or (app.net.internet_interface == "eth1" and 1 or 2)
                _yunling_map[show_line * 3 + 2] = "setting/ring_select.png"
                set_data({net_map = _yunling_map, hidden_save = false})
                now_set = "yunling"
                now_choose = app.net.internet_interface
            end
        elseif now_set == "local" then
            local n_line = tonumber(line)
            now_choose = n_line == 1 and "eth0" or "eth1"
            _local_map[(n_line - 1)*3 + 2] = "setting/ring_select.png"
            set_data({net_map = _local_map})
        elseif now_set == "yunling" then
            local n_line = tonumber(line)
            now_choose = n_line == 1 and "eth0" or (n_line == 2 and "eth1" or "wlan0")
            _yunling_map[(n_line - 1)*3 + 2] = "setting/ring_select.png"
            set_data({net_map = _yunling_map})
        end
    end,

}
return controller