local view = {
    {
        type = "list",
        position = {align = utils_align.IN_TOP_MID, aligny = 60},
        attr =
        {
            w = 896, h = 520, h_line = 70, keep = true, map = "{{net_map}}",
            c_bar = 0x00000000, c = 0x00000000, c_def = 0x00000000, c_clk = 0x00000000,
            map_ctrl =
            {
                {
                    type = utils_list.TYPE_TEXT, x = 10, y = 24, w = 250, h = 40, c = 0xffffffff,
                    content_h = 22, content_algin = utils_list.TEXT_ALIGN_LEFT, 
                    content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
                { type = utils_list.TYPE_IMG, x = 840, y = 30, },
                { type = utils_list.TYPE_IMG, x = 0, y = 69 },
            },
        },
        action = {bind = {change = "list", up = "list_up"}}
    },
    {
        type = "shared",
        attr = {file = "shared_btn", func = "ctrl_btn", 
                obj = {x = 852, y = 512, name = "save", hidden = "{{hidden_save}}",
                        rel = "setting/btn_ok.png", act_up = "config_act",
                        content = "保存"}},
    },
}
return view