local controller =
{
    data = {
        bg_hidden = false
    },
    onload = function()
        common_hidden("set_bar")
        log_debug('systemset/systemset_reset onload') 
    end,
    onshow = function()
        log_debug('systemset/systemset_reset onshow') 
    end,
    ondestroy = function()
        common_show("set_bar")
        log_debug('systemset/systemset_reset ondestroy') 
    end,

    reset = function()
        set_data({bg_hidden = true})
        cfun.reset()
        reboot()
    end,

}
return controller