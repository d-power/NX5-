local input_info ={
    ipc_name = "请输入名称：",
    ipc_ip = "请输入IP号：",
    ipc_user = "请输入用户名：",
    ipc_pwd = "请输入密码：",
}

local app = get_app()
local page_act = false
local btnm_unact = false

local now_input = ""
local t_input_txt = {}

local function get_zh_ctrl(len)
    local ret = {}
    for i = 1, len do
        ret[i] = 1 | utils_btnm.RPT_UP | utils_btnm.NO_RPT_LONG
    end
    return ret
end

local controller =
{
    data = {
        ipc_select = false,
        input_hid = true,
        input_info = "",

        ipc_name_txt = "",
        ipc_ip_txt = "",
        ipc_user_txt = "",
        ipc_pwd_txt = "",

        ipc_name_hidden = true,
        ipc_ip_hidden = true,
        ipc_user_hidden = true,
        ipc_pwd_hidden = true,

        modify = 0,

        input_txt = "",

        btnm_map = kb.abc,
        btnm_map_ctrl = kb.abc_ctrl,

        zh_w   = 0,
        slideposx = 0,
        zh_map = {},
        zh_ctrl = {},
        zh_hidden = true,   
        input_pinyin = ""

    },
    onload = function()
        set_data({return_page = "systemset_ipc", 
                  now_set = "添加网络摄像机", return_msg = {show_tab = "system_set",}})
        log_debug('systemset/systemset_addipc onload') 
    end,
    onshow = function()
        log_debug('systemset/systemset_addipc onshow') 
    end,
    ondestroy = function()
        log_debug('systemset/systemset_addipc ondestroy') 
    end,

    ret_act = function()
        if this.data.input_hid == false then
            set_data({
                ipc_select = false,
                input_hid = true,
            })
            return true
        end
        return false
    end,

    add_ipc = function(v)
        -- app.ipc_group[this.data.modify == 0 and (#app.ipc_group + 1) or this.data.modify] = 
        if  not check_ip(this.data.ipc_ip_txt) 
            or this.data.ipc_name_txt == "" 
            or this.data.ipc_user_txt == "" 
            or this.data.ipc_pwd_txt == ""  then
            -- popups.show_popups("请输入IPC信息")

            print(this.data.ipc_ip_txt == "",
                            this.data.ipc_name_txt == "",
                            this.data.ipc_user_txt == "" ,
                            this.data.ipc_pwd_txt == "")

            set_data({
                ipc_name_hidden = this.data.ipc_name_txt ~= "",
                ipc_ip_hidden = this.data.ipc_ip_txt ~= "",
                ipc_user_hidden = this.data.ipc_user_txt ~= "",
                ipc_pwd_hidden = this.data.ipc_pwd_txt ~= "",
            })

            return 
        end

        for index, value in ipairs(app.ipc_group) do
            if  index ~= this.data.modify and value.ip  == this.data.ipc_ip_txt then
                popups.show_popups("IP地址已存在")
                return 
            end
        end        

        local ipc_info = {
            name = this.data.ipc_name_txt,
            ip   = this.data.ipc_ip_txt,
            username  = this.data.ipc_user_txt,
            password  = this.data.ipc_pwd_txt,
        }
        -- 保存或修改ipc配置
        if this.data.modify == 0 then
            db.insert_ipc(ipc_info)
        else
            ipc_info.id = app.ipc_group[this.data.modify].id
            db.update_ipc(ipc_info)
        end
        set_page("systemset_ipc")
    end,

    ta_up = function(v)
        set_data({
            ipc_select = true,
            input_hid = false,
            input_info = input_info[v.name],
            input_txt = ""
        })
        t_input_txt = {}
        now_input = v.name
    end,

    btnm_up = function(v)
        btnm_unact = true
        page_act = false
    end,
    btnm_down = function(v)
        btnm_unact = false
    end,

    page_change = function(v, posx, posy)
        if not btnm_unact then
            page_act = true
        end
    end,

    btnm_action = function(v, txt)
        log_info("btnm_action", page_act)
        if page_act == true then 
            page_act = false
            return 
        end

        if txt == kb.del_txt then
            if this.data.input_pinyin ~= "" then
                set_data({input_pinyin = this.data.input_pinyin:sub(1, -2)})
                if this.data.input_pinyin ~= "" then
                    local zh_map = get_zh_by_pinyin(this.data.input_pinyin)
                    set_data({slideposx = 0, zh_w = #zh_map * 80, zh_map = zh_map, zh_ctrl = get_zh_ctrl(#zh_map)})
                else
                    set_data({slideposx = 0, zh_w = 0, zh_map = {}, zh_ctrl = {},})
                end
            elseif #t_input_txt > 0 then
                set_data({input_txt = this.data.input_txt:sub(1, -1 - #t_input_txt[#t_input_txt]) })
                table.remove(t_input_txt, #t_input_txt)
            end
        elseif txt == "确定" then
            -- 连接wifi
            if now_input ~= "ipc_ip" or check_ip(this.data.input_txt) then
                set_data({
                    ipc_select = false,
                    input_hid = true,
                    [now_input .. "_txt"] = this.data.input_txt,
                    zh_hidden = true, input_pinyin = "",
                    [now_input .. "_hidden"] = true
                })
            else
                popups.show_popups("IP地址格式错误")
            end
        elseif txt == "ABC" then
            set_data({ btnm_map = kb.ABC, btnm_map_ctrl = kb.ABC_ctrl, zh_hidden = true, input_pinyin = "", })
        elseif txt == "abc" then
            set_data({ btnm_map = kb.abc, btnm_map_ctrl = kb.abc_ctrl, zh_hidden = true, input_pinyin = "", })
        elseif txt == "中" then
            set_data({ btnm_map = kb.abc, btnm_map_ctrl = kb.abc_ctrl, slideposx = 0, zh_w = 0, zh_map = {}, zh_ctrl = {}, zh_hidden = false, input_pinyin = "", })
        elseif txt == "1#" then
            set_data({ btnm_map = kb.spec, btnm_map_ctrl = kb.spec_ctrl, zh_hidden = true, input_pinyin = "", })
        else
            if not this.data.zh_hidden and 'a' <= txt and txt <= 'z' then
                set_data({input_pinyin = this.data.input_pinyin .. txt })
                local zh_map = get_zh_by_pinyin(this.data.input_pinyin)
                set_data({slideposx = 0, zh_w = #zh_map * 80, zh_map = zh_map, zh_ctrl = get_zh_ctrl(#zh_map)})
            else
                table.insert(t_input_txt, txt)
                set_data({input_txt = this.data.input_txt .. txt })
                if "zh_hidden" == v.name then
                    set_data({slideposx = 0,zh_w = 0, input_pinyin = "", zh_map = {}, zh_ctrl = {}})
                end
            end
        end
    end,

    change_record = function()
        log_line()
    end
}
return controller