local app = get_app()
local STATUS_CHECK_UPDATE = 0

local status = STATUS_CHECK_UPDATE

local controller =
{--[[此版本已最新版本\n无需更新]]
    data = {
        upgrade_info = "",
        upgrade_schedule = "检查更新",
        upgrade_img = "setting/update.png",
        upgrade_hidden = false,
    },

    onload = function()
        set_data({now_set = "软件升级", return_msg = {show_tab = "system_set",}})
        log_debug('systemset/systemset_upgrade onload') 
    end,

    onshow = function()
        log_debug('systemset/systemset_upgrade onshow') 
    end,

    ondestroy = function()
        app.upgrade_url = ""
        log_debug('systemset/systemset_upgrade ondestroy') 
    end,

    popups_select_hidden_action = function(v)
        log_info("popups hidden")
        app.upgrade_url = ""
    end,

    popups_action = function(v) 
        if v.name == "popups_ok" then
            if app.upgrade_url == "" then
                ws.check_upgrade()
            else
                ws.down_upgrade(app.upgrade_url)
            end
        end

        app.upgrade_url = ""
        popups.hidden_popups_with_select()
    end,

    upgrade_action = function()
        if status == STATUS_CHECK_UPDATE then
            if get_app().state.link then
                popups.show_popups_with_select("软件升级", "是否现在检测新版本？", 60)
            else
                popups.show_popups("设备不在线")
            end
        end
    end
}
return controller