local view = {
    {
        type        = "page",
        position    = {align = utils_align.IN_TOP_MID, alignx = 0, aligny = 80},
        attr        = { w = 960, h = 500, c = 0x00303030, c_bar = 0x00808080, hidden = "{{ipc_select}}",
                        layout = utils_page.LAYOUT_OFF, round = true, mode = utils_page.MODE_OFF},
        name        = "page_add"
    },
    {
        type = "text",
        position = {x = 32, y = 32},
        attr ={ w = 240, h = 22, c = 0xffffffff, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT,
                content = "添加网络摄像机", parent = "page_add"},
    },
    {
        type = "text",
        position = {x = 32, y = 114},
        attr ={ w = 240, h = 18, c = 0xffffffff, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT,
                content = "请输入名称", parent = "page_add"},
    },
    {
        type = "textarea",
        position = {x = 156, y = 100},
        attr = {w = 768, h_content = 32, curor = 500, align = 1, radius = 8, parent = "page_add",
                c_content = 0xFFFFFFFF, c = 0xff1d1d1d, c_cursor = 0, content = "{{ipc_name_txt}}",single = true}, 
        action      = {bind = {up = "ta_up"}},
        name = "ipc_name",
    },
    {
        type = "text",
        position = {x = 160, y = 156},
        attr ={ w = 240, h = 15, c = 0xffff0000, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT, hidden = "{{ipc_name_hidden}}",
                content = "请输入名称", parent = "page_add"},
    },

    {
        type = "text",
        position = {x = 32, y = 190},
        attr ={ w = 240, h = 18, c = 0xffffffff, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT,
                content = "请输入IP号", parent = "page_add"},
    },
    {
        type = "textarea",
        position = {x = 156, y = 178},
        attr = {w = 768, h_content = 32, curor = 500, align = 1, radius = 8, parent = "page_add",
                c_content = 0xFFFFFFFF, c = 0xff1d1d1d, c_cursor = 0, content = "{{ipc_ip_txt}}",single = true}, 
        action      = {bind = {up = "ta_up"}},
        name = "ipc_ip",
    },
    {
        type = "text",
        position = {x = 160, y = 234},
        attr ={ w = 240, h = 15, c = 0xffff0000, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT, hidden = "{{ipc_ip_hidden}}",
                content = "请输入IP地址", parent = "page_add"},
    },

    {
        type = "text",
        position = {x = 32, y = 270},
        attr ={ w = 240, h = 18, c = 0xffffffff, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT,
                content = "请输入用户名", parent = "page_add"},
    },
    {
        type = "textarea",
        position = {x = 156, y = 256},
        attr = {w = 768, h_content = 32, curor = 500, align = 1, radius = 8, parent = "page_add",
                c_content = 0xFFFFFFFF, c = 0xff1d1d1d, c_cursor = 0, content = "{{ipc_user_txt}}",single = true}, 
        action      = {bind = {up = "ta_up"}},
        name = "ipc_user",
    },
    {
        type = "text",
        position = {x = 160, y = 312},
        attr ={ w = 240, h = 15, c = 0xffff0000, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT, hidden = "{{ipc_user_hidden}}",
                content = "请输入用户名", parent = "page_add"},
    },

    {
        type = "text",
        position = {x = 32, y = 348},
        attr ={ w = 240, h = 18, c = 0xffffffff, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT,
                content = "请输入密码", parent = "page_add"},
    },
    {
        type = "textarea",
        position = {x = 156, y = 334},
        attr = {w = 768, h_content = 32, curor = 500, align = 1, radius = 8, parent = "page_add",
                c_content = 0xFFFFFFFF, c = 0xff1d1d1d, c_cursor = 0, content = "{{ipc_pwd_txt}}",single = true}, 
        action      = {bind = {up = "ta_up"}},
        name = "ipc_pwd",
    },
    {
        type = "text",
        position = {x = 160, y = 390},
        attr ={ w = 240, h = 15, c = 0xffff0000, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT, hidden = "{{ipc_pwd_hidden}}",
                content = "请输入密码", parent = "page_add"},
    },

    {
        type        = "page",
        position    = {align = utils_align.IN_TOP_MID, alignx = 0, aligny = 85},
        attr        = {w = 960, h = 68, c = 0xff1d1d1d, c_bar = 0x00808080, layout = utils_page.LAYOUT_OFF,
                       round = true, mode = utils_page.MODE_AUTO, hidden = "{{input_hid}}"},
        name        = "page0",
    },
    {
        type = "text",
        position = {align = utils_align.IN_TOP_LEFT, aligny = 110, alignx = 63},
        attr ={ w = 140, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT, 
                c = 0xffffffff, content = "{{input_info}}", hidden = "{{input_hid}}"},
        name = "pwd_txt"
    },
    {
        type = "textarea",
        position = {align = utils_align.OUT_RIGHT_MID, alignx = 0, aligny = 0, ref = "pwd_txt"},
        attr = {w = 700, h_content = 26, curor = 500, --[[max = 6,]] align = 0, radius = 8, hidden = "{{input_hid}}",
                c_content = 0xFFFFFFFF, c = 0xff1d1d1d, c_cursor = 0x00FFFFFF, content = "{{input_txt}}",single = true}, 
        action      = {bind = {up = "ta_change"}},
    },
    {
        type = "btnm",
        position = {align = utils_align.IN_TOP_MID, alignx = 0, aligny = 280,},
        attr =
        {
            w = 1016, h = 410, h_content = 25, hidden = "{{input_hid}}",
            -- 背景，按键常态，按键按下，按键禁用，按键选中的颜色
            c = 0x00ffffff, c_def = 0xff1d1d1d, c_clk = 0xff526178, c_dis = 0xff808080, c_chk = 0xff526178, radius = 8,
            -- 文本，文本按下，文本禁用，文本选中的颜色
            c_content = 0xffffffff, c_content_clk = 0xffffffff, c_content_dis = 0xff000000, c_content_chk = 0xffffffff,
            map = "{{btnm_map}}",
            map_ctrl = "{{btnm_map_ctrl}}",
        },
        action = {bind = {change = "btnm_action"}},
    },
    {
        type = "img",
        position = {x = 948, y = 423},
        attr = {res = "setting/del.png", hidden = "{{input_hid}}",}
    },
    {
        type = "shared",
        attr = {file = "shared_btn", func = "ctrl_btn", 
                obj = {x = 786, y = 420, name = "save", parent = "page_add",
                        rel = "setting/btn_ok.png", act_up = "add_ipc",
                        content = "确定"}},
    },
    {
        type        = "page",
        position    = {align = utils_align.IN_TOP_MID, alignx = 0, aligny = 200},
        attr        = {w = 956, h = 80, c = 0x00000000, c_bar = 0x00808080, layout = utils_page.LAYOUT_ROW_MID, hidden= "{{zh_hidden}}", slideposx = "{{slideposx}}",
                       round = false, mode = utils_page.MODE_OFF},
        name        = "page0",
        action       = {bind = {change = "page_change", up = "page_up"}}
    },
    {
        type = "btnm",
        position = {align = utils_align.IN_TOP_MID, alignx = 0, aligny = 280,},
        attr =
        {
            w = "{{zh_w}}", h = 50, h_content = 25, parent = "page0",
            -- 背景，按键常态，按键按下，按键禁用，按键选中的颜色
            c = 0, c_def = 0, c_clk = 0, c_dis = 0, c_chk = 0, radius = 0,
            -- 文本，文本按下，文本禁用，文本选中的颜色
            c_content = 0xffffffff, c_content_clk = 0xffffffff, c_content_dis = 0xff000000, c_content_chk = 0xffffffff,
            map = "{{zh_map}}",
            map_ctrl = "{{zh_ctrl}}"
        },
        action = {bind = {change = "btnm_action", up = "btnm_up", down = "btnm_down"}},
        name = "zh_hidden"
    },
    {
        type = "text",
        position    = {align = utils_align.IN_TOP_LEFT, alignx = 34, aligny = 200},
        attr ={ w = 140, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT, 
                c = 0xffffffff, content = "{{input_pinyin}}", hidden = "{{zh_hidden}}"},
    },
}


return view
