local app = get_app()

local controller =
{
    data = {
        input_ip = app.cloud.server_url,
        curor_time = 0
    },
    onload = function()
        set_data({return_page = "setting", 
                  now_set = "服务器设置", return_msg = {show_tab = "system_set",}})
        log_debug('systemset/system_webip onload') 
    end,
    onshow = function()
        log_debug('systemset/system_webip onshow') 
    end,
    ondestroy = function()
        log_debug('systemset/system_webip ondestroy') 
    end,

    ta_change = function(v)
        set_data({
            input_ip = "",
            curor_time = 500
        })
    end,

    btnm_action = function(v, txt)
        if this.data.curor_time == 0 then return end

        if txt == " " then
            set_data({input_ip = this.data.input_ip:sub(1, -2) })
        elseif txt == "确定" then
            if check_ip(this.data.input_ip) then
                popups.show_popups("设置成功")
                app.cloud.server_url = this.data.input_ip
                db.set_cloud(app.cloud)

                reboot()
            else
                popups.show_popups("格式错误")
            end
        elseif txt == "取消" then
            set_page("setting", {show_tab = "system_set",})
        elseif this.data.input_ip:len() < 15 then
            set_data({input_ip = this.data.input_ip .. txt })
        end
    end
}
return controller