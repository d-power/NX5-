local app = get_app()
local _list_map = {}
local security_group = {}

local ret_timeout = 0

-- 同步数据库
get_security_info(db.get_security())

if app.security_group then
    for i = 1, #app.security_group do
        table.insert(_list_map, app.area_map[app.security_group[i].area + 1])
        table.insert(_list_map, app.type_map[app.security_group[i].type + 1])
        table.insert(_list_map, app.state_map[app.security_group[i].onoff + 1] ~= "未启用" and get_recolor_str("启用", 0x00ff00) or "禁用")
        table.insert(_list_map, app.level_map[app.security_group[i].level + 1] ~= "常开" and get_recolor_str("常闭", 0x00ff00) or "常开")
        table.insert(_list_map, "setting/list_line.png")
    end
end

for index, security in ipairs(app.security_group) do
    security_group[index] = {}
    for key, value in pairs(security) do
        security_group[index][key] = value
    end
end

local controller =
{
    data = {
        list_map = _list_map
    },
    onload = function()
        set_data({now_set = "安防设置", return_msg = {show_tab = "system_set",}})
        log_debug('systemset/systemset_security onload') 
    end,
    onshow = function()
        log_debug('systemset/systemset_security onshow') 
    end,
    ondestroy = function()
        log_debug('systemset/systemset_security ondestroy') 
    end,
    config_act = function()
        --[[
            for index, value in ipairs(app.security_group) do
                -- 判断延时防区
                if value.type > 2 then
                    if value.state == app.security.state.on then
                        popups.show_popups("已布防，请先撤防！")
                        return
                    end
                end
            end
        ]]

        -- 保存配置
        local save_param = {security_param = security_group}
        log_info(encode(save_param))
        log_debug(db.set_security(encode(save_param)))
        if db.set_security(encode(save_param)) == 0 then
            ret_timeout = 30
            popups.show_popups("设置成功")
        else
            popups.show_popups("设置失败")
        end
        get_security_info(db.get_security())
    end,

    timer = function()
        if ret_timeout > 0 then
            ret_timeout = ret_timeout - 1
            if ret_timeout == 0 then
                set_page(common.set_bar.data.return_page, common.set_bar.data.return_msg)
                common.set_bar.data.return_msg = nil
            end
        end
    end,

    list_up = function(v, _ver, _hor)
        local ver = tonumber(_ver)
        local hor = tonumber(_hor)

        log_debug(ver, hor)

        if hor == 1 then
            for i = 1, #app.area_map do
                if app.area_map[i] == _list_map[(ver - 1) * 5 + hor] then
                    if i == #app.area_map then i = 0 end
                    _list_map[(ver - 1) * 5 + hor] = app.area_map[i + 1]
                    security_group[ver].area = i
                    break
                end
            end
        elseif hor == 2 then
            for i = 1, #app.type_map do
                if app.type_map[i] == _list_map[(ver - 1) * 5 + hor] then
                    if i == #app.type_map then i = 0 end
                    _list_map[(ver - 1) * 5 + hor] = app.type_map[i + 1]
                    security_group[ver].type = i
                    break
                end
            end
        elseif hor == 3 then
            _list_map[(ver - 1) * 5 + hor] = _list_map[(ver - 1) * 5 + hor] == "禁用" and get_recolor_str("启用", 0x00ff00) or "禁用"
            security_group[ver].onoff = _list_map[(ver - 1) * 5 + hor] == "禁用" and 0 or 1
        elseif hor == 4 then
            _list_map[(ver - 1) * 5 + hor] = _list_map[(ver - 1) * 5 + hor] == "常开" and get_recolor_str("常闭", 0x00ff00) or "常开"
            security_group[ver].level = _list_map[(ver - 1) * 5 + hor] == "常开" and 1 or 0
        end

        set_data({list_map = _list_map})

    end

}
return controller