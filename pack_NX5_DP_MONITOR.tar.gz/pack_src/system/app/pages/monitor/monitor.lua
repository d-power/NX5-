
local door_selected = ""
local ipc_select = ""
local now_monitor = "wallDoor"
local now_monitor_door = ""
local now_monitor_addr = ""
local captureing = false

local app = get_app()
local monitor_timeout = 0

local monitor_map = {
    "monitor/monitor_selete.png", "monitor/door_img.png", "monitor/line.png", "围墙机", "Wall Machine",
    "monitor/monitor_rel.png", "monitor/door_img.png", "monitor/line.png", "门口机", "Door Phone",
    "monitor/monitor_rel.png", "monitor/door_img.png", "monitor/line.png", "车闸机", "Car Brake",
    "monitor/monitor_rel.png", "monitor/door_img.png", "monitor/line.png", "外梯控机", "External ladder control",
    "monitor/monitor_rel.png", "monitor/door_img.png", "monitor/line.png", "内梯控机", "Internal ladder control",
    "monitor/monitor_rel.png", "monitor/ipc_img.png",  "monitor/line.png", "IPC（摄像头）", "IPC (camera)",
}

--[[
    围墙机为wallDoor，单元机为unitDoor，
    车闸机为parkingDoor，保安分机为securityDev，
    保安小叮为securityHandhold，梯内梯控机为liftInside，
    梯外梯控机为liftOutside，一键紧急呼叫为oneKey
]]
local now_monitor_tab = {"wallDoor", "unitDoor", "parkingDoor", "liftInside", "liftOutside", "ipcamera"}

local monitor_tab = {
    wallDoor = {},
    unitDoor = {},
    parkingDoor = {},
    liftInside = {},
    liftOutside = {},
    ipcamera = {}
}

app.ipc_group = decode(db.get_ipc() or "{}").ipc_record or {}

local function door_selected_refresh()
    door_selected = ""
    
    table.print(app.door_list)

    monitor_tab.wallDoor = {}
    monitor_tab.unitDoor = {}
    monitor_tab.parkingDoor = {}
    monitor_tab.liftInside = {}
    monitor_tab.liftOutside = {}
    monitor_tab.ipcamera = {}

    for i = 1, #app.ipc_group do
        monitor_tab.ipcamera[i] = app.ipc_group[i]
    end

    for i = 1, #app.door_list do
        local kind = app.door_list[i].kind
        monitor_tab[kind][#monitor_tab[kind] + 1] = app.door_list[i]
    end
end

local function update_door_selected()
    door_selected_refresh()

    table.print(monitor_tab)

    for index, value in ipairs(monitor_tab[now_monitor]) do
        if door_selected == "" then
            door_selected = value.name
        else
            door_selected = door_selected .. "\n" .. value.name
        end
    end

    local opt = 0
    for index, value in ipairs(monitor_tab[now_monitor]) do
        if value.name == now_monitor_door then
            opt = index - 1
            break
        end
    end

    for i = 1, #now_monitor_tab do
        print(now_monitor_tab[i], now_monitor)
        if now_monitor_tab[i] == now_monitor then
            monitor_map[(i - 1) * 5 + 1] = "monitor/monitor_selete.png"
        else
            monitor_map[(i - 1) * 5 + 1] = "monitor/monitor_rel.png"
        end
    end

    set_data({
        selected = door_selected, opt = opt,
        list_map = monitor_map
    })
end

door_selected_refresh()

table.print(monitor_map)

local controller =
{
    data = {
        selected = door_selected,
        opt = 0,
        monitor_start = false,

        no_screen_off = false,

        list_map = monitor_map
    },
    onload = function()
        set_data({now_set = "监视中心", return_page = "home", return_msg = {show_act = 1}})

        if this.data.monitor_start then
            for index, value in ipairs(app.door_list) do
                if value.name == app.monitor_quick.name then
                    now_monitor = value.kind
                    break
                end
            end
            if app.call_info.session_id ~= -1 then
                phone.hangup(app.call_info.session_id)
            end
            set_data({no_screen_off = true})
            app.call_info.session_id = phone.monitor(app.monitor_quick.sn)
            now_monitor_door = app.monitor_quick.name
            now_monitor_addr = app.monitor_quick.community .. app.monitor_quick.addr
            
            update_door_selected()

        elseif #app.door_list > 0 then
            now_monitor_door = app.door_list[1].name
            now_monitor_addr = app.door_list[1].community .. app.door_list[1].addr
        end
        log_debug('monitor/monitor onload') 
    end,
    onshow = function()
        log_debug('monitor/monitor onshow') 
    end,
    ondestroy = function()
        if now_monitor == "ipc" then
            cfun.ipc("hangup")
        end

        if (app.call_info.session_id ~= -1) then
            phone.hangup(app.call_info.session_id)
            app.call_info.session_id = -1
        end
        log_debug('monitor/monitor ondestroy') 
    end,

    timer = function(v)
        if this.data.no_screen_off == true then
            if monitor_timeout == 0 then monitor_timeout = 600 end
            monitor_timeout = monitor_timeout - 1
            if monitor_timeout == 0 then

                if now_monitor == "ipcamera" then
                    cfun.ipc("hangup")
                end
        
                if (app.call_info.session_id ~= -1) then
                    phone.hangup(app.call_info.session_id)
                    app.call_info.session_id = -1
                end

                set_data({no_screen_off = false})
                lgui_screensaver_reset()
            end
        else
            monitor_timeout = 0
        end
    end,

    callring = function()
        if (app.call_info.session_id ~= -1) then
            phone.hangup(app.call_info.session_id)
            app.call_info.session_id = -1
        end
    end,

    door_list_refresh = function(v)
        if now_monitor == "ipcamera" then return end
        log_debug("update door list")
        update_door_selected()
    end,

    phone_capture = function ()
        log_debug("start capture")
        if now_monitor == "ipcamera" then
            ipc.photo(now_monitor_addr)
        else
            local result = phone.capture(app.call_info.session_id, now_monitor_addr)
            if result > 0 then
                popups.show_popups("拍照失败")
            end
        end

    end,

    capture_ack = function()
        popups.show_popups("拍照成功")
    end,

    monitor_ack = function(result)
        if result.result == "fail" then
            if result.reason == "device offline" then
                popups.show_popups("设备不在线")
            else
                popups.show_popups("监视失败")
            end
            phone.hangup(app.call_info.session_id)
            app.call_info.session_id = -1
        end
        set_data({no_screen_off = false})
    end,

    choose_monitor = function(v, _index, str) 
        log_debug("select index: " .. _index .." str:".. str) 
        local index = tonumber(_index)

        set_data({no_screen_off = true})

        if now_monitor == "ipcamera" then
            ipc.hangup()
            index = index + 1
            if app.ipc_group[index] then
                ipc.monitor(app.ipc_group[index].ip, app.ipc_group[index].username, app.ipc_group[index].password)
                now_monitor_addr = app.ipc_group[index].name
            end
            return 
        end

        if app.call_info.session_id ~= -1 then
            log_debug("hangup monitor")
            phone.hangup(app.call_info.session_id)
        end

        if type(monitor_tab[now_monitor][index + 1]) == "table" then
            local now_to_monitor = monitor_tab[now_monitor][index + 1]
            app.call_info.session_id = phone.monitor(now_to_monitor.sn)
            if app.call_info.session_id ~= -1 then
                app.monitor_quick.addr = now_to_monitor.addr
                app.monitor_quick.sn   = now_to_monitor.sn
                app.monitor_quick.name = now_to_monitor.name
                app.monitor_quick.community = now_to_monitor.community
            end
            now_monitor_door = now_to_monitor.name
            now_monitor_addr = now_to_monitor.community .. now_to_monitor.addr
        end
    end,

    monitor_change = function(v, _line)
        local line = tonumber(_line)

        if (app.call_info.session_id ~= -1) then
            phone.hangup(app.call_info.session_id)
        end

        now_monitor = now_monitor_tab[line]
        update_door_selected()

        if now_monitor ~= "ipcamera" then
            ipc.hangup()
        end

    end,
}
return controller