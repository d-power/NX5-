local view = {
    {
        type = "img",
        position = {align = utils_align.IN_TOP_MID, aligny = 100 },
        attr = {res = "monitor/monitor_bg.png",},
        name = "monitor_bg"
    },
    {
        type = "vdec",
        position = {align = utils_align.IN_RIGHT_MID, alignx = -4},
        attr = {w = 716, h = 464, parent = "monitor_bg"}
    },
    {
        type = "img",
        position = {x = 258, y = 20},
        attr = {res = "monitor/combobox_bg.png", parent = "monitor_bg"},
    },
    {
        type = "combobox",
        position = {x = 258, y = 20},
        attr = {w = 124, h = 36, h_max = 128, h_content = 16, c_content = 0xFFFFFFFF, dir = utils_combobox.DIR_DOWN,
            c = 0x00808080, c_slt = 0x003c3c3c,c_bar = 0, c_clk = 0x000000ff, res = "monitor/down.png",
            content = "{{selected}}", opt = "{{opt}}", parent = "monitor_bg"
        },
        action = {bind = {change = "choose_monitor"}},
    },

    {
        type = "list",
        position = {x = 10, y = 0},
        attr =
        {
            w = 210, h = 464, h_line = 116, c = 0x00bcc3cd, c_def = 0x00000000, c_clk = 0x00000000, keep = true, c_bar = 0x00000000,
            slidepos = 0, c_edge = 0x00ff0000, parent = "monitor_bg",
            map_ctrl =
            {
                {
                    type = utils_list.TYPE_IMG, x = 0, y = 0
                },
                {
                    type = utils_list.TYPE_IMG, x = 18, y = 35
                },
                {
                    type = utils_list.TYPE_IMG, x = 0, y = 463
                },
                {
                    type = utils_list.TYPE_TEXT, x = 78, y = 35, w = 200, h = 30, c = 0xffffffff,
                    content_h = 20, content_algin = utils_list.TEXT_ALIGN_LEFT, content_mode = utils_list.TEXT_MODE_DOT,
                },
                {
                    type = utils_list.TYPE_TEXT, x = 78, y = 68, w = 200, h = 20, c = 0xffffffff,
                    content_h = 12, content_algin = utils_list.TEXT_ALIGN_LEFT, content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
            },
            map = "{{list_map}}"
        },
        action = {bind = {change = "list", up = "monitor_change"}}
    },

    -- {
    --     type = "btn",
    --     position = {x = 0, y = 0 },
    --     attr = {res_rel = "monitor/monitor_selete.png", parent = "monitor_bg"},
    --     action = {bind = {up = "monitor_change"}},
    --     name = "door"
    -- },
    -- {
    --     type = "img",
    --     position = {align = utils_align.IN_LEFT_MID, alignx = 28 },
    --     attr = {res = "monitor/door_img.png", parent = "door"},
    -- },
    -- {
    --     type = "text",
    --     position = {align = utils_align.IN_LEFT_MID, alignx = 88, aligny = -8 },
    --     attr = {
    --         w = 140, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT, parent = "door",
    --         c = 0xffffffff, content = "门口机", }
    -- },
    -- {
    --     type = "text",
    --     position = {align = utils_align.IN_LEFT_MID, alignx = 88, aligny = 20 },
    --     attr = {
    --         w = 140, h = 12, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT, parent = "door",
    --         c = 0xffffffff, content = "Door Phone", }
    -- },
    
    -- {
    --     type = "btn",
    --     position = {x = 0, y = 116 },
    --     attr = {res_rel = "monitor/monitor_rel.png", parent = "monitor_bg"},
    --     action = {bind = {up = "monitor_change"}},
    --     name = "ipc"
    -- },
    -- {
    --     type = "img",
    --     position = {align = utils_align.IN_LEFT_MID, alignx = 28 },
    --     attr = {res = "monitor/ipc_img.png", parent = "ipc"},
    -- },
    -- {
    --     type = "text",
    --     position = {align = utils_align.IN_LEFT_MID, alignx = 88, aligny = -8 },
    --     attr = {
    --         w = 140, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT, parent = "ipc",
    --         c = 0xffffffff, content = "IPC（摄像头）", }
    -- },
    -- {
    --     type = "text",
    --     position = {align = utils_align.IN_LEFT_MID, alignx = 88, aligny = 20 },
    --     attr = {
    --         w = 140, h = 12, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT, parent = "ipc",
    --         c = 0xffffffff, content = "IPC (camera)", }
    -- },

    -- {
    --     type = "btn",
    --     position = {x = 0, y = 116 },
    --     attr = {res_rel = "monitor/monitor_rel.png", parent = "monitor_bg"},
    --     action = {bind = {up = "monitor_change"}},
    --     name = "ipc"
    -- },
    -- {
    --     type = "img",
    --     position = {align = utils_align.IN_LEFT_MID, alignx = 28 },
    --     attr = {res = "monitor/ipc_img.png", parent = "ipc"},
    -- },
    -- {
    --     type = "text",
    --     position = {align = utils_align.IN_LEFT_MID, alignx = 88, aligny = -8 },
    --     attr = {
    --         w = 140, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT, parent = "ipc",
    --         c = 0xffffffff, content = "IPC（摄像头）", }
    -- },
    -- {
    --     type = "text",
    --     position = {align = utils_align.IN_LEFT_MID, alignx = 88, aligny = 20 },
    --     attr = {
    --         w = 140, h = 12, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT, parent = "ipc",
    --         c = 0xffffffff, content = "IPC (camera)", }
    -- },
    {
        type = "btn",
        position = {x = 900, y = 376 },
        attr = {res_rel = "monitor/photograph.png", parent = "monitor_bg"},
        action = {bind = {up = "phone_capture"}},
        name = "photograph"
    },
    {
        type = "text",
        position = {align = utils_align.OUT_BOTTOM_MID, alignx = 0, aligny = 6, ref = "photograph"},
        attr = {
            w = 50, h = 16, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER,
            c = 0xffffffff, content = "拍照", }
    },
}
return view