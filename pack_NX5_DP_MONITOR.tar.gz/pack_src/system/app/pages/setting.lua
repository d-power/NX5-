local text_color = { 0xFFF7C754, 0xFFFFFFFF }

local tab_act = {"setting/tab_select.png", "setting/tab_noselect.png"}

local controller =
{
    data =
    {
        user_set_color = text_color[1],
        system_set_color = text_color[2],
        bar_x = 90,

        user_set_hidden  = false,
        system_set_hidden  = true,

        tab_select1 = tab_act[1],
        tab_select2 = tab_act[2],

        user_tab_show = 0,

        show_tab = "user_set",
    },

    onload = function()
        set_data({now_set = "设置", return_page = "home", return_msg = {}})
        if this.data.show_tab == "system_set" then
            set_data({
                bar_x = 208,
                user_set_color = text_color[2],
                system_set_color = text_color[1],
                system_set_hidden = false,
                user_set_hidden  = true,
            })
        else
            set_data({
                tab_select1 = tab_act[this.data.user_tab_show == 0 and 1 or 2],
                tab_select2 = tab_act[this.data.user_tab_show == 1 and 1 or 2], 
            })
        end
        log_info("setting onload")
    end,

    onshow = function()
        log_info("setting onshow")
    end,

    ondestroy = function()
        log_info("setting ondestroy")
    end,

    goto_next_page = function(v)
        log_debug("next page is " .. v.name)
        set_data({return_page = "setting"})
        set_page(v.name)
    end,

    tab_act = function(v, tab)
        set_data({
            tab_select1 = tab_act[(tab == "0") and 1 or 2],
            tab_select2 = tab_act[(tab == "0") and 2 or 1]
        })
        log_debug(this.data.tab_select1, this.data.tab_select2)
    end,

    change_set = function(v)
        if v.name == "user_set" then
            set_data({
                user_set_color = text_color[1],
                system_set_color = text_color[2],
                bar_x = 90,
                user_set_hidden  = false,
                system_set_hidden  = true,
            })
        elseif v.name == "system_set" then
            set_data({return_page = "setting"})
            set_page("input_pwd")
        end
    end
}

return controller
