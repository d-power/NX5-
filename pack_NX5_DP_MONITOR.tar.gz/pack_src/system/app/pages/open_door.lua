
local time_out = {}
local app = get_app()
local now_open_list = {}

local controller =
{
    data = {
        now_open_list = {}
    },
    onload = function()
        set_data({now_set = "一键开门", return_page = "home", return_msg = {show_act = 1}})
        log_debug('open_door onload') 
    end,
    onshow = function()
        log_debug('open_door onshow') 
    end,
    ondestroy = function()
        log_debug('open_door ondestroy') 
    end,

    open_door_act = function(v)
        if this.data["state_img" .. v.user_data.index] ~= "open_success.png" then
            log_info("want to open door", app.door_list[v.user_data.index].community, app.door_list[v.user_data.index].addr)
            ws.unlock(app.door_list[v.user_data.index].sn)
            table.insert(now_open_list, v.user_data.index)
        end
    end,

    door_list_refresh = function(v)
        set_page("open_door")
    end,

    unlock_result = function(result)
        if result == "ok" then
            set_data({
                ["state_img" .. now_open_list[1]] = "open_success.png",
                ["state_content" .. now_open_list[1]] = "已开门"
            })
            app.open_quick.addr = app.door_list[now_open_list[1]].addr
            app.open_quick.sn   = app.door_list[now_open_list[1]].sn
            time_out[#time_out + 1] = {index = now_open_list[1], timeout = 30}
        elseif result == "fail" then
            popups.show_popups(get_recolor_str("开门失败!", 0xff0000), 3)
        end
        table.remove(now_open_list, 1)
    end,

    timer = function()
        for index, value in ipairs(time_out) do
            value.timeout = value.timeout - 1
            if value.timeout == 0 then
                set_data({
                    ["state_img" .. value.index] = "open_btn.png",
                    ["state_content" .. value.index] = "开门"
                })
                table.remove(time_out, index)
            end
        end
    end,
}

for i = 1, #app.door_list do
    controller.data["state_img" .. i] = "open_btn.png"
    controller.data["state_content" .. i] = "开门"
end

return controller

