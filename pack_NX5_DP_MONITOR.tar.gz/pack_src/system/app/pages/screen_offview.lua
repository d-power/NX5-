local view = {
    {
        type = "blank",
        position = {x = 0, y = 0},
        attr = { w = 1024, h = 600},
        action = {bind = {up = "back_act"}}
    },
}
return view