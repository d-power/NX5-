
local _wifi_map = {}
local app = get_app()
local wifi_scan_default_timeout = 30*10
local wifi_scan_timeout = 1
local want_to_connect_ssid = ""
local want_to_connect_password = ""
local want_to_connect_security = 0
local want_to_connect_power = ""
local now_wifi_power = ""
local wifi_map = {}

if app.state.wifi then
    
end

local function wifi_map_refresh()
    _wifi_map = {}
    wifi_map = {}
    local j = 1
    for i = 1, #app.wifi_map do
        if app.state.wifi and app.net.wifi_name == app.wifi_map[i].ssid then 
            now_wifi_power =  app.wifi_map[i].security > 0 and "setting/wifi_pwd_".. (app.wifi_map[i].signal + 1) ..".png" 
                                                            or "setting/wifi_nopwd_".. (app.wifi_map[i].signal + 1) ..".png"
            if this and this.show then
                set_data({now_wifi_power = now_wifi_power})
            end
        else
            _wifi_map[#_wifi_map + 1] = app.wifi_map[i].ssid
            _wifi_map[#_wifi_map + 1] = app.wifi_map[i].security > 0 and "setting/wifi_pwd_".. (app.wifi_map[i].signal + 1) ..".png" 
                                                                    or "setting/wifi_nopwd_".. (app.wifi_map[i].signal + 1) ..".png"
            _wifi_map[#_wifi_map + 1] = "setting/list_line.png"           
            
            wifi_map[j] = app.wifi_map[i]

            j = j + 1
        end
    end
end

wifi_map_refresh()

local controller =
{
    data = {
        select = false,
        input_pwd_hid = true,
        input_pwd = "",

        btnm_map = kb.abc,
        btnm_map_ctrl = kb.abc_ctrl,

        WIFI_name = app.state.wifi and app.net.wifi_name or "未连接WIFI",

        now_wifi_power = now_wifi_power,

        no_screen_off = false,

        wifi_map = _wifi_map,
    },

    onload = function()
        set_data({now_set = "WiFi配网", return_msg = {user_tab_show = 0}})
        log_debug('user_setting/setting_wifi onload') 
    end,
    onshow = function()
        log_debug('user_setting/setting_wifi onshow') 
    end,
    ondestroy = function()
        log_debug('user_setting/setting_wifi ondestroy') 
    end,

    list_up = function(v, _index)
        local index = tonumber(_index)
        set_data({now_set = wifi_map[index].ssid, input_pwd_hid = false, select = true, input_pwd = ""})
        want_to_connect_ssid = wifi_map[index].ssid
        want_to_connect_security = wifi_map[index].security
        want_to_connect_power = wifi_map[index].security > 0 and "setting/wifi_pwd_".. (wifi_map[index].signal + 1) ..".png" 
                                or "setting/wifi_nopwd_".. (wifi_map[index].signal + 1) ..".png"
    end,

    btnm_action = function(v, txt)
        if txt == kb.del_txt then
            set_data({input_pwd = this.data.input_pwd:sub(1, -2) })
        elseif txt == "确定" then
            -- 连接wifi
            want_to_connect_password = this.data.input_pwd
            
            log_info(want_to_connect_ssid, want_to_connect_password, want_to_connect_security)
            set_data({ no_screen_off = true, })
            wifi.sta.connect(want_to_connect_ssid, want_to_connect_password, want_to_connect_security)

            popups.show_popups("正在连接WiFi...", 100000)
        elseif txt == "中" then
        elseif txt == "ABC" then
            set_data({ btnm_map = kb.ABC, btnm_map_ctrl = kb.ABC_ctrl, })
        elseif txt == "abc" then
            set_data({ btnm_map = kb.abc, btnm_map_ctrl = kb.abc_ctrl, })
        elseif txt == "1#" then
            set_data({ btnm_map = kb.spec, btnm_map_ctrl = kb.spec_ctrl, })
        elseif this.data.input_pwd:len() < 64 then
            set_data({input_pwd = this.data.input_pwd .. txt })
        end
    end,

    timer = function()
        wifi_scan_timeout = wifi_scan_timeout - 1
        if wifi_scan_timeout == 0 then
            wifi.sta.scan()
        end
    end,

    scan_result = function()
        wifi_map_refresh()
        set_data({wifi_map = _wifi_map})
        wifi_scan_timeout = wifi_scan_default_timeout
    end,

    wifi_state_change = function(state)
        wifi_map_refresh()
        set_data({
            wifi_map = _wifi_map,
            now_wifi_power = app.state.wifi and want_to_connect_power or "",
            WIFI_name = app.state.wifi and app.net.wifi_name or "未连接WIFI",
        })
    end,

    connect_result = function(ch_errno)
        if ch_errno ~= "WIFI连接已断开!" then
            popups.show_popups(ch_errno)
        end
        if ch_errno == "WIFI连接成功!" then
            app.net.wifi_name = want_to_connect_ssid
            app.net.wifi_password = want_to_connect_password
            app.net.wifi_security =  want_to_connect_security
            app.state.wifi = true
            wifi_map_refresh()
            db.set_net(app.net)
            set_data({
                wifi_map = _wifi_map,
                now_set = "WiFi配网",
                input_pwd_hid = true, select = false,
                no_screen_off = false,
                now_wifi_power = app.state.wifi and want_to_connect_power or "",
                WIFI_name = app.state.wifi and app.net.wifi_name or "未连接WIFI",
            })
        else
            if this.data.input_pwd_hid == false then
                app.state.wifi = false
                app.state.link = false
                set_data({
                    no_screen_off = false,
                    input_pwd = ""
                })
            end
        end
        lgui_screensaver_reset()
        wifi_scan_timeout = wifi_scan_default_timeout
    end,

    ret_act = function()
        if this.data.input_pwd_hid == false then
            set_data({
                now_set = "WiFi配网",
                no_screen_off = false,
                input_pwd_hid = true, select = false,
                now_wifi_power = app.state.wifi and want_to_connect_power or "",
                WIFI_name = app.state.wifi and app.net.wifi_name or "未连接WIFI",
            })
            return true
        end
        return false
    end,
}

return controller
