local view = {
    {
        type = "shared",
        attr = {file = "shared_btn", func = "ctrl_btn", 
                obj = {x = 852, y = 512, name = "save", 
                        rel = "setting/btn_ok.png", act_up = "config_act",
                        content = "保存"}},
    },
    -- {
    --     type = "shared",
    --     attr = {file = "shared_btn", func = "ctrl_btn", 
    --             obj = {x = 680, y = 512, name = "cancel", 
    --                     rel = "setting/btn_cancel.png", act_up = "config_act",
    --                     content = "取消"}},
    -- },
}

local delay_config = {
    {name = "armed",       min = "10",  max = "99",  content = "布防延时"},
    {name = "alarm",       min = "0",   max = "120", content = "报警延时"},
    {name = "alarm_ring",  min = "180", max = "600", content = "报警音持续时间"},
    {name = "call",        min = "10",  max = "60",  content = "被呼延时"},
    {name = "screen",      min = "10",  max = "60",  content = "屏保时间"},
}


for i = 1, #delay_config do
    view[#view + 1] = {
        type = "shared",
        attr = {file = "shared", func = "shared_delay", 
                obj = {
                    x = 300, y = 120 + (i - 1) * 74, min = delay_config[i].min, max = delay_config[i].max,
                    w = 400, name = delay_config[i].name, content = delay_config[i].content},}
    }
end

return view

