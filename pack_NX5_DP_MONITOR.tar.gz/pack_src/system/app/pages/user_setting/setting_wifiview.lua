local view = {
    {
        type        = "text",
        position    = {x = 60, y = 70},
        attr        = {content = "当前连接网络", w = 132, h = 20, c = 0xffffffff, hidden = "{{select}}",
                         mode = utils_text.MODE_DOT, align = utils_text.ALIGN_LEFT},
    },
    {
        type        = "text",
        position    = {x = 78, y = 110},
        attr        = {content = "{{WIFI_name}}", w = 250, h = 20, c = 0xffffffff, hidden = "{{select}}",
                         mode = utils_text.MODE_DOT, align = utils_text.ALIGN_LEFT},
    },
    {
        type = "img",
        position = {align = utils_align.IN_TOP_MID, aligny = 150},
        attr = {res = "setting/list_line.png", hidden = "{{select}}",},
        name = "setting_bg"
    },
    {
        type = "img",
        position = {x = 906, y = 108},
        attr = {res = "{{now_wifi_power}}", hidden = "{{select}}",},
        name = "setting_bg"
    },
    {
        type        = "text",
        position    = {x = 60, y = 170},
        attr        = {content = "其他网络", w = 132, h = 20, c = 0xffffffff, hidden = "{{select}}",
                         mode = utils_text.MODE_DOT, align = utils_text.ALIGN_LEFT},
    },

    {
        type = "list",
        position = {align = utils_align.IN_TOP_MID, aligny = 200},
        attr =
        {
            w = 896, h = 360, h_line = 80, keep = true, map = "{{wifi_map}}", hidden = "{{select}}",
            c_bar = 0x00000000, c = 0x00000000, c_def = 0x00000000, c_clk = 0x00000000,
            map_ctrl =
            {
                {
                    type = utils_list.TYPE_TEXT, x = 10, y = 36, w = 250, h = 40, c = 0xffffffff,
                    content_h = 22, content_algin = utils_list.TEXT_ALIGN_LEFT, 
                    content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
                -- {
                --     type = utils_list.TYPE_TEXT, x = 250, y = 18, w = 140, h = 40, c = 0xffffffff,
                --     content_h = 20, content_algin = utils_list.TEXT_ALIGN_RIGHT, 
                --     content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                -- },
                {
                    type = utils_list.TYPE_IMG, x = 840, y = 30,
                },
                {
                    type = utils_list.TYPE_IMG, x = 0, y = 79
                },
            },
        },
        action = {bind = {change = "list", up = "list_up"}}
    },

    -- {
    --     type = "img",
    --     position = {align = utils_align.IN_TOP_LEFT, alignx = 31, aligny = 85},
    --     attr = {res = "setting/pwdset_bg.png", hidden = "{{input_pwd_hid}}"}
    -- },
    {
        type        = "page",
        position    = {align = utils_align.IN_TOP_MID, alignx = 0, aligny = 85},
        attr        = {w = 960, h = 68, c = 0xff434343, c_bar = 0x00808080, layout = utils_page.LAYOUT_OFF,
                       round = true, mode = utils_page.MODE_AUTO, hidden = "{{input_pwd_hid}}"},
        name        = "page0",
    },
    {
        type = "text",
        position = {align = utils_align.IN_TOP_LEFT, aligny = 110, alignx = 63},
        attr ={ w = 240, h = 20, c = 0xffffffff, content = "请输入WiFi密码:", hidden = "{{input_pwd_hid}}"},
        name = "pwd_txt"
    },
    {
        type = "textarea",
        position = {align = utils_align.OUT_RIGHT_MID, alignx = 15, aligny = 0, ref = "pwd_txt"},
        attr = {w = 700, h_content = 26, curor = 500, --[[max = 6,]] align = 0, pwd = 500, radius = 8, hidden = "{{input_pwd_hid}}",
                c_content = 0xFFFFFFFF, c = 0xff434343, c_cursor = 0x00FFFFFF, content = "{{input_pwd}}",single = true}, 
        action      = {bind = {up = "ta_change"}},
    },
    {
        type = "btnm",
        position = {align = utils_align.IN_TOP_MID, alignx = 0, aligny = 280,},
        attr =
        {
            w = 1016, h = 410, h_content = 25, hidden = "{{input_pwd_hid}}",
            -- 背景，按键常态，按键按下，按键禁用，按键选中的颜色
            c = 0x00ffffff, c_def = 0xff383838, c_clk = 0xff526178, c_dis = 0xff808080, c_chk = 0xff526178, radius = 8,
            -- 文本，文本按下，文本禁用，文本选中的颜色
            c_content = 0xffffffff, c_content_clk = 0xffffffff, c_content_dis = 0xff000000, c_content_chk = 0xffffffff,
            map = "{{btnm_map}}",
            map_ctrl = "{{btnm_map_ctrl}}",
        },
        action = {bind = {change = "btnm_action"}},
    },
    {
        type = "img",
        position = {x = 948, y = 423},
        attr = {res = "setting/del.png", hidden = "{{input_pwd_hid}}",}
    },
}

return view
