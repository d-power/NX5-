local view = {
    {
        type = "img",
        position = {align = utils_align.IN_TOP_MID, aligny = 160},
        attr = {res = "setting/list_line.png",},
        name = "auto_time"
    },
    {
        type        = "text",
        position    = {align =utils_align.OUT_TOP_LEFT, alignx = 0, aligny = -26, ref = "auto_time"},
        attr        = {content = "自动获取", w = 132, h = 20, c = 0xffffffff},
    },
    {
        type = "btn",
        position = {align = utils_align.OUT_TOP_RIGHT, alignx = -6, aligny = -15, ref = "auto_time"},
        attr = {res_rel = "setting/manual_time.png", res_chk_rel = "setting/auto_time.png", chk = true, state = "{{check_state}}",},
        action = {bind = {up = "auto_change"}}
    },
    {
        type = "blank",
        position = {align = utils_align.IN_TOP_MID, aligny = 176},
        attr = {w = 900, h = 72, hidden = "{{auto_time}}"},
        action = {bind = {up = "goto_set_date"}},
        name = "date_set"
    },
    {
        type = "img",
        position = {align = utils_align.IN_BOTTOM_MID},
        attr = {res = "setting/list_line.png", parent = "date_set"},
    },
    {
        type        = "text",
        position    = {align =utils_align.IN_BOTTOM_LEFT, alignx = 0, aligny = -26},
        attr        = {content = "手动设置", w = 132, h = 20, c = 0xffffffff, parent = "date_set"},
    },
    {
        type = "img",
        position = {align = utils_align.IN_RIGHT_MID, alignx = -20},
        attr = {res = "home/right.png", parent = "date_set"},
    },
}

return view
