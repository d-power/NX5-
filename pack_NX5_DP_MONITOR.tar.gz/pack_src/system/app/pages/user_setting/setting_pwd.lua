local now_input = "old_pwd"
local app = get_app()
local timeout = -1

local controller =
{
    data = {
        old_pwd = "",
        new_pwd = "",
        reset_pwd = "",

        old_cursor = 0xFFFFFFFF,
        new_cursor = 0x00FFFFFF,
        reset_cursor = 0x00FFFFFF,
    },
    onload = function()
        set_data({now_set = "密码设置"})
        log_debug('user_setting/setting_pwd onload') 
    end,
    onshow = function()
        log_debug('user_setting/setting_pwd onshow') 
    end,
    ondestroy = function()
        log_debug('user_setting/setting_pwd ondestroy') 
    end,

    timer = function()
        if timeout > 0 then
            timeout = timeout - 1 
            if timeout == 0 then
                set_page("setting")
            end
        end
    end,
    
    btnm_action = function(v, txt)
        if txt == " " then
            set_data({[now_input] = this.data[now_input]:sub(1, -2) })
        elseif txt == "确定" then
            print(this.data.old_pwd, this.data.new_pwd, this.data.reset_pwd,  app.password.safe_passwd)
            if this.data.new_pwd:len() ~= 6 or this.data.reset_pwd:len() ~= 6 then
                popups.show_popups("请输入六位新密码!")
            else
                if this.data.old_pwd == app.password.safe_passwd then
                    if this.data.new_pwd == this.data.reset_pwd then
                        if this.data.new_pwd ~= this.data.new_pwd:reverse() then
                            app.password.safe_passwd = this.data.new_pwd
                            app.password.hostage_passwd = app.password.safe_passwd:reverse()
                            db.set_password(app.password)
                            popups.show_popups("设置成功")
                            timeout = 30
                        else
                            popups.show_popups("撤防密码不能与挟持密码一致！", 3, 480)
                        end
                    else 
                        popups.show_popups("两次输入的新密码不一致!", 3, 480)
                    end
                else
                    popups.show_popups("密码错误") 
                end
            end

            if timeout <= 0 then
                set_data({
                    old_pwd = "",
                    new_pwd = "",
                    reset_pwd = "",
                    old_cursor = 0xFFFFFFFF,
                    new_cursor = 0x00FFFFFF,
                    reset_cursor = 0x00FFFFFF,
                })
                now_input = "old_pwd"
            end
        elseif this.data[now_input]:len() < 6 then
            set_data({[now_input] = this.data[now_input] .. txt })

            if this.data[now_input]:len() == 6 then
                local change_name = ""
                if now_input == "old_pwd" then
                    change_name = "new"
                elseif now_input == "new_pwd" then
                    change_name = "reset"
                elseif now_input == "reset_pwd" then
                    return
                end

                now_input = change_name .. "_pwd"

                local set__cursor = { old_cursor = 0x00FFFFFF, new_cursor = 0x00FFFFFF, reset_cursor = 0x00FFFFFF}
                set__cursor[change_name .. "_cursor"] = 0xFFFFFFFF
        
                set_data(set__cursor)
            end
        end
    end,

    ta_change = function(v)
        now_input = v.name .. "_pwd"
        log_debug(v.name .. "_cursor")

        local set__cursor = { old_cursor = 0x00FFFFFF, new_cursor = 0x00FFFFFF, reset_cursor = 0x00FFFFFF}
        set__cursor[v.name .. "_cursor"] = 0xFFFFFFFF

        set_data(set__cursor)

    end,
}

return controller
