local SMARTAPP_URL_TEST = "http://dptest.d-power.com.cn/dpyun/miniprogram?type=handhold&sn=%s&network=WIFI"
local SMARTAPP_URL_NORMAL = "http://dpyun.d-power.com.cn/dpyun/miniprogram?type=handhold&sn=%s&network=WIFI"
local MAC = cfun.read_sn()

local view = {
    {
        type = "list",
        position = {x = 60, y = 90},
        attr =
        {
            w = 510, h = 540, h_line = 60, c = 0x00bcc3cd, c_def = 0x00000000, c_clk = 0x00000000, keep = true, c_bar = 0x00000000,
            map = "{{info_map}}", slidepos = 0, c_edge = 0x00ff0000,
            map_ctrl =
            {
                {
                    type = utils_list.TYPE_TEXT, x = 2, y = 22, w = 460, h = 50, c = 0xffffffff,
                    content_h = 18, content_algin = utils_list.TEXT_ALIGN_LEFT, content_mode = utils_list.TEXT_MODE_DOT,
                },
                {
                    type = utils_list.TYPE_IMG, x = 0, y = 59
                },
            },
        },
        action = {bind = {change = "list", up = "list_up"}}
    },
    {
        type = "qrcode",
        position = {align = utils_align.IN_TOP_MID, alignx = 280, aligny = 160},
        attr = {ver = 12, w = 4, content = string.format(SMARTAPP_URL_TEST, MAC)},
        name = "qrcode_img"
    },
    {
        type = "text",
        position = {align = utils_align.OUT_BOTTOM_MID, aligny = 20, ref = "qrcode_img"},
        attr = {
            w = 320, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER,
            c = 0xffffffff, content = string.format("设备MAC:%s", MAC) }
    },
}

return view
