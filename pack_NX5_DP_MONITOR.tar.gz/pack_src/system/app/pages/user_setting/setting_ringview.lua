local view =
{
    {
        type = "list",
        position = {align = utils_align.IN_TOP_MID, aligny = 88},
        attr =
        {
            w = 1024, h = 420, h_line = 70, c = 0x00bcc3cd, c_def = 0x00000000, c_clk = 0x00000000, keep = true, c_bar = 0x00000000,
            map = "{{ring_map}}", slidepos = 0, c_edge = 0x00ff0000, parent = "set_ring",
            map_ctrl =
            {
                {
                    type = utils_list.TYPE_TEXT, x = 62, y = 28, w = 460, h = 50, c = 0xffffffff,
                    content_h = 18, content_algin = utils_list.TEXT_ALIGN_LEFT, content_mode = utils_list.TEXT_MODE_DOT,
                },
                {
                    type = utils_list.TYPE_IMG, x = 933, y = 24
                },
                {
                    type = utils_list.TYPE_IMG, x = 62, y = 69
                },
            },
        },
        action = {bind = {change = "list", up = "list_up"}}
    },
}

return view
