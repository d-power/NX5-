local app = get_app()
app.hw = db.get_hw()

local ret_timeout = 0

local controller =
{
    data = {
        display_brightness = app.hw.display_brightness,

        slider_x = (app.hw.display_brightness - 6) * 4,
        slider_txt = tostring(app.hw.display_brightness)
    },
    onload = function()
        set_data({now_set = "亮度设置", return_msg = {user_tab_show = 1}})
        log_debug('user_setting/setting_light onload') 
    end,
    onshow = function()
        log_debug('user_setting/setting_light onshow') 
    end,
    ondestroy = function()
        cfun.screen_set_bright(app.hw.display_brightness)
        log_debug('user_setting/setting_light ondestroy')
    end,

    timer = function()
        if ret_timeout > 0 then
            ret_timeout = ret_timeout - 1
            if ret_timeout == 0 then
                set_page(common.set_bar.data.return_page, common.set_bar.data.return_msg)
                common.set_bar.data.return_msg = nil
            end
        end
    end,

    light_change = function(v, val)
        set_data({
            slider_x = (tonumber(val) - 6) * 4,
            slider_txt = tostring(tonumber(val))
        })
        cfun.screen_set_bright(tonumber(val))
    end,

    config_act = function(v)
        if v.name == "save" then
            app.hw.display_brightness = this.data.display_brightness

            if db.set_hw(app.hw) == 0 then
                ret_timeout = 30
                popups.show_popups("设置成功")
            else
                popups.show_popups("设置失败")
            end
        else
            
        end
    end,

    volume_change = function(v, value)
        if value == nil then
            local change_act  = v.name:sub(("light_"):len() + 1, -1)
            if change_act == "add" and this.data.display_brightness < 100 then
                set_data({
                    display_brightness = this.data.display_brightness + 1,
                    slider_x = (this.data.display_brightness + 1 - 6) * 4,
                    slider_txt = tostring(this.data.display_brightness + 1)
                })
            elseif change_act == "reduce" and this.data.display_brightness > 1 then
                set_data({
                    display_brightness = this.data.display_brightness - 1,
                    slider_x = (this.data.display_brightness - 1 - 6) * 4,
                    slider_txt = tostring(this.data.display_brightness - 1)
                })
            end

            cfun.screen_set_bright(tonumber(this.data.display_brightness))
        end
    end,
}
return controller