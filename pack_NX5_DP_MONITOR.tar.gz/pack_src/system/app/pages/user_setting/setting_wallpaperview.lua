local view = {
    -- {
    --     type = "img",
    --     position = {x = 56, y = 88},
    --     attr = {w = 288, h = 216,res = "background.png"},
    --     name = "bg1"
    -- },
    {
        type        = "page",
        position = {x = 56, y = 88},
        attr        = {w = 288, h = 216, c = 0xff000000, c_bar = 0x00808080, layout = utils_page.LAYOUT_OFF,
                       round = true, mode = utils_page.MODE_AUTO},
        name        = "bg1",
    },
    {
        type = "img",
        position = {x = 238, y = 166},
        attr = {res = "setting/bg_select.png", parent = "bg1"},
    },
    {
        type = "text",
        position = {align = utils_align.OUT_BOTTOM_MID, aligny = 14, ref = "bg1"},
        attr = {
            w = 228, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT,
            c = 0xffffffff, content = "炫酷黑", }
    },
}
return view