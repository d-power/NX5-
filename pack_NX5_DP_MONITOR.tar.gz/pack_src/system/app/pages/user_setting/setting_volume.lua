local app = get_app()
app.sound = db.get_sound()

local ret_timeout = 0

local controller =
{
    data = {
        ring_volume = app.sound.ring_vol,
        call_volume = app.sound.talk_vol,
        
        ring_volume_x = (app.sound.ring_vol - 6) * 4,
        ring_volume_txt = tostring(app.sound.ring_vol),

        call_volume_x = (app.sound.talk_vol - 6) * 4,
        call_volume_txt = tostring(app.sound.talk_vol),
    },
    onload = function()
        set_data({now_set = "音量设置"})
        log_debug('user_setting/setting_volume onload') 
    end,
    onshow = function()
        log_debug('user_setting/setting_volume onshow') 
    end,
    ondestroy = function()
        log_debug('user_setting/setting_volume ondestroy') 
    end,

    timer = function()
        if ret_timeout > 0 then
            ret_timeout = ret_timeout - 1
            if ret_timeout == 0 then
                set_page(common.set_bar.data.return_page, common.set_bar.data.return_msg)
                common.set_bar.data.return_msg = nil
            end
        end
    end,

    config_act = function(v)
        if v.name == "save" then
            app.sound.ring_vol = this.data.ring_volume
            app.sound.talk_vol = this.data.call_volume
            if db.set_sound(app.sound) == 0 then
                ret_timeout = 30
                popups.show_popups("设置成功")
            else
                popups.show_popups("设置失败")
            end
            log_debug(this.data.ring_volume, this.data.call_volume)
        end
    end,

    volume_change = function(v, value)

        local change_mode = v.name:sub(1, ("call_volume_"):len() - 1) == "ring_volume" and "ring_volume" or "call_volume"

        if value == nil then
            local change_act  = v.name:sub(("call_volume_"):len() + 1, -1)
            print(change_mode, change_act, (this.data[change_mode] + 1 - 6) * 4)
            if change_act == "add" and this.data[change_mode] < 100 then
                set_data({
                    [change_mode] = this.data[change_mode] + 1,
                    [change_mode .. "_x"] = (this.data[change_mode] + 1 - 6) * 4,
                    [change_mode .. "_txt"] = tostring(this.data[change_mode] + 1)
                })
            elseif change_act == "reduce" and this.data[change_mode] > 0 then
                set_data({
                    [change_mode] = this.data[change_mode] - 1,
                    [change_mode .. "_x"] = (this.data[change_mode] - 1 - 6) * 4,
                    [change_mode .. "_txt"] = tostring(this.data[change_mode] - 1)
                })
            elseif change_act == "mute" then
                set_data({
                    [change_mode] = 0,
                    [change_mode .. "_x"] = (0 - 6) * 4,
                    [change_mode .. "_txt"] = "0"
                })
            end
        else
            set_data({
                [change_mode .. "_x"] = (tonumber(value) - 6) * 4,
                [change_mode .. "_txt"] = tostring(tonumber(value))
            })
        end
    end,
}
return controller