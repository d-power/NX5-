local controller =
{
    data = {
    },
    onload = function()
        set_data({now_set = "屏保设置", return_msg = {user_tab_show = 1}})
        log_debug('user_setting/setting_screensaver onload') 
    end,
    onshow = function()
        log_debug('user_setting/setting_screensaver onshow') 
    end,
    ondestroy = function()
        log_debug('user_setting/setting_screensaver ondestroy') 
    end,
}
return controller