local view = {
    {
        type = "shared",
        attr = {file = "shared_btn", func = "ctrl_btn", 
                obj = {x = 852, y = 512, name = "save", 
                        rel = "setting/btn_ok.png", act_up = "config_act", content = "保存"}},
    },
    -- {
    --     type = "shared",
    --     attr = {file = "shared_btn", func = "ctrl_btn", 
    --             obj = {x = 680, y = 512, name = "cancel", 
    --                     rel = "setting/btn_cancel.png", act_up = "config_act", content = "取消"}},
    -- },

    {
        type = "roller",
        position = {x = 120, y = 200},
        attr = {
                w = 80, h = 30, c = 0x00818c9e, c_slt = 0x0039475e, c_content = 0xffffffff, c_slt_content = 0xffffffff,
                opt = "{{year_opt}}", align = utils_roller.ALIGN_CENTER, cnt = 3, mode = utils_roller.MODE_NORMAL,
                content = "{{year_roller}}"},
        action = {bind = {change = "year_change"}},
    },
    {
        type = "roller",
        position = {x = 240, y = 200},
        attr = {
                w = 80, h = 30, c = 0x00818c9e, c_slt = 0x0039475e, c_content = 0xffffffff, c_slt_content = 0xffffffff,
                opt = "{{mouth_opt}}", align = utils_roller.ALIGN_CENTER, cnt = 3, mode = utils_roller.MODE_NORMAL,
                content = "{{mouth_roller}}"},
        action = {bind = {change = "mouth_change"}},
    },
    {
        type = "roller",
        position = {x = 360, y = 200},
        attr = {
                w = 80, h = 30, c = 0x00818c9e, c_slt = 0x0039475e, c_content = 0xffffffff, c_slt_content = 0xffffffff,
                opt = "{{day_opt}}", align = utils_roller.ALIGN_CENTER, cnt = 3, mode = utils_roller.MODE_NORMAL,
                content = "{{day_roller}}"},
        action = {bind = {change = "day_change"}},
    },
    {
        type = "roller",
        position = {x = 660, y = 200},
        attr = {
                w = 80, h = 30, c = 0x00818c9e, c_slt = 0x0039475e, c_content = 0xffffffff, c_slt_content = 0xffffffff,
                opt = "{{hour_opt}}", align = utils_roller.ALIGN_CENTER, cnt = 3, mode = utils_roller.MODE_NORMAL,
                content = "{{hour_roller}}"},
        action = {bind = {change = "hour_change"}},
    },
    {
        type = "roller",
        position = {x = 760, y = 200},
        attr = {
                w = 80, h = 30, c = 0x00818c9e, c_slt = 0x0039475e, c_content = 0xffffffff, c_slt_content = 0xffffffff,
                opt = "{{min_opt}}", align = utils_roller.ALIGN_CENTER, cnt = 3, mode = utils_roller.MODE_NORMAL,
                content = "{{min_roller}}"},
        action = {bind = {change = "min_change"}},
    },

    {
        type = "img",
        position = {x = 64, y = 258},
        attr = {res = "setting/list_line.png",},
    },
    {
        type = "img",
        position = {x = 64, y = 312},
        attr = {res = "setting/list_line.png",},
    },

}
return view