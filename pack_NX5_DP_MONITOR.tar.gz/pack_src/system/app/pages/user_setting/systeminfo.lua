
local wifi_ip_info = decode(cfun.get_ip()) or {ip = ""}
local app = get_app()

app.net = db.get_net()
app.status = db.get_status()
app.sys_config = db.get_sys_config()
app.cloud = db.get_cloud()

-- {"ip":"192.168.1.167","mask":"255.255.255.0","gateway":"192.168.1.1","dns":"192.168.1.1"}

local language = {
    "简体中文",
    "繁体中文",
    "英文",
}

local _info_map = {
    "本机IP地址：" ..( wifi_ip_info.ip or ""), "setting/list_line.png",
    "服务器地址：" .. app.cloud.server_url, "setting/list_line.png",
    "位置信息：" .. app.sys_config.position, "setting/list_line.png",
    "应用版本号：" .. app.status.software_name .." ("..app.status.software_version..")", "setting/list_line.png",
    "系统版本号：" .. app.status.system_name .." ("..app.status.system_version..")", "setting/list_line.png",
    "硬件版本号：" .. app.status.hardware_name .." ("..app.status.hardware_version..")", "setting/list_line.png",
    "语言：" .. language[app.sys_config.language + 1], "setting/list_line.png",
}

-- if app.net.wifi_name ~= "" then
--     _info_map[#_info_map+1] =  "WiFi：" .. app.net.wifi_name
--     _info_map[#_info_map+1] = "setting/list_line.png"
-- end


local controller =
{
    data = {
        info_map = _info_map
    },
    onload = function()
        set_data({now_set = "系统信息"})
        log_debug('user_setting/systeminfo onload') 
    end,
    onshow = function()
        log_debug('user_setting/systeminfo onshow') 
    end,
    ondestroy = function()
        log_debug('user_setting/systeminfo ondestroy') 
    end,
}
return controller