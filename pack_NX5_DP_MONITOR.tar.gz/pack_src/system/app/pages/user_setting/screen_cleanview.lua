local _map = {}

for i = 1, 27 do
    _map[#_map + 1] = string.format("aimg/%d.png", i)
end

local view = {
    {
        type = "aimg",
        position = {align = utils_align.CENTER},
        attr = {
            times = -1,
            interval = 40,
            map = _map
        },
    },
    {
        type = "text",
        position = {align = utils_align.IN_TOP_MID, aligny = 376},
        attr = {
            w = 1024, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER,
            c = 0xffffffff, content = "屏幕清洗中...", }
    },
}
return view