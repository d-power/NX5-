local app = get_app()
app.delay = db.get_delay()
local ret_timeout = 0

local db_correspond = {
    armed       = {db = "safe_delay",       min = 10,  max = 99,  interval = 400/(99 - 10),   frist_x = -6},
    alarm       = {db = "alarm_delay",      min = 0,   max = 120, interval = 400/(120 - 0),   frist_x = -7},
    alarm_ring  = {db = "alarm_duration",   min = 180, max = 600, interval = 400/(600 - 180), frist_x = -25},
    call        = {db = "call_delay",       min = 10,  max = 60,  interval = 400/(60 - 10),   frist_x = -3},
    screen      = {db = "screen_delay",     min = 10,  max = 60,  interval = 400/(60 - 10),   frist_x = -3}
}

local controller =
{
    data = {
        armed_delay = app.delay.safe_delay,
        alarm_delay = app.delay.alarm_delay,
        alarm_ring_delay = app.delay.alarm_duration,
        call_delay = app.delay.call_delay,
        screen_delay = app.delay.screen_delay,

        armed_x = math.floor((app.delay.safe_delay - db_correspond.armed.min + db_correspond.armed.frist_x) * db_correspond.armed.interval),
        alarm_x = math.floor((app.delay.alarm_delay - db_correspond.alarm.min + db_correspond.alarm.frist_x) * db_correspond.alarm.interval),
        alarm_ring_x = math.floor((app.delay.alarm_duration - db_correspond.alarm_ring.min + db_correspond.alarm_ring.frist_x) * db_correspond.alarm_ring.interval),
        call_x = math.floor((app.delay.call_delay - db_correspond.call.min + db_correspond.call.frist_x) * db_correspond.call.interval),
        screen_x = math.floor((app.delay.screen_delay - db_correspond.screen.min + db_correspond.screen.frist_x) * db_correspond.screen.interval),

        armed_txt = tostring(app.delay.safe_delay),
        alarm_txt = tostring(app.delay.alarm_delay),
        alarm_ring_txt = tostring(app.delay.alarm_duration),
        call_txt = tostring(app.delay.call_delay),
        screen_txt = tostring(app.delay.screen_delay),
    },
    onload = function()
        log_debug('user_setting/setting_delay onload') 
    end,
    onshow = function()
        log_debug('user_setting/setting_delay onshow') 
    end,
    ondestroy = function()
        log_debug('user_setting/setting_delay ondestroy') 
    end,

    timer = function()
        if ret_timeout > 0 then
            ret_timeout = ret_timeout - 1
            if ret_timeout == 0 then
                set_page(common.set_bar.data.return_page, common.set_bar.data.return_msg)
                common.set_bar.data.return_msg = nil
            end
        end
    end,

    config_act = function(v)
        if v.name == "save" then
            for key, value in pairs(db_correspond) do
                app.delay[value.db] = this.data[key .. "_delay"] or app.delay[value.db]
            end
            if db.set_delay(app.delay) == 0 then
                set_screensaver_time(app.delay.screen_delay)
                ret_timeout = 30
                popups.show_popups("设置成功")
            else
                popups.show_popups("设置失败")
            end
        else
        end
    end,

    delay_change = function(v, val)
        local change_cfg = split(v.name, "^")
        local change_value = change_cfg[1] .. "_delay"
        local change_x = change_cfg[1] .. "_x"
        local change_txt = change_cfg[1] .. "_txt"

        print(v.name, this.data[change_value])

        if change_cfg[2] == "add" and this.data[change_value] < db_correspond[change_cfg[1]].max then
            set_data({
                [change_value] = this.data[change_value] + 1,
                [change_x] = math.floor((this.data[change_value] + 1 - db_correspond[change_cfg[1]].min + db_correspond[change_cfg[1]].frist_x) * db_correspond[change_cfg[1]].interval),
                [change_txt] = tostring(this.data[change_value] + 1)
            })
        elseif change_cfg[2] == "reduce" and this.data[change_value] > db_correspond[change_cfg[1]].min then
            set_data({
                [change_value] = this.data[change_value] - 1,
                [change_x] = math.floor((this.data[change_value] - 1 - db_correspond[change_cfg[1]].min + db_correspond[change_cfg[1]].frist_x) * db_correspond[change_cfg[1]].interval),
                [change_txt] = tostring(this.data[change_value] - 1)
            })
        elseif change_cfg[2] == "slider" then
            set_data({
                [change_x] = math.floor((tonumber(val) - db_correspond[change_cfg[1]].min + db_correspond[change_cfg[1]].frist_x) * db_correspond[change_cfg[1]].interval),
                [change_txt] = tostring(tonumber(val))
            })
        end
    end,
}

return controller
