local b_auto_time = false
local app = get_app()

-- TODO: 保存是否为自动设置以及上一次手动设置的值

app.sys_config = db.get_sys_config()
table.print(app.sys_config)

b_auto_time = app.sys_config.auto_time == 1
 
local controller =
{
    data = {
        auto_time = b_auto_time,
        check_state = b_auto_time and utils_btn.CHK_REL or utils_btn.REL
    },
    onload = function()
        set_data({now_set = "时间设置", return_page = "setting"})
    end,
    onshow = function()
    end,
    ondestroy = function()
    end,

    auto_change = function()
        set_data({auto_time = not this.data.auto_time})
        app.sys_config.auto_time = this.data.auto_time and 1 or 0
        if app.sys_config.auto_time == 1 then
            ws.sync_time()
        end

        db.set_sys_config(app.sys_config)
    end,

    goto_set_date = function()
        set_page("setting_date")
    end,
}
return controller