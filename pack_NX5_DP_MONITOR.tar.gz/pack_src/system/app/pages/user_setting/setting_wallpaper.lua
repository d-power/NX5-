local controller =
{
    data = {
    },
    onload = function()
        set_data({now_set = "壁纸设置", return_msg = {user_tab_show = 1}})
        log_debug('user_setting/setting_wallpaper onload') 
    end,
    onshow = function()
        log_debug('user_setting/setting_wallpaper onshow') 
    end,
    ondestroy = function()
        log_debug('user_setting/setting_wallpaper ondestroy') 
    end,
}
return controller