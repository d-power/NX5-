local clear_timeout = 10 * 10

local controller =
{
    data = {
    },
    onload = function()
        set_data({now_set = "屏幕清洗"})
        log_debug('user_setting/screen_clean onload') 
    end,
    onshow = function()
        log_debug('user_setting/screen_clean onshow') 
    end,
    ondestroy = function()
        log_debug('user_setting/screen_clean ondestroy') 
    end,

    ret_act = function()
        return clear_timeout > 0
    end,

    timer = function()
        clear_timeout = clear_timeout - 1
        if clear_timeout >= 0 then
            log_debug("screen clean time left", clear_timeout)
        end
    end

}
return controller