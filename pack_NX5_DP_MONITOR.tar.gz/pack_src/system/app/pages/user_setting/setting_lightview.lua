local view = {
    {
        type = "shared",
        attr = {file = "shared_btn", func = "ctrl_btn", 
                obj = {x = 852, y = 512, name = "save", 
                        rel = "setting/btn_ok.png", act_up = "config_act",
                        content = "保存"}},
    },
    -- {
    --     type = "shared",
    --     attr = {file = "shared_btn", func = "ctrl_btn", 
    --             obj = {x = 680, y = 512, name = "cancel", 
    --                     rel = "setting/btn_cancel.png", act_up = "config_act",
    --                     content = "取消"}},
    -- },
    {
        type = "btn",
        position = {x = 780, y = 300},
        attr = {res_rel = "setting/add_rel.png", res_clk = "setting/add_pre.png",},
        action = {bind = {up = "volume_change"}},
        name = "light_add"
    },  
    {
        type = "btn",
        position = {x = 276, y = 300},
        attr = {res_rel = "setting/reduce_rel.png", res_clk = "setting/reduce_rel.png",},
        action = {bind = {up = "volume_change"}},
        name = "light_reduce"
    },
    {
        type = "slider",
        position = {align = utils_align.OUT_RIGHT_MID, alignx = 26, ref = "light_reduce"},
        attr = {w = 400, h = 16, c = 0xff1d1d1d, c_act = 0xffffffff, c_knob = 0x00FFFFFF, round = true,
                spin = false, min = 1, max = 100, value = "{{display_brightness}}", mode = utils_slider.MODE_NORMAL},
        action = {bind = {change = "light_change"}},
        name = "light_slider"
    },
    {
        type = "text",
        position = {align = utils_align.OUT_BOTTOM_RIGHT, aligny = 20, ref  = "light_slider"},
        attr = {
            w = 320, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_RIGHT,
            c = 0xffffffff, content = "100", }
    },
    {
        type = "text",
        position = {align = utils_align.OUT_BOTTOM_LEFT, aligny = 20, ref  = "light_slider"},
        attr = {
            w = 320, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT,
            c = 0xffffffff, content = "1", }
    },
    {
        type = "img",
        position = {align = utils_align.IN_LEFT_MID, alignx = "{{slider_x}}", ref  = "light_slider"},
        attr = {res = "setting/round.png"},
        name = "round"
    },
    {
        type = "text",
        position = {align = utils_align.CENTER,},
        attr = {
            w = 40, h = 12, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = "round",
            c = 0xff000000, content = "{{slider_txt}}", }
    },
}
return view