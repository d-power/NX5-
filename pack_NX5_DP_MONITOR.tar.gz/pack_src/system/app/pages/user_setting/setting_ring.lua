local app = get_app()
local _ring_map = { "静音",  "setting/ring_noselect.png", "setting/list_line.png", }
local default_ring_path = "/system/ring"
local sd_ring_path = "/tmp/media/mmcblk0/ring"
local file_to_path = {}
local music_id = 0

app.sound = db.get_sound()

table.print(app.sound)

local function add_ring_file(path)
    local path_info, path_error = lfs.attributes(path)
    if path_info == nil then
        log_error(path_error)
    else
        for file in lfs.dir(path) do 
            if file ~= "." and file ~= ".." then 
                local f = path..'/'..file 
                local attr = lfs.attributes (f) 
                if type(attr) == "table" then
                    if attr.mode == "directory" then 
                        add_ring_file (f) 
                    else 
                        file_to_path[file] = f
                        _ring_map[#_ring_map + 1] = file
                        _ring_map[#_ring_map + 1] = "setting/ring_noselect.png"
                        _ring_map[#_ring_map + 1] = "setting/list_line.png"
                    end 
                end
            end 
        end 
    end
end

add_ring_file(default_ring_path)
add_ring_file(sd_ring_path)

local now_choose = "静音"
for key, value in pairs(file_to_path) do
    if app.sound.call_in_ring_name == value then
        now_choose = key
        break
    end
end

for i = 1, #_ring_map, 3 do
    if _ring_map[i] == now_choose then
        _ring_map[i + 1] = "setting/ring_select.png"
        break
    end
end


local controller =
{
    data = {
        ring_map = _ring_map
    },
    onload = function()
        set_data({now_set = "铃声设置"})
        log_debug('user_setting/setting_ring onload') 
    end,
    onshow = function()
        log_debug('user_setting/setting_ring onshow') 
    end,
    ondestroy = function()
        if music_id ~= 0 then
            cfun.stop_music(music_id)
        end
        log_debug('user_setting/setting_ring ondestroy') 
    end,

    list_up = function(v, line)
        log_debug(v, line)

        for i = 0, #_ring_map / 3 - 1 do
            _ring_map[i * 3 + 2] = tonumber(line) == (i + 1) and "setting/ring_select.png" or "setting/ring_noselect.png"
        end

        app.sound.call_in_ring_name = file_to_path[_ring_map[(tonumber(line) - 1) * 3 + 1]] or ""
        app.sound.call_out_ring_name = file_to_path[_ring_map[(tonumber(line) - 1) * 3 + 1]] or ""

        -- TODO:停止并播放音乐
        cfun.stop_music(music_id)
        music_id = 0

        if tonumber(line) == 1 then
            app.sound.enable_mute = 1
        else
            app.sound.enable_mute = 0
        end

        db.set_sound(app.sound)

        print(app.sound.call_in_ring_name, app.sound.enable_mute)
        if app.sound.enable_mute == 0 then
            music_id = cfun.play_music(app.sound.call_in_ring_name)
        end

        set_data({ring_map = _ring_map})
    end,
}
return controller