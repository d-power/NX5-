local view = {
    {
        type = "shared",
        attr = {file = "shared_btn", func = "ctrl_btn", 
                obj = {x = 852, y = 512, name = "save", 
                        rel = "setting/btn_ok.png", act_up = "config_act",
                        content = "保存"}},
    },
    {
        type = "btn",
        position = {x = 880, y = 218},
        attr = {res_rel = "setting/add_rel.png", res_clk = "setting/add_pre.png",},
        action = {bind = {up = "volume_change"}},
        name = "ring_volume_add"
    },
    {
        type = "btn",
        position = {x = 880, y = 378},
        attr = {res_rel = "setting/add_rel.png", res_clk = "setting/add_pre.png",},
        action = {bind = {up = "volume_change"}},
        name = "call_volume_add"
    },
    {
        type = "btn",
        position = {x = 376, y = 218},
        attr = {res_rel = "setting/reduce_rel.png", res_clk = "setting/reduce_rel.png",},
        action = {bind = {up = "volume_change"}},
        name = "ring_volume_reduce"
    },  
    {
        type = "btn",
        position = {x = 376, y = 378},
        attr = {res_rel = "setting/reduce_rel.png", res_clk = "setting/reduce_rel.png",},
        action = {bind = {up = "volume_change"}},
        name = "call_volume_reduce"
    },
    {
        type = "btn",
        position = {x = 304, y = 218},
        attr = {res_rel = "setting/mute_rel.png", res_clk = "setting/mute_rel.png",},
        action = {bind = {up = "volume_change"}},
        name = "ring_volume_mute"
    },
    {
        type = "text",
        position = {align = utils_align.OUT_LEFT_MID, alignx = - 32, ref  = "ring_volume_mute"},
        attr = {
            w = 320, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_RIGHT,
            c = 0xffffffff, content = "振铃音量/按键音量", }
    },
    {
        type = "btn",
        position = {x = 304, y = 378},
        attr = {res_rel = "setting/mute_rel.png", res_clk = "setting/mute_rel.png",},
        action = {bind = {up = "volume_change"}},
        name = "call_volume_mute"
    },
    {
        type = "text",
        position = {align = utils_align.OUT_LEFT_MID, alignx = - 32, ref = "call_volume_mute"},
        attr = {
            w = 320, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_RIGHT,
            c = 0xffffffff, content = "通话音量", }
    },
    {
        type = "slider",
        position = {align = utils_align.OUT_RIGHT_MID, alignx = 26, ref = "ring_volume_reduce"},
        attr = {w = 400, h = 16, c = 0xff1d1d1d, c_act = 0xffffffff, c_knob = 0x00FFFFFF, round = true,
                spin = false, min = 0, max = 100, value = "{{ring_volume}}", mode = utils_slider.MODE_NORMAL},
        action = {bind = {change = "volume_change"}},
        name = "ring_volume_slider"
    },
    {
        type = "text",
        position = {align = utils_align.OUT_BOTTOM_RIGHT, aligny = 20, ref  = "ring_volume_slider"},
        attr = {
            w = 320, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_RIGHT,
            c = 0xffffffff, content = "100", }
    },
    {
        type = "text",
        position = {align = utils_align.OUT_BOTTOM_LEFT, aligny = 20, ref  = "ring_volume_slider"},
        attr = {
            w = 320, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT,
            c = 0xffffffff, content = "0", }
    },
    {
        type = "slider",
        position = {align = utils_align.OUT_RIGHT_MID, alignx = 26, ref = "call_volume_reduce"},
        attr = {w = 400, h = 16, c = 0xff1d1d1d, c_act = 0xffffffff, c_knob = 0x00FFFFFF, round = true,
                spin = false, min = 0, max = 100, value = "{{call_volume}}", mode = utils_slider.MODE_NORMAL},
        action = {bind = {change = "volume_change"}},
        name = "call_volume_slider"
    },
    {
        type = "text",
        position = {align = utils_align.OUT_BOTTOM_RIGHT, aligny = 20, ref  = "call_volume_slider"},
        attr = {
            w = 320, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_RIGHT,
            c = 0xffffffff, content = "100", }
    },
    {
        type = "text",
        position = {align = utils_align.OUT_BOTTOM_LEFT, aligny = 20, ref  = "call_volume_slider"},
        attr = {
            w = 320, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT,
            c = 0xffffffff, content = "0", }
    },

    {
        type = "img",
        position = {align = utils_align.IN_LEFT_MID, alignx = "{{ring_volume_x}}", ref  = "ring_volume_slider"},
        attr = {res = "setting/round.png"},
        name = "ring_round"
    },
    {
        type = "text",
        position = {align = utils_align.CENTER,},
        attr = {
            w = 40, h = 12, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = "ring_round",
            c = 0xff000000, content = "{{ring_volume_txt}}", }
    },

    {
        type = "img",
        position = {align = utils_align.IN_LEFT_MID, alignx = "{{call_volume_x}}", ref  = "call_volume_slider"},
        attr = {res = "setting/round.png"},
        name = "call_round"
    },
    {
        type = "text",
        position = {align = utils_align.CENTER,},
        attr = {
            w = 40, h = 12, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = "call_round",
            c = 0xff000000, content = "{{call_volume_txt}}", }
    },
}
return view