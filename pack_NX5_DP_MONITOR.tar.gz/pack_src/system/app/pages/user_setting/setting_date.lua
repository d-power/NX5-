local app = get_app()
local year = {} for i = 2020, 2030 do year[i-2019] = i end
local mouth = {} for i = 1, 12 do mouth[i] = i end
local day = {} for i = 1, 31 do day[i] = i end
local hour = {} for i = 0, 23 do hour[i + 1] = string.format("%02d", i) end
local min = {} for i = 0, 59 do min[i+1] = string.format("%02d", i) end

local day_number = 31
local select_year = tonumber(os.date("%Y"))
local select_mouth = tonumber(os.date("%m"))
local select_day = tonumber(os.date("%d"))
local select_hour = tonumber(os.date("%H"))
local select_min = tonumber(os.date("%M"))

local ret_timeout = 0

local function change_leap_year(year)
    if(year % 400 == 0 or year % 4 == 0 and year % 100 ~= 0) then
        log_debug("这年是闰年")
        return true
    else
        log_debug("这年不是闰年")
        return false
    end
end

local function get_day_number(year, mouth)
    log_debug("now year:"..year.." mouth:"..mouth)

    local _mouth = tonumber(mouth)
    local _year  = tonumber(year)

    if _mouth == 2 then
        return change_leap_year(_year) and 29 or 28
    end

    if _mouth == 1 or _mouth == 3 or _mouth == 5 or _mouth == 7 or _mouth == 8 or _mouth == 10 or _mouth == 12 then
        return 31
    else
        return 30
    end

end

local day_number = get_day_number(select_year, select_mouth)

log_debug(day_number)

local controller =
{
    data = {

        year_opt = select_year < 2020 and 0 or select_year - 2020,
        year_roller =  table.concat(year, "\n"),

        mouth_opt = select_mouth - 1,
        mouth_roller =  table.concat(mouth, "\n"),

        day_opt = select_day - 1,
        day_roller = table.concat(day, "\n", 1, day_number),

        hour_opt = select_hour,
        hour_roller =  table.concat(hour, "\n"),

        min_opt = select_min,
        min_roller =  table.concat(min, "\n"),
    },
    onload = function()
        set_data({now_set = "时间设置", return_page = "setting_time"})
        log_debug('user_setting/setting_date onload') 
    end,
    onshow = function()
        log_debug('user_setting/setting_date onshow') 
    end,
    ondestroy = function()
        log_debug('user_setting/setting_date ondestroy') 
    end,
    
    timer = function()
        if ret_timeout > 0 then
            ret_timeout = ret_timeout - 1
            if ret_timeout == 0 then
                set_page(common.set_bar.data.return_page, common.set_bar.data.return_msg)
                common.set_bar.data.return_msg = nil
            end
        end
    end,

    config_act = function()
        app.sys_config.last_time = string.format("%04d-%02d-%02d %02d:%02d", 
                                            2020 + this.data.year_opt, this.data.mouth_opt + 1, this.data.day_opt + 1,
                                            this.data.hour_opt, this.data.min_opt)
        if db.set_sys_config(app.sys_config) == 0 then
            ret_timeout = 30
            os.execute("date '" .. app.sys_config.last_time .. "'")
            popups.show_popups("设置成功")
        else
            popups.show_popups("设置失败")
        end 
    end
}
return controller