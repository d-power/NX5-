

local controller =
{
    data =
    {
        now_set = "",
        return_page = "",
        return_msg = {},
    },

    onload = function()
        log_info("set_bar onload")
    end,

    onshow = function()
        log_info("set_bar onshow")
    end,

    ondestroy = function()
        log_info("set_bar ondestroy")
    end,

    back_act = function()
        if not this.ret_act or not this.ret_act() then
            set_page(common.set_bar.data.return_page, common.set_bar.data.return_msg)
            common.set_bar.data.return_msg = nil
        end
    end
}

return controller
