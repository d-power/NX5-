local view =
{
    {
        type = "mark",
        position = {align = utils_align.IN_TOP_MID},
        attr = {w = get_lcd_hor_res(), h = 55, c = 0x10A6A6A6},
        name = "set_bar_bg",
    },
    {
        type = "img",
        position = {align = utils_align.IN_TOP_LEFT, alignx = 30, aligny = 15},
        attr = {res = "back.png"}
    },
    {
        type = "blank",
        position = {align = utils_align.IN_TOP_LEFT},
        attr = { w = 100, h = 55, parent = "set_bar_bg"},
        action = {bind = {up = "back_act"}}
    },
    {
        type = "text",
        position = {align = utils_align.CENTER},
        attr ={ w = 1024, h = 26, c = 0xffffffff, align = utils_text.ALIGN_CENTER, mode = utils_text.MODE_CROP,
                content = "{{now_set}}", parent = "set_bar_bg" },
    },
    {
        type = "clock",
        position = {align = utils_align.IN_RIGHT_MID, alignx = -60},
        attr =
        {
            w = 320, h = 20, align = utils_clock.ALIGN_RIGHT, c = 0xffffffff, fmt = "%H:%M", parent = "set_bar_bg"
        },
    },
}

return view
