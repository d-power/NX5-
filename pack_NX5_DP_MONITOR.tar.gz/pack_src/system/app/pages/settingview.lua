local view =
{
    -- {
    --     type = "img",
    --     position = {align = utils_align.IN_TOP_MID, aligny = 88},
    --     attr = {res = "setting/bg.png"}
    -- },
    {
        type = "blank",
        position = {x = 60, y = 110},
        attr = { w = 120, h = 60},
        action = {bind = {up = "change_set"}},
        name = "user_set"
    },
    {
        type = "text",
        position = {align = utils_align.CENTER},
        attr ={ w = 120, h = 20, c = "{{user_set_color}}", align = utils_text.ALIGN_CENTER, mode = utils_text.MODE_CROP,
                content = "用户设置", parent = "user_set" },
    },
    {
        type = "blank",
        position = {x = 180, y = 110},
        attr = { w = 120, h = 60},
        action = {bind = {up = "change_set"}},
        name = "system_set"
    },
    {
        type = "text",
        position = {align = utils_align.CENTER},
        attr ={ w = 120, h = 20, c = "{{system_set_color}}", align = utils_text.ALIGN_CENTER, mode = utils_text.MODE_CROP,
                content = "系统设置", parent = "system_set" },
    },
    {
        type = "bar",
        position = {x = "{{bar_x}}", y = 165},
        attr = { w = 58, h = 3, src = 0, dest = 2,round = true, c = 0xFFF7C754, c_act = 0xFFF7C754, value = 2 },
    },
    {
        type        = "tab",
        position    = {align = utils_align.IN_TOP_MID, alignx = 0, aligny = 200},
        attr        = {w = 900, h = 340, tab = "{{user_tab_show}}", hidden = "{{user_set_hidden}}"},
        action      = {bind = {up = "tab_up", down = "tab_down", change = "tab_act"},},
        name        = "user_tab"
    },
    { type  = "tab", position = {}, attr = {parent = "user_tab"}, name = "user_tab0"},
    { type  = "tab", position = {}, attr = {parent = "user_tab"}, name = "user_tab1"},
    {
        type = "img",
        position = {align = utils_align.IN_BOTTOM_MID, aligny = -55, alignx = -12},
        attr = {res = "{{tab_select1}}", hidden = "{{user_set_hidden}}"}
    },
    {
        type = "img",
        position = {align = utils_align.IN_BOTTOM_MID, aligny = -55, alignx = 12},
        attr = {res = "{{tab_select2}}", hidden = "{{user_set_hidden}}"}
    },
    {
        type        = "tab",
        position    = {align = utils_align.IN_TOP_MID, alignx = 0, aligny = 200},
        attr        = {w = 900, h = 340, tab = 0, hidden = "{{system_set_hidden}}"},
        action      = {bind = {up = "tab_up", down = "tab_down", change = "tab_act"},},
        name        = "system_tab"
    },
    { type  = "tab", position = {}, attr = {parent = "system_tab"}, name = "system_tab0"},
}

local user_set_tab = {
    {name = "系统信息", img = "setting/system.png",         next_page = "systeminfo"},
    {name = "铃声设置", img = "setting/ring_set.png",       next_page = "setting_ring"},
    {name = "wifi设置", img = "setting/wifi.png",           next_page = "setting_wifi"},
    {name = "时间日期", img = "setting/timer.png",          next_page = "setting_time"},
    {name = "密码设置", img = "setting/password.png",       next_page = "setting_pwd"},
    {name = "音量设置", img = "setting/volume.png",         next_page = "setting_volume"},
    {name = "延时设置", img = "setting/delay.png",          next_page = "setting_delay"},
    {name = "屏幕清洗", img = "setting/screen_clear.png",   next_page = "screen_clean"},
    {name = "亮度设置", img = "setting/light.png",          next_page = "setting_light"},
    -- {name = "壁纸设置", img = "setting/wallpaper.png",      next_page = "setting_wallpaper"},
    {name = "屏保设置", img = "setting/screen_saver.png",   next_page = "setting_screensaver"},
}

for i = 0, #user_set_tab - 1 do
    view[#view + 1] = 
        {
            type = "shared",
            attr = {file = "shared_btn", func = "set_shart_btn", 
                    obj = {
                        x = math.floor((i%8)%4) * 224, y = math.floor((i%8)/4) * 171,
                        parent = "user_tab" .. math.modf(i/8),
                        next_page = user_set_tab[i+1].next_page,
                        img = user_set_tab[i+1].img,
                        text = user_set_tab[i+1].name,
                    }},
        }
end

local system_set_tab = {
    {name = "安防设置",     img = "setting/security.png",         next_page = "systemset_security"},
    -- {name = "房号设置",     img = "setting/roomid_set.png",       next_page = ""},
    -- {name = "小门口机设置",  img = "setting/small_door.png",       next_page = ""},
    {name = "工程密码",     img = "setting/prj_pwd.png",           next_page = "systemset_pwd"},
    {name = "系统复位",     img = "setting/sys_reset.png",        next_page = "systemset_reset"},
    {name = "网络摄像头",   img = "setting/webcam.png",          next_page = "systemset_ipc"},
    -- {name = "色彩调整",     img = "setting/color.png",           next_page = "systemset_color"},
    {name = "软件升级",     img = "setting/soft_update.png",     next_page = "systemset_upgrade"},
    {name = "服务器设置",     img = "setting/web.png",     next_page = "system_webip"},
    {name = "硬件测试",     img = "setting/hardware.png",     next_page = "hardware_test"},
    {name = "网络设置",     img = "setting/net_config.png",     next_page = "systemset_net"},
}

for i = 0, #system_set_tab - 1 do
    view[#view + 1] = 
        {
            type = "shared",
            attr = {file = "shared_btn", func = "set_shart_btn", 
                    obj = {
                        x = math.floor((i%8)%4) * 224, y = math.floor((i%8)/4) * 171,
                        parent = "system_tab" .. math.modf(i/8),
                        next_page = system_set_tab[i+1].next_page,
                        img = system_set_tab[i+1].img,
                        text = system_set_tab[i+1].name,
                    }},
        }
end

return view
