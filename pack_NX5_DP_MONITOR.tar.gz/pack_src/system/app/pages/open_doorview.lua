local view = {
    {
        type        = "page",
        position    = {align = utils_align.IN_TOP_MID, alignx = 4, aligny = 90},
        attr        = {w = 956, h = 500, c = 0x00000000, c_bar = 0x00808080, layout = utils_page.LAYOUT_GRID,
                       round = false, mode = utils_page.MODE_OFF},
        name        = "page0",
        action       = {bind = {change = function(v, posx, posy) log_debug(3, "pos ",  posx, posy) end}}
    },
}

local app = get_app()

for i = 1, #app.door_list do
    log_debug( app.door_list[i].community, app.door_list[i].addr)
    view[#view + 1] = {
        type = "shared",
        attr = {file = "shared_door", func = "door_module", 
                obj = {
                    x = (i - 1) % 2 == 0 and 0 or 400, 
                    y = (i - 1)/2 * 150 + 10,
                    name = "door" .. i, 
                    community = app.door_list[i].community,
                    addr = app.door_list[i].addr,
                    open_state_img = "{{state_img".. i.. "}}",
                    open_content = "{{state_content".. i.. "}}",
                    parent = "page0",
                    user_data = { index = i }
                }},
    }
end

return view
