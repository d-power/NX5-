local controller =
{
    data = {
        no_screen_off = true
    },
    onload = function()
        log_debug('hardware_test/hardware_reboot onload') 
    end,
    onshow = function()
        log_debug('hardware_test/hardware_reboot onshow') 
    end,
    ondestroy = function()
        log_debug('hardware_test/hardware_reboot ondestroy') 
    end,
}
return controller