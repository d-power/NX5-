local view = {
    {
        type = "text",
        position = {align = utils_align.CENTER, aligny = -30},
        attr = {
            w = 1024, h = 30, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER,
            c = "{{net1_color}}", content = "{{net1_status}}", }
    },
    {
        type = "text",
        position = {align = utils_align.CENTER, aligny = 30,},
        attr = {
            w = 1024, h = 30, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER,
            c = "{{net2_color}}", content = "{{net2_status}}", }
    }
}
return view