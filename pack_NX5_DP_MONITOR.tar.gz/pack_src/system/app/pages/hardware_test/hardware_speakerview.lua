local view = {
    {
        type = "bar",
        position = {align = utils_align.CENTER},
        attr =
        {
            w = 600, h = 16, src = 0, dest = 600, time = 0, round = true,
            c = 0xff4d4d4d, c_act = 0xFFFFB319, value = "{{audio_value}}",
        },
        name = "bar1"
    },
    {
        type = "text",
        position = {align = utils_align.OUT_BOTTOM_MID, aligny = 40, ref = 'bar1'},
        attr = {
            w = 1024, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER,
            c = 0xffffffff, content = "音频播放中...", }
    },
}
return view