local _test_map = {
    "扬声器", "home/right.png", "setting/list_line.png",
    "麦克风", "home/right.png", "setting/list_line.png",
    "屏幕测试", "home/right.png", "setting/list_line.png",
    "有线网络", "home/right.png", "setting/list_line.png",
    "无线网络", "home/right.png", "setting/list_line.png",
    "重启系统", "home/right.png", "setting/list_line.png",
    "老化测试", "home/right.png", "setting/list_line.png",
}

local next_page = {
    "hardware_speaker",
    "hardware_mike",
    "hardware_screen",
    "hardware_network",
    "hardware_wifi",
    "",
    "hardware_ageing",
}

local timeout = 0

local controller =
{
    data = {
        test_map = _test_map,
        mbox_hidden = true
    },

    onload = function()
        log_debug('hardware_test/hardware_test onload') 
    end,

    onshow = function()
        set_data({now_set = "硬件测试", return_page = "setting", return_msg = {show_tab = "system_set"}})
        log_debug('hardware_test/hardware_test onshow') 
    end,

    ondestroy = function()
        log_debug('hardware_test/hardware_test ondestroy') 
    end,

    list_up = function(v, line)
        if next_page[tonumber(line)] ~= "" then
            set_page(next_page[tonumber(line)])
        else
            set_data({mbox_hidden = false})
        end
    end,

    ret_act = function()
        return not this.data.mbox_hidden
    end,    

    timer = function()
        if this.data.mbox_hidden == false then
            timeout = timeout + 1
            if timeout == 20 then
                reboot()
            end
        end
    end,
}

return controller
