local play_timer = 0

local controller =
{
    data = {
        audio_value = 0,
        no_screen_off = true
    },
    onload = function()
        set_data({now_set = "扬声器", return_page = "hardware_test"})
        log_debug('hardware_test/hardware_speaker onload') 
    end,
    onshow = function()
        cfun.test("speaker", 1)
        log_debug('hardware_test/hardware_speaker onshow') 
    end,
    ondestroy = function()
        cfun.test("speaker", 0)
        log_debug('hardware_test/hardware_speaker ondestroy') 
    end,

    timer = function ()
        play_timer = play_timer + 1
        if play_timer == 2820 then
            play_timer = 0
        end

        set_data({audio_value = math.floor(play_timer * 600 / 2820)})
    end,
}
return controller