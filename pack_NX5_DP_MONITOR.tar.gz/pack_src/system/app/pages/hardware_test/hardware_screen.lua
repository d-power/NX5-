local time_sec = 0
local index =  1
local color_map = {
    0xffff0000,
    0xffffffff,
    0xff000000,
    0xff00ff00,
    0xff0000ff,
}

local controller =
{
    data = {
        color = 0xffff0000,
        no_screen_off = true
    },
    onload = function()
        common_hidden("set_bar")
        log_debug('hardware_test/hardware_screen onload') 
    end,
    
    onshow = function()
        log_debug('hardware_test/hardware_screen onshow') 
    end,

    ondestroy = function()
        common_show("set_bar")
        log_debug('hardware_test/hardware_screen ondestroy') 
    end,
    
    timer = function()
        time_sec = time_sec + 1
        if time_sec == 10 then
            index = index + 1
            if index == 6 then
                set_page("hardware_test")
            end
            set_data({color = color_map[index]})
            time_sec = 0
        end
    end
}
return controller