
local _map_aimg = {}

for i = 1, 89 do
    _map_aimg[i] = string.format("uvoice/%d.png", i)
end

local view = {
    {
        type        = "text",
        position    = {align =utils_align.IN_BOTTOM_MID, aligny = -100},
        attr        = { content = "{{record_text}}", w = 480, h = 20, align = utils_text.ALIGN_CENTER, 
                        mode = utils_text.MODE_BREAK, c = 0xffffffff,},
    },

    {
        type = "btn",
        position = {align = utils_align.IN_BOTTOM_MID, aligny = -40},
        attr = {res_rel = "setting/btn_ok.png", res_clk = "setting/btn_ok.png"},
        name = "start_record",
        action = {bind = {up = "act"}}
    },
    {
        type        = "text",
        position    = {align =utils_align.CENTER},
        attr        = {content = "{{content}}", w = 480, h = 25, align = utils_text.ALIGN_CENTER, parent = "start_record",
                        mode = utils_text.MODE_BREAK, c = 0xffffffff,},
    },
    {
        type = "aimg",
        position = {align = utils_align.CENTER},
        attr = {
            times = -1,
            interval = 40,
            map = _map_aimg
        },
    },
}
return view