local record_time = -1

local record_state = 0

local state = {
    STATE_DEFAULT       = 0,
    STATE_START_RECORD  = 1,
    STATE_STOP_RECORD   = 2,
    STATE_PLAY_RECORD   = 3
}

record_state = state.STATE_DEFAULT

local controller =
{
    data = {
        no_screensaver = true,
        record_text = "",
        play_hid = true,
        content = "录音",
        no_screen_off = true
    },

    onload = function()
        set_data({now_set = "麦克风", return_page = "hardware_test"})
        log_debug('hardware_test/hardware_mike onload') 
    end,
    onshow = function()
        log_debug('hardware_test/hardware_mike onshow') 
    end,
    ondestroy = function()
        cfun.test("mike", "record", false)
        cfun.test("mike", "paly", false)

        os.execute("rm /system/sound/record.pcm")

        log_debug('hardware_test/hardware_mike ondestroy') 
    end,

    act = function(v)
        if record_state == state.STATE_DEFAULT then
            record_time = 101
            set_data({content = "暂停"})
            cfun.test("mike", "record", true)
            record_state = state.STATE_START_RECORD
        elseif record_state == state.STATE_START_RECORD then
            record_time = -1
            cfun.test("mike", "record", false)
            set_data({content = "播放"})
            record_state = state.STATE_STOP_RECORD
        elseif record_state == state.STATE_STOP_RECORD then
            cfun.test("mike", "paly", true)
            record_time = 101
            set_data({content = "停止播放"})
            record_state = state.STATE_PLAY_RECORD
        elseif record_state == state.STATE_PLAY_RECORD then
            cfun.test("mike", "paly", false)
            record_time = -1
            set_data({content = "录音"})
            record_state = state.STATE_DEFAULT
        end
    end,

    timer = function(v)
        record_time = record_time - 1
        if record_time == 0 then
            if record_state == state.STATE_START_RECORD then
                cfun.test("mike", "record", false)
                record_state = state.STATE_STOP_RECORD
                set_data({content = "播放"})
            elseif record_state == state.STATE_PLAY_RECORD then
                cfun.test("mike", "play", false)
                set_data({content = "录音"})
                record_state = state.STATE_DEFAULT
            end
        end

        if record_time > 0 and record_time % 10 == 0 then
            set_data({record_text = math.floor((10 - record_time/10)) .. "s"})
        elseif record_time <= 0 then
            set_data({record_text = "0s"})
        end

    end,
}
return controller
