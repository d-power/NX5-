local controller =
{
    data = {
        no_screen_off = true
    },
    onload = function()
        set_data({now_set = "老化测试", return_page = "hardware_test"})
        log_debug('hardware_test/hardware_ageing onload') 
    end,
    onshow = function()
        cfun.test("ageing", true)
        log_debug('hardware_test/hardware_ageing onshow') 
    end,
    ondestroy = function()
        cfun.test("ageing", false)
        log_debug('hardware_test/hardware_ageing ondestroy') 
    end,
}
return controller