
local _wifi_map = {}
local app = get_app()
local wifi_scan_default_timeout = 30*10
local wifi_scan_timeout = 1
local want_to_connect_ssid = ""
local want_to_connect_security = 0

local function wifi_map_refresh()
    _wifi_map = {}
    for i = 1, #app.wifi_map do
        _wifi_map[(i -1) * 3 + 1] = app.wifi_map[i].ssid
        _wifi_map[(i -1) * 3 + 2] = app.wifi_map[i].security > 0 and "setting/wifi_pwd_".. (app.wifi_map[i].signal + 1) ..".png" 
                                                                  or "setting/wifi_nopwd_".. (app.wifi_map[i].signal + 1) ..".png"
        _wifi_map[(i -1) * 3 + 3] = "setting/list_line.png"
    end
end

wifi_map_refresh()

local controller =
{
    data = {
        select = false,
        input_pwd_hid = true,
        input_pwd = "",

        btnm_map = kb.abc,
        btnm_map_ctrl = kb.abc_ctrl,

        wifi_map = _wifi_map,

        no_screen_off = true
    },

    onload = function()
        set_data({now_set = "无线网络", return_page = "hardware_test",})
        log_debug('user_setting/setting_wifi onload') 
    end,
    onshow = function()
        log_debug('user_setting/setting_wifi onshow') 
    end,
    ondestroy = function()
        log_debug('user_setting/setting_wifi ondestroy') 
    end,

    list_up = function(v, _index)
        set_data({input_pwd_hid = false, select = true, input_pwd = ""})
        local index = tonumber(_index)
        want_to_connect_ssid = app.wifi_map[index].ssid
        want_to_connect_security = app.wifi_map[index].security
    end,

    btnm_action = function(v, txt)
        if txt == kb.del_txt then
            set_data({input_pwd = this.data.input_pwd:sub(1, -2) })
        elseif txt == "确定" then
            -- 连接wifi
            print(want_to_connect_ssid, this.data.input_pwd, want_to_connect_security)
            wifi.sta.connect(want_to_connect_ssid, this.data.input_pwd, want_to_connect_security)
            popups.show_popups("正在连接WiFi...", 100000)
        elseif txt == "中" then
        elseif txt == "ABC" then
            set_data({ btnm_map = kb.ABC, btnm_map_ctrl = kb.ABC_ctrl, })
        elseif txt == "abc" then
            set_data({ btnm_map = kb.abc, btnm_map_ctrl = kb.abc_ctrl, })
        elseif txt == "1#" then
            set_data({ btnm_map = kb.spec, btnm_map_ctrl = kb.spec_ctrl, })
        else
            set_data({input_pwd = this.data.input_pwd .. txt })
        end
    end,

    timer = function()
        wifi_scan_timeout = wifi_scan_timeout - 1
        if wifi_scan_timeout == 0 then
            wifi.sta.scan()
        end
    end,

    scan_result = function()
        wifi_map_refresh()
        set_data({wifi_map = _wifi_map})
        wifi_scan_timeout = wifi_scan_default_timeout
    end,

    connect_result = function(ch_errno)
        popups.show_popups(ch_errno)
        if ch_errno == "WIFI连接成功！" then
            set_data({input_pwd_hid = true, select = false})
        end
        wifi_scan_timeout = wifi_scan_default_timeout
    end,

    ret_act = function()
        if this.data.input_pwd_hid == false then
            set_data({input_pwd_hid = true, select = false})
            return true
        end
        return false
    end,
}

return controller
