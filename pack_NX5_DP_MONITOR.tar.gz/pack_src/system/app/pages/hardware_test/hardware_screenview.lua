local view = {
    {
        type        = "page",
        position    = {align = utils_align.CENTER},
        attr        = {w = 1024, h = 600, c = "{{color}}", c_bar = 0, layout = utils_page.LAYOUT_OFF,
                       round = false, mode = utils_page.MODE_AUTO},
    }
}

return view