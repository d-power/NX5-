local view = {
    {
        type = "list",
        position = {align = utils_align.IN_TOP_MID, aligny = 60},
        attr =
        {
            w = 896, h = 520, h_line = 70, keep = true, map = "{{test_map}}",
            c_bar = 0x00000000, c = 0x00000000, c_def = 0x00000000, c_clk = 0x00000000,
            map_ctrl =
            {
                {
                    type = utils_list.TYPE_TEXT, x = 10, y = 24, w = 250, h = 40, c = 0xffffffff,
                    content_h = 22, content_algin = utils_list.TEXT_ALIGN_LEFT, 
                    content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
                { type = utils_list.TYPE_IMG, x = 840, y = 30, },
                { type = utils_list.TYPE_IMG, x = 0, y = 69 },
            },
        },
        action = {bind = {change = "list", up = "list_up"}}
    },
    {
        type = "mark",
        position = {align = utils_align.CENTER},
        attr = {w = 1024, h = 600, c = 0x802C2C2C, hidden = "{{mbox_hidden}}"},
        name = "mbox_bg"
    },
    {

        type = "mbox",
        position = {align = utils_align.CENTER},
        attr =
        {
            w = 360, h = 160, h_title = 8, h_body = 24, h_content = 8, h_btn = 50, parent = "mbox_bg",
            c_bg = 0xff525252, c_title = 0x00ffffff, c_body = 0xffffffff, raduis = 10,
            c_btn_clk = 0x0023324b, c_btn_def = 0x00d5d9df, c_content = 0xffffffff,
            body = "测试结束，即将重启", time = 0,
        },
    },
}
return view