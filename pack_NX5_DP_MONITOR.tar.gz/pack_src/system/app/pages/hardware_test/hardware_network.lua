local app = get_app()

local controller =
{
    data = {
        net1_status = app.state.net1 and "网口1：网络已连接" or "网口1：网络未连接",
        net2_status = app.state.net2 and "网口2：网络已连接" or "网口2：网络未连接",
        net1_color = app.state.net1 and 0xffffffff or 0xffff0000,
        net2_color = app.state.net2 and 0xffffffff or 0xffff0000,
        no_screen_off = true
    },
    onload = function()
        set_data({now_set = "有线网络", return_page = "hardware_test"})
        log_debug('hardware_test/hardware_network onload') 
    end,
    onshow = function()
        log_debug('hardware_test/hardware_network onshow') 
    end,
    ondestroy = function()
        log_debug('hardware_test/hardware_network ondestroy') 
    end,
}
return controller