local view = {
    {
        type = "vdec",
        position = {x = 0, y = 96},
        attr = {w = 1024, h = 464, hidden = "{{vdec_hidden}}"}
    },
}
return view