local controller =
{
    data = {
    },
    onload = function()
        log_debug('uvoice/uvoice onload') 
    end,
    onshow = function()
        log_debug('uvoice/uvoice onshow') 
    end,
    ondestroy = function()
        log_debug('uvoice/uvoice ondestroy') 
    end,
}
return controller