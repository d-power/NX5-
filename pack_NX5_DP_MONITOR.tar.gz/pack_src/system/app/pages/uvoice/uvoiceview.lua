local _map = {}

for i = 1, 89 do
    _map[#_map + 1] = string.format("uvoice/%d.png", i)
end

local view = {
    {
        type = "aimg",
        position = {align = utils_align.IN_BOTTOM_MID, aligny = -50},
        attr = {
            times = -1,
            interval = 40,
            map = _map
        },
    },
}
return view