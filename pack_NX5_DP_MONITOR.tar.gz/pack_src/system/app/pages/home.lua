local app = get_app()

local timeout = 0
-- 获取当前模式
local now_mode = 1

local open_door_timeout = 0

-- 获取布防状态
local security_status = app.security_status.SECURITY_STATUS_OFF
for i = 1, #app.security_group do
    if app.security_group[i].state == app.security.state.on and app.security_group[i].type > 2 then
        security_status = app.security_status.SECURITY_STATUS_ON
    end
end

local function reset_security()
    security_status = app.security_status.SECURITY_STATUS_OFF
    local result = safe.disarm(#app.security_group)
    set_data({security_status_content = "未布防", security_hidden = false, countdown_hidden = true, security_status_img = "home/unlock.png", loading_value = 135, security_act_content = "一键布防"})
end

local quick_record = db.get_quick_record().quick_record or {}
local call_record = db.get_call_record().call_record or {}

local _missed_call = false
for _, value in ipairs(call_record) do
    if value.is_callout == 0 and value.is_accept == 0 and value.is_read == 0 then
        _missed_call = true
    end
end

local _notice_map = {}

local _list_h = #quick_record * 86

for index, value in ipairs(quick_record) do
    _notice_map[#_notice_map + 1] = value.message
    _notice_map[#_notice_map + 1] = value.time
    _notice_map[#_notice_map + 1] = "home/notice_line.png"
end

local tab_act = {"setting/tab_select.png", "setting/tab_noselect.png"}
local loading_value = 0 
local security_defult_timeout = app.delay.safe_delay

local date_etoz = { "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六" }

local controller =
{
    data = {
        net1 = not (app.state.net1 or false),      -- 局域网口1
        net2 = not (app.state.net2 or false),      -- 局域网口2
        wifi = not (app.state.wifi or false),            -- wifi
        link = not (app.state.link or false),            -- 链接

        sound_img = (app.sound.enable_mute == 1 or app.sound.ring_vol == 0) and "home/mute.png" or "home/sound.png",

        missed_call = not _missed_call,

        show_act = 0,           -- 显示哪个tab

        mode_name = app.smart_info[now_mode].name,
        smart_state = utils_btn.CLK,

        security_hidden = false,
        countdown_hidden = true,

        security_timeout = 0,
        security_countdown = app.delay.safe_delay .. "S",
        loading_value = security_status == app.security_status.SECURITY_STATUS_OFF and 135 or 135 + 270,
        security_status_img = security_status == app.security_status.SECURITY_STATUS_OFF and "home/unlock.png" or "home/lock.png",
        security_status_content = security_status == app.security_status.SECURITY_STATUS_OFF and "未布防" or "已布防", 
        security_act_content = security_status == app.security_status.SECURITY_STATUS_OFF and "一键布防" or "一键撤防",

        moniter_default = app.monitor_quick.addr,

        list_map = _notice_map,
        list_h = _list_h,

        sos_reciprocal = "home/3.png",
        sos_reciprocal_hidden = true,
        sos_hint = false,
        sos_reciprocal_timeout = 0,

        sos_hint_txt = "请点击【SOS】",
        sos_status_img = "home/sos_act.png",

        open_door_addr = app.open_quick.addr,
        open_door_img = "home/door_default.png",

        tab_select1 = tab_act[1],
        tab_select2 = tab_act[2],
        
        date = string.format("%s/%s %s", os.date("%m"), os.date("%d"), date_etoz[tonumber(os.date("%w") + 1)])
    },
    onload = function()
        set_data({
            tab_select1 = tab_act[(this.data.show_act == 0 ) and 1 or 2],
            tab_select2 = tab_act[(this.data.show_act == 0 ) and 2 or 1]
        })
        common_hidden("set_bar")
    end,

    onshow = function()
        cfun.screen_onoff(1)
    end,
    
    ondestroy = function()
        common_show("set_bar")
    end,

    sos_cancel = function()
        set_data({ sos_reciprocal_hidden = true, sos_hint = false,})
        -- 取消SOS报警
        this.data.sos_reciprocal_timeout = 0
    end,

    tab_change = function(v, tab)
        set_data({
            tab_select1 = tab_act[(tab == "0") and 1 or 2],
            tab_select2 = tab_act[(tab == "0") and 2 or 1]
        })
    end,

    sos_action = function()
        log_debug("sos_act")
        if this.data.sos_status_img == "home/sos_act.png" then
            -- 发送SOS报警
            if not check_web_net_link() then
                popups.show_popups("网络未连接")
            elseif app.state.link then
                set_data({
                    sos_reciprocal_hidden = false,
                    sos_reciprocal = "home/3.png",
                    sos_hint = true,
                })
                this.data.sos_reciprocal_timeout = 30
            else
                popups.show_popups(app.login_fail_reason == "sn is not registered" and "设备未绑定" or "未登入服务器")
            end
        end
    end,

    open_door_act = function(v)
        log_debug("open_door_act")
        -- 发送开门消息
        if this.data.open_door_img == "home/door_default.png" then
            if not check_web_net_link() then
                popups.show_popups("网络未连接")
            elseif app.open_quick.sn ~= "" then
                ws.unlock(app.open_quick.sn)
            elseif app.state.link then
                popups.show_popups("无设备")
            else
                popups.show_popups(app.login_fail_reason == "sn is not registered" and "设备未绑定" or "未登入服务器")
            end
        end
    end,

    moniter_act = function()
        if not check_web_net_link() then
            popups.show_popups("网络未连接")
        elseif app.monitor_quick.name ~= "" then
            set_page("monitor", {monitor_start = true})
        elseif app.state.link then
            popups.show_popups("无设备")
        else
            popups.show_popups(app.login_fail_reason == "sn is not registered" and "设备未绑定" or "未登入服务器")
        end
    end,

    unlock_result = function(result)
        set_data({
            open_door_img = result == "ok" and "home/open_door_success.png" or "home/open_door_fail.png",
            open_door_addr = result == "ok" and "门已开，请进" or "门未开，请重试", 
        })
        open_door_timeout = 30
    end,

    websocket_result = function(cmd, result)
        if cmd == "sos" then
            set_data({
                sos_hint_txt = result == "success" and "报警成功" or "报警失败", 
                sos_status_img = result == "success" and "home/sos_success.png" or "home/sos_fail.png",
                sos_reciprocal_hidden = true, sos_hint = false,
            })
            this.data.sos_reciprocal_timeout = 30
        elseif cmd == "open_door" then
            set_data({
                open_door_status = result == "success" and "门已开，请进" or "门未开，请重试", 
            })
        end
    end,

    smart_change = function(v)
        set_data({smart_state = this.data.smart_state == utils_btn.CLK and utils_btn.CHK_CLK or utils_btn.CLK,})
    end,

    mode_change = function(v)
        now_mode = now_mode + v.user_data
        now_mode = now_mode < 1 and #app.smart_info or now_mode
        now_mode = now_mode > #app.smart_info and 1 or now_mode

        set_data({mode_name = app.smart_info[now_mode].name})
    end,

    goto_more = function(v)
        log_debug(v.next_page)
        local next_msg = {}
        if v.next_page == "smart_home" then
            print(this.data.smart_state)
            next_msg = {
                now_mode = now_mode,
                smart_state = this.data.smart_state
            }
        elseif v.next_page == "open_door" then
            if app.state.link then
                app.door_list = {}
                ws.get_door_list()
            end
        elseif v.next_page == "monitor" then
            if app.state.link then
                app.door_list = {}
                ws.get_door_list()
            end
        end
        set_page(v.next_page, next_msg)
    end,

    call_out = function(v)
        if v.name == "house" then
            log_debug("户户通话")
        elseif v.name == "manager" then
            log_debug("呼叫物管")
            if not check_web_net_link() then
                popups.show_popups("网络未连接")
            elseif app.state.link then
                app.call_info.session_id = phone.phone_management()
                if app.call_info.session_id ~= -1 then
                    set_page("call_out")
                else
                    popups.show_popups("呼叫失败")
                end
            else
                popups.show_popups(app.login_fail_reason == "sn is not registered" and "设备未绑定" or "未登入服务器")
            end
        end
    end,

    call_ladder = function(v)
        popups.show_popups("呼梯失败")
    end,

    security_change = function(v)
        log_debug(security_status)
        if security_status == app.security_status.SECURITY_STATUS_OFF then
            local result = safe.arm(#app.security_group)
            if result.result == "ok" then
                security_status = app.security_status.SECURITY_STATUSING
                loading_value = 135
                set_data({  security_hidden = true, countdown_hidden = false, security_countdown = security_defult_timeout .. "S", 
                            security_timeout = 0, security_act_content = "取消布防"})
            else
                arm_fail_handle(result)
            end
        elseif security_status == app.security_status.SECURITY_STATUSING then
            reset_security()
        elseif security_status == app.security_status.SECURITY_STATUS_ON then
            set_page("security_pwd")
            set_data({return_page = "home"})
        end
    end,

    timer = function()
        if this.data.date ~= string.format("%s/%s %s", os.date("%m"), os.date("%d"), date_etoz[tonumber(os.date("%w") + 1)]) then
            set_data({
                date = string.format("%s/%s %s", os.date("%m"), os.date("%d"), date_etoz[tonumber(os.date("%w") + 1)])
            })
        end
        if security_status == app.security_status.SECURITY_STATUSING then
            this.data.security_timeout = this.data.security_timeout + 1
            if this.data.security_timeout % 10 == 0 then
                set_data({security_countdown = (security_defult_timeout - math.floor(this.data.security_timeout / 10)) .. "s"})
            end

            if this.data.loading_value < 135 + 270 then
                loading_value = loading_value + 27 / security_defult_timeout
                set_data({loading_value = math.floor(loading_value)})
            end

            if this.data.security_timeout == security_defult_timeout * 10 then
                security_status = app.security_status.SECURITY_STATUS_ON 
                for i = 1, #app.security_group do
                    if app.security_group[i].onoff == app.security.onoff.on then
                        app.security_group[i].state = app.security.state.on
                    end
                end
                set_data({  security_act_content = "一键撤防", security_status_content = "已布防", 
                            security_hidden = false, countdown_hidden = true, security_status_img = "home/lock.png",})
            end
        end

        if open_door_timeout > 0 then
            open_door_timeout = open_door_timeout - 1
            if open_door_timeout == 0 then
                set_data({open_door_img = "home/door_default.png", open_door_addr = app.open_quick.addr,})
            end
        end

        if this.data.sos_reciprocal_timeout > 0 then
            this.data.sos_reciprocal_timeout = this.data.sos_reciprocal_timeout - 1
            if this.data.sos_reciprocal_timeout == 0 then
                if this.data.sos_hint == true then
                    ws.sos()
                else
                    set_data({
                        sos_hint_txt = "请点击【SOS】",
                        sos_status_img = "home/sos_act.png"
                    })
                end
                return 
            end
 
            if this.data.sos_reciprocal_timeout % 10 == 0 and this.data.sos_hint == true then
                set_data({
                    sos_reciprocal = "home/".. math.floor(this.data.sos_reciprocal_timeout / 10) ..".png"
                })
            end
        end
    end,

    quick_record_update = function()
        quick_record = db.get_quick_record().quick_record or {}
        _list_h = #quick_record * 86
        _notice_map = {}
        for index, value in ipairs(quick_record) do
            _notice_map[#_notice_map + 1] = value.message
            _notice_map[#_notice_map + 1] = value.time
            _notice_map[#_notice_map + 1] = "home/notice_line.png"
        end

        set_data({
            list_map = _notice_map,
            list_h = _list_h,
        })
    end,
}
return controller