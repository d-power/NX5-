local controller =
{
    data = {
    },
    onload = function()
        common_hidden("set_bar")
        log_debug('screen_off onload') 
    end,
    onshow = function()
        log_debug('screen_off onshow') 
    end,
    ondestroy = function()
        log_debug('screen_off ondestroy') 
    end,

    back_act = function()
        set_page(safe.check_is_alarming() == 0 and "home" or "security")
    end,

}
return controller