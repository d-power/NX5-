local view = {
    {
        type = "vdec",
        position = {x = 0, y = 0},
        attr = {w = 1024, h = 600, hidden = "{{vdec_hidden}}"}
    },
    {
        type = "text",
        position = {x = 940, y = 98},
        attr = {
            w = 128, h = 30, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_LEFT,
            c = 0xffffffff, content ="{{countdown}}",}
    },
    {
        type = "img",
        position = {align = utils_align.CENTER, aligny = -40 },
        attr = {res = "call/default_img.png", hidden = "{{who_img_hidden}}", w = 200, h = 200},
    },
    {
        type = "img",
        position = {align = utils_align.CENTER, aligny = 0 },
        attr = {res = "{{who_img}}", hidden = "{{who_img_hidden}}", w = 1024, h = 600},
    },
    {
        type = "text",
        position = {align = utils_align.IN_TOP_MID,aligny = 380 },
        attr = {
            w = 1024, h = 26, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER,
            c = 0xffffffff, content = "{{who_content}}", }
    },
    {
        type = "btn",
        position = {align = utils_align.IN_BOTTOM_MID, alignx = "{{hangup_posx}}", aligny =  -74 },
        attr = {res_rel = "call/hangup.png", },
        action = {bind = {up = "call_act"}},
        name = "hangup"
    },
    {
        type = "text",
        position = {align = utils_align.IN_BOTTOM_MID, alignx = "{{hangup_content_posx}}", aligny =  -34 },
        attr = {
            w = 128, h = 18, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER,
            c = 0xffffffff, content = "挂断", }
    },
    {
        type = "btn",
        position = {align = utils_align.IN_BOTTOM_MID, alignx = 150, aligny =  -74 },
        attr = {res_rel = "call/accept.png", hidden = "{{accept_hidden}}" },
        action = {bind = {up = "call_act"}},
        name = "accept"
    },
    {
        type = "text",
        position = {align = utils_align.OUT_BOTTOM_MID, aligny = 16, ref = "accept" },
        attr = {
            w = 128, h = 18, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER,
            c = 0xffffffff, content = "接听", hidden = "{{accept_hidden}}" }
    },
    {
        type = "btn",
        position = {align = utils_align.IN_BOTTOM_MID, alignx = "{{lock_posx}}", aligny =  -74 },
        attr = {res_rel = get_app().call_info.lift and "call/elevator.png" or "call/lock.png", hidden = not (get_app().call_info.unlock or get_app().call_info.lift)},
        action = {bind = {up = "call_act"}},
        name = "lock"
    },
    {
        type = "text",
        position = {align = utils_align.IN_BOTTOM_MID, alignx = "{{lock_content_posx}}", aligny =  -34 },
        attr = {
            w = 128, h = 18, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER,
            c = 0xffffffff, content = get_app().call_info.lift and "呼梯" or "开锁", hidden = not (get_app().call_info.unlock or get_app().call_info.lift)}
    },
    {
        type = "slider",
        position = {align = utils_align.IN_RIGHT_MID, alignx = 0},
        attr = {w = 300, h = 480, c = 0x004d4d4d, c_act = 0x00ffffff, c_knob = 0x00FFFFFF, round = false,
                spin = false, min = 0, max = 100, value = 50, mode = utils_slider.MODE_NORMAL},
        action = {bind = {change = "volume_change", up = "volume_up"}},
    },
    {
        type = "slider",
        position = {align = utils_align.IN_LEFT_MID, alignx = 0},
        attr = {w = 300, h = 480, c = 0x004d4d4d, c_act = 0x00ffffff, c_knob = 0x00FFFFFF, round = false,
                spin = false, min = 0, max = 100, value = 50, mode = utils_slider.MODE_NORMAL},
        action = {bind = {change = "light_change", up = "light_up"}},
    },

    {
        type = "img",
        position = {align = utils_align.CENTER, aligny = -40 },
        attr = {res = "call/bg.png", hidden = "{{change_config_hidden}}"},
        name = "change_bg"
    },
    {
        type = "img",
        position = {align = utils_align.CENTER, aligny = -20 },
        attr = {res = "{{now_change_img}}", parent = "change_bg",},
    },
    {
        type = "text",
        position = {align = utils_align.CENTER, alignx = 0, aligny = 60 },
        attr = {
            w = 128, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = "change_bg",
            c = 0xffffffff, content = "{{now_change_content}}",}
    },
    {
        type = "loading",
        position = {align = utils_align.CENTER, aligny = -20 },
        attr = {
            w = 140, w_inner = 2, src = 270, dest = 270 + 360, parent = "change_bg",
            value = "{{loading_value}}", c = 0x00ffffff, c_bg = 0xff6E6E6E, c_act = 0xffffffff
        },
    },
    {
        type = "shared",
        attr = {file = "shared_btn", func = "ctrl_btn", 
                obj = {x = 58, y = 98, name = "cancel", hidden = "{{alarm_hidden}}", txt_height = 20,
                        rel = "setting/btn_cancel.png", act_up = "config_act", txt_color = 0xffff0000,
                        content = "发生报警"}},
    },
}
return view