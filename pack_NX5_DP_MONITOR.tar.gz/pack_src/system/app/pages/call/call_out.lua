local app = get_app()
local timeout = 30 * 10 --app.delay.call_delay * 10;

local frist_val = -1
local last_volume = 0

local is_accept = false

local controller =
{
    data = {
        img_hidden = false,
        content = "正在呼叫物管...",
        vdec_hidden = true,

        change_config_hidden = true,
        now_change_img = "call/volume.png",
        now_change_content = "声音",
        loading_value = 270 + 180,

        countdown = "30S",

        no_screen_off = true,

        alarm_hidden = safe.check_is_alarming() == 0
    },
    onload = function()
        set_data({now_set = "", return_page = "home"})
        log_debug('call/call_out onload')
    end,
    onshow = function()
        log_debug('call/call_out onshow') 
    end,
    ondestroy = function()
        if app.call_info.session_id then
            phone.hangup(app.call_info.session_id)
        end
        lgui_screensaver_reset()
        app.call_info.session_id = -1
        log_debug('call/call_out ondestroy') 
    end,
    
    callout_ack = function(result)
        if result == "ok" then
        else
            popups.show_popups("呼叫失败")
        end
    end,

    popups_hidden_action = function()
        lgui_screensaver_reset()
        phone.hangup(app.call_info.session_id)
        set_page(common.set_bar.data.return_page)
    end,

    call_act = function(v)
        if v.name == "hangup" then
            phone.hangup(app.call_info.session_id)
            set_page(common.set_bar.data.return_page)
        end
    end,

    timer = function()
        timeout = timeout - 1

        if timeout >= 0 then
            set_data({countdown = math.floor(timeout / 10) .. "S"})
        end

        if timeout == 0 then
            lgui_screensaver_reset()
            phone.hangup(app.call_info.session_id)
            set_page(common.set_bar.data.return_page)
        end
    end,

    volume_change = function(v, _val)
        local val = tonumber(_val)
        local change_value = 0
        if frist_val == -1  then 
            frist_val = val
            last_volume = 270 + math.floor((is_accept == true and  app.sound.talk_vol or app.sound.ring_vol) * 360 / 100)  -- this.data.loading_value 
            set_data({loading_value = last_volume + change_value,})
            return 
        elseif val > frist_val then
            change_value = math.floor(((270 + 360) - last_volume) * (val - frist_val) / (100 - frist_val))
        else
            change_value = 0 - math.floor((last_volume - 270) * (frist_val - val) / frist_val)
        end
        set_data({
            change_config_hidden = false, 
            loading_value = last_volume + change_value,
            now_change_img = "call/volume.png",
            now_change_content = "声音",
        })
        log_debug(this.data.loading_value)
        if this.data.loading_value > 270 then
            phone.phone_talk_volume(app.call_info.session_id, math.floor((this.data.loading_value - 270) * 100 / 360))
        end
    end,

    volume_up = function(v)
        frist_val = -1
        if is_accept == true  then
            app.sound.talk_vol = math.floor((this.data.loading_value - 270) * 100 / 360)
        else
            app.sound.ring_vol = math.floor((this.data.loading_value - 270) * 100 / 360)
        end
        set_data({change_config_hidden = true,})
        db.set_sound(app.sound)
    end,

    light_change = function(v, _val)
        local val = tonumber(_val)
        local change_value = 0
        if frist_val == -1  then 
            frist_val = val
            last_volume = 270 + math.floor(app.hw.display_brightness * 360 / 100)
            set_data({loading_value = last_volume + change_value,})
            return 
        elseif val > frist_val then
            change_value = math.floor(((270 + 360) - last_volume) * (val - frist_val) / (100 - frist_val))
        else
            change_value = 0 - math.floor((last_volume - 270) * (frist_val - val) / frist_val)
        end
        set_data({
            change_config_hidden = false, 
            loading_value = last_volume + change_value,
            now_change_img = "call/light.png",
            now_change_content = "亮度",
        })
        app.hw.display_brightness = math.floor((this.data.loading_value - 270) * 100 / 360)
        cfun.screen_set_bright(app.hw.display_brightness)

    end,

    light_up = function(v)
        frist_val = -1
        app.hw.display_brightness = math.floor((this.data.loading_value - 270) * 100 / 360)
        set_data({change_config_hidden = true,})
        db.set_hw(app.hw)
    end,

    callaccept = function(v)
        is_accept = true
        timeout = 60 * 10
    end,

    alarm = function(v)
        set_data({alarm_hidden = false, return_page = "security"})
        return true
    end,

}
return controller