local view = {
    {
        type        = "swiper",
        position    = {align = utils_align.IN_TOP_MID, alignx = 0, aligny = 0},
        attr        = {w = 1024, h = 600, x_area = -688, y_area = 0, w_area = 2400, h_area = 600, mode = utils_swiper.MODE_NORMAL,
                       type = utils_swiper.TYPE_IMG, value = "{{show_value}}", cnt = 3, slt = false,
                       map = "{{swiper_map}}"},
        action      = {bind = {up = "swiper_up", down = "swiper_down", change = "swiper_act"}}
    },
}
return view