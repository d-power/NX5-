local controller =
{
    data = {
        pic_path = ""
    },
    onload = function()
        set_data({now_set = "呼叫图像", 
                  return_page = "record", 
                  return_msg = {
                      notice_color = 0xFFFFFFFF,
                      phone_color = 0xFFF7C754,
                      notice_hidden = true,
                      phone_hidden = false,
                      bar_x = 570
                  } })
        log_debug('record/call_photo onload') 
    end,
    onshow = function()
        log_debug('record/call_photo onshow') 
    end,
    ondestroy = function()
        log_debug('record/call_photo ondestroy') 
    end,
}
return controller