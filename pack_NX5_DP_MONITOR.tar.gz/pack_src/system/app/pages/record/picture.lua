local photo_record = db.get_photo_record().photo_record or {}
local _swiper1 = {}
for index, value in ipairs(photo_record) do
    _swiper1[#_swiper1 + 1] = value.path
end

table.print(_swiper1)

local controller =
{
    data = {
        swiper_map = _swiper1,
        show_value = 0
    },
    onload = function()
        set_data({now_set = "拍照记录", 
                  return_page = "record", 
                  return_msg = {
                    notice_color = 0xFFFFFFFF,
                    picture_color = 0xFFF7C754,
                    notice_hidden = true,
                    picture_hidden = false,
                    bar_x = 452
                  } })
        log_debug('record/picture onload') 
    end,
    onshow = function()
        log_debug('record/picture onshow') 
    end,
    ondestroy = function()
        log_debug('record/picture ondestroy') 
    end,
}

return controller
