local view = {
    {
        type = "img",
        position = {align = utils_align.IN_TOP_MID, aligny = 88},
        attr = {res = "setting/bg.png",}
    },
    {
        type = "blank",
        position = {x = 60, y = 176},
        attr = { w = 120, h = 60},
        action = {bind = {up = "change_record"}},
        name = "notice"
    },
    {
        type = "text",
        position = {align = utils_align.CENTER},
        attr ={ w = 120, h = 20, c = "{{notice_color}}", align = utils_text.ALIGN_CENTER, mode = utils_text.MODE_CROP,
                content = "小区信息", parent = "notice" },
    },
    {
        type = "blank",
        position = {x = 180, y = 176},
        attr = { w = 120, h = 60},
        action = {bind = {up = "change_record"}},
        name = "security"
    },
    {
        type = "text",
        position = {align = utils_align.CENTER},
        attr ={ w = 120, h = 20, c = "{{security_color}}", align = utils_text.ALIGN_CENTER, mode = utils_text.MODE_CROP,
                content = "安防记录", parent = "security" },
    },
    {
        type = "blank",
        position = {x = 300, y = 176},
        attr = { w = 120, h = 60},
        action = {bind = {up = "change_record"}},
        name = "alarm"
    },
    {
        type = "text",
        position = {align = utils_align.CENTER},
        attr ={ w = 120, h = 20, c = "{{alarm_color}}", align = utils_text.ALIGN_CENTER, mode = utils_text.MODE_CROP,
                content = "报警记录", parent = "alarm" },
    },
    {
        type = "blank",
        position = {x = 420, y = 176},
        attr = { w = 120, h = 60},
        action = {bind = {up = "change_record"}},
        name = "picture"
    },
    {
        type = "text",
        position = {align = utils_align.CENTER},
        attr ={ w = 120, h = 20, c = "{{picture_color}}", align = utils_text.ALIGN_CENTER, mode = utils_text.MODE_CROP,
                content = "拍照记录", parent = "picture" },
    },
    {
        type = "blank",
        position = {x = 540, y = 176},
        attr = { w = 120, h = 60},
        action = {bind = {up = "change_record"}},
        name = "phone"
    },
    {
        type = "text",
        position = {align = utils_align.CENTER},
        attr ={ w = 120, h = 20, c = "{{phone_color}}", align = utils_text.ALIGN_CENTER, mode = utils_text.MODE_CROP,
                content = "通话记录", parent = "phone" },
    },
    {
        type = "bar",
        position = {x = "{{bar_x}}", y = 232},
        attr = { w = 58, h = 3, src = 0, dest = 2,round = true, c = 0xFFF7C754, c_act = 0xFFF7C754, value = 2 },
    },

    {
        type = "btn",
        position = {x = 66, y = 120},
        attr = {res_rel = "record/edit.png",},
        action = {bind = {up = "edit_action"}},
        name = "edit",
    },
    {
        type = "text",
        position = {align = utils_align.CENTER},
        attr ={ w = 90, h = 16, c = 0xffffffff, align = utils_text.ALIGN_CENTER, mode = utils_text.MODE_CROP,
                content = "{{edit_content}}", parent = "edit" },
    },

    {
        type = "btn",
        position = {x = 190, y = 522},
        attr = {res_rel = "record/delete.png", hidden = "{{delete_hidden}}"},
        action = {bind = {up = "delete_action"}},
        name = "delete",
    },
    {
        type = "text",
        position = {align = utils_align.CENTER},
        attr ={ w = 90, h = 16, c = 0xffffffff, align = utils_text.ALIGN_CENTER, mode = utils_text.MODE_CROP,
                content = "删除", parent = "delete" },
    },

    {
        type = "btn",
        position = {x = 64, y = 522},
        attr = {
            chk = true, state = "{{selete_state}}", hidden = "{{delete_hidden}}",
            res_rel = "record/check_box.png", res_chk_rel = "record/seleted.png",
        },
        action = {bind = {up = "all_seleted_action"}},
    },
    {
        type = "text",
        position = {x = 116, y = 528},
        attr ={ w = 90, h = 16, c = 0xffffffff, align = utils_text.ALIGN_LEFT, mode = utils_text.MODE_CROP,  hidden = "{{delete_hidden}}",
                content = "全选",},
    },

    {
        type = "list",
        position = {align = utils_align.IN_TOP_MID, aligny = 240},
        attr =
        {
            w = 960, h = 272, h_line = 68, c = 0x00bcc3cd, c_def = 0x00000000, c_clk = 0x00000000, keep = true, c_bar = 0x00000000,
            map = "{{notice_map}}", slidepos = 0, c_edge = 0x00ff0000, hidden = "{{notice_hidden}}",
            map_ctrl =
            {
                { type = utils_list.TYPE_IMG, x = 32, y = 22 },
                { type = utils_list.TYPE_IMG, x = 60, y = 22 },
                { type = utils_list.TYPE_IMG, x = 900, y = 26 },
                {
                    type = utils_list.TYPE_TEXT, x = 84, y = 18, w = 820, h = 30, c = 0xffffffff,
                    content_h = 16, content_algin = utils_list.TEXT_ALIGN_LEFT, content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
                {
                    type = utils_list.TYPE_TEXT, x = 84, y = 46, w = 820, h = 20, c = 0xffffffff,
                    content_h = 14, content_algin = utils_list.TEXT_ALIGN_LEFT, content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
                {
                    type = utils_list.TYPE_IMG, x = 84, y = 67
                },
            },
        },
        action = {bind = {change = "list", up = "list_up"}},
        name = "notice"
    },

    {
        type = "list",
        position = {align = utils_align.IN_TOP_MID, aligny = 240},
        attr =
        {
            w = 960, h = 272, h_line = 68, c = 0x00bcc3cd, c_def = 0x00000000, c_clk = 0x00000000, keep = true, c_bar = 0x00000000,
            map = "{{security_map}}", slidepos = 0, c_edge = 0x00ff0000, hidden = "{{security_hidden}}",
            map_ctrl =
            {
                { type = utils_list.TYPE_IMG, x = 32, y = 22 },
                {
                    type = utils_list.TYPE_TEXT, x = 84, y = 26, w = 820, h = 30, c = 0xffffffff,
                    content_h = 16, content_algin = utils_list.TEXT_ALIGN_LEFT, content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
                {
                    type = utils_list.TYPE_TEXT, x = 84, y = 26, w = 820, h = 20, c = 0xffffffff,
                    content_h = 14, content_algin = utils_list.TEXT_ALIGN_RIGHT, content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
                {
                    type = utils_list.TYPE_IMG, x = 84, y = 67
                },
            },
        },
        action = {bind = {change = "list", up = "list_up"}},
        name = "security"
    },

    {
        type = "list",
        position = {align = utils_align.IN_TOP_MID, aligny = 240},
        attr =
        {
            w = 960, h = 272, h_line = 68, c = 0x00bcc3cd, c_def = 0x00000000, c_clk = 0x00000000, keep = true, c_bar = 0x00000000,
            map = "{{alarm_map}}", slidepos = 0, c_edge = 0x00ff0000, hidden = "{{alarm_hidden}}",
            map_ctrl =
            {
                { type = utils_list.TYPE_IMG, x = 32, y = 22 },
                {
                    type = utils_list.TYPE_TEXT, x = 84, y = 26, w = 820, h = 30, c = 0xffffffff,
                    content_h = 16, content_algin = utils_list.TEXT_ALIGN_LEFT, content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
                {
                    type = utils_list.TYPE_TEXT, x = 84, y = 26, w = 820, h = 20, c = 0xffffffff,
                    content_h = 14, content_algin = utils_list.TEXT_ALIGN_RIGHT, content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
                {
                    type = utils_list.TYPE_IMG, x = 84, y = 67
                },
            },
        },
        action = {bind = {change = "list", up = "list_up"}},
        name = "alarm"
    },

    {
        type = "list",
        position = {align = utils_align.IN_TOP_MID, aligny = 240},
        attr =
        {
            w = 960, h = 272, h_line = 68, c = 0x00bcc3cd, c_def = 0x00000000, c_clk = 0x00000000, keep = true, c_bar = 0x00000000,
            map = "{{picture_map}}", slidepos = 0, c_edge = 0x00ff0000, hidden = "{{picture_hidden}}",
            map_ctrl =
            {
                { type = utils_list.TYPE_IMG, x = 32, y = 22 },
                { type = utils_list.TYPE_IMG, x = 900, y = 26 },
                {
                    type = utils_list.TYPE_TEXT, x = 84, y = 18, w = 820, h = 30, c = 0xffffffff,
                    content_h = 16, content_algin = utils_list.TEXT_ALIGN_LEFT, content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
                {
                    type = utils_list.TYPE_TEXT, x = 84, y = 46, w = 820, h = 20, c = 0xffffffff,
                    content_h = 14, content_algin = utils_list.TEXT_ALIGN_LEFT, content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
                {
                    type = utils_list.TYPE_IMG, x = 84, y = 67
                },
            },
        },
        action = {bind = {change = "list", up = "list_up"}},
        name = "picture"
    },
    {
        type = "list",
        position = {align = utils_align.IN_TOP_MID, aligny = 240},
        attr =
        {
            w = 960, h = 272, h_line = 68, c = 0x00bcc3cd, c_def = 0x00000000, c_clk = 0x00000000, keep = true, c_bar = 0x00000000,
            map = "{{phone_map}}", slidepos = 0, c_edge = 0x00ff0000, hidden = "{{phone_hidden}}",
            map_ctrl =
            {
                { type = utils_list.TYPE_IMG, x = 32, y = 22 },
                { type = utils_list.TYPE_IMG, x = 900, y = 26 },
                { type = utils_list.TYPE_IMG, x = 84, y = 26 },
                {
                    type = utils_list.TYPE_TEXT, x = 130, y = 18, w = 820, h = 30, c = 0xffffffff,
                    content_h = 16, content_algin = utils_list.TEXT_ALIGN_LEFT, content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
                {
                    type = utils_list.TYPE_TEXT, x = 130, y = 46, w = 820, h = 20, c = 0xffffffff,
                    content_h = 14, content_algin = utils_list.TEXT_ALIGN_LEFT, content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
                {
                    type = utils_list.TYPE_IMG, x = 84, y = 67
                },
            },
        },
        action = {bind = {change = "list", up = "list_up"}},
        name = "phone"
    },
}
return view