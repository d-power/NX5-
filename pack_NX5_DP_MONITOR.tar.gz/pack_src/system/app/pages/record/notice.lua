local controller =
{
    data = {
        notice_title = "贴心服务暖人心——大富社区公共志愿服务日活动",
        notice_content = "      为了更好地给社区居民生活带来方便,用实际行动开展各种关怀他人,服务社会、促进社会和谐的公益活动,让居民在家门口就可以享受到众多的贴心服务,3月7日,大富社区志愿服务组织常态化公共服务日活动走进香榭大院小区,一如既往地服务社区居民。推进社区志愿服务稳步发展,营造出邻里守望相助的和谐氛围。\n发布时间: 2021-01-01 00:00:00"
    },
    onload = function()
        set_data({now_set = "小区信息", return_page = "record"})
        log_debug('record/notice onload') 
    end,
    onshow = function()
        log_debug('record/notice onshow') 
    end,
    ondestroy = function()
        log_debug('record/notice ondestroy') 
    end,
}
return controller