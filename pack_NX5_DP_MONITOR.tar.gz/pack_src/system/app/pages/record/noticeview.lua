local view = {
    {
        type        = "page",
        position    = {align = utils_align.IN_TOP_MID, alignx = 10, aligny = 90},
        attr        = {w = 960, h = 480, c = 0x00000000, c_bar = 0x00808080, layout = utils_page.LAYOUT_OFF,
                       round = false, mode = utils_page.MODE_OFF},
        name        = "page0",
        action       = {bind = {change = function(v, posx, posy) log_debug(3, "pos ",  posx, posy) end}}
    },
    {
        type = "text",
        position = {x = 50, y = 36},
        attr = {
            w = 860, h = 22, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = "page0",
            c = 0xffffffff, content = "{{notice_title}}", }
    },

    {
        type = "text",
        position = {x = 50, y = 80},
        attr = {
            w = 860, h = 18, mode = utils_text.MODE_BREAK, align = utils_text.ALIGN_LEFT, parent = "page0",
            c = 0xffffffff, content = "{{notice_content}}", }
    },
}
return view