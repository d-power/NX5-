local text_color = { 0xFFF7C754, 0xFFFFFFFF }
local tab_act = {"setting/tab_select.png", "setting/tab_noselect.png"}

local pos_list = {
    notice   = 90,
    security = 208,
    alarm    = 330,   
    picture  = 452,
    phone    = 570,
}
local app = get_app()

local quick_record = db.get_quick_record().quick_record or {}

table.print(quick_record)

-- 布撤防记录
local safe_record = db.get_safe_record().safe_record or {}
local _security_map = {}

for _, value in ipairs(safe_record) do
    _security_map[#_security_map + 1] = ""
    _security_map[#_security_map + 1] = (value.pos or "") ..'-'..
                                       (app.area_map[value.area + 1] or "") ..'-'..
                                       (app.type_map[value.type + 1] or "") ..'-'..
                                       (value.state == 1 and "布防" or "撤防")
    _security_map[#_security_map + 1] = value.time
    _security_map[#_security_map + 1] = "record/list_line.png"
end

-- 报警记录
local alarm_record = db.get_alarm_record().alarm_record or {}
local _alarm_map = {}
for _, value in ipairs(alarm_record) do
    _alarm_map[#_alarm_map + 1] = ""
    _alarm_map[#_alarm_map + 1] = (app.area_map[value.area + 1] or "") ..
                                  (app.type_map[value.type + 1] or "")
    _alarm_map[#_alarm_map + 1] = value.time
    _alarm_map[#_alarm_map + 1] = "record/list_line.png"
end

-- 通话记录
local call_record = db.get_call_record().call_record or {}
local _phone_map = {}
local function recolor(txt, en)
    return en == 0 and get_recolor_str(txt, "FF1815") or txt
end

for _, value in ipairs(call_record) do
    _phone_map[#_phone_map + 1] = ""
    _phone_map[#_phone_map + 1] = "" --[[(value.img_path == "") and "" or "home/right.png"]]
    _phone_map[#_phone_map + 1] = value.is_callout == 1 and "record/out.png" or 
                                  value.is_accept == 0 and "record/miss.png" or "record/in_accpet.png"
    _phone_map[#_phone_map + 1] = recolor(value.position, (value.is_accept == 0) and (value.is_callout == 0))
    _phone_map[#_phone_map + 1] = value.time
    _phone_map[#_phone_map + 1] = "record/list_line.png"
end

-- 拍照记录
local photo_record = db.get_photo_record().photo_record or {}
local _picture_map = {}

for index, value in ipairs(photo_record) do
    _picture_map[#_picture_map + 1] = ""
    _picture_map[#_picture_map + 1] = "home/right.png"
    _picture_map[#_picture_map + 1] = value.position
    _picture_map[#_picture_map + 1] = value.time
    _picture_map[#_picture_map + 1] = "record/list_line.png"
end

local notice_record = db.get_message_record().message_record or {}
local _notice_map = {}

local function refresh_notice ()
    _notice_map = {}
    for index, value in ipairs(notice_record) do
        _notice_map[#_notice_map + 1] = "record/record_img.png"
        _notice_map[#_notice_map + 1] = value.read == 0 and "record/unread.png" or ""
        _notice_map[#_notice_map + 1] = "home/right.png"
        _notice_map[#_notice_map + 1] = value.title or ""
        _notice_map[#_notice_map + 1] = value.time or ""
        _notice_map[#_notice_map + 1] = "record/list_line.png"
    end
end

refresh_notice()

-- 当前改变的列表
local change_map = {}
local change_name = ""
local map_w = 0
local selete_line = {}

local delete_db_record = {
    notice_map = function(index)
        db.delete_message_record(notice_record[index].id)
        table.remove(notice_record, index)
    end,

    security_map = function(index)
        db.delete_safe_record(safe_record[index].id)
        table.remove(safe_record, index)
    end,

    alarm_map = function(index)
        db.delete_alarm_record(alarm_record[index].id)
        table.remove(alarm_record, index)
    end,

    picture_map = function(index)
        db.delete_photo_record(photo_record[index].id)
        table.remove(photo_record, index)
    end,

    phone_map = function(index)
        db.delete_call_record(call_record[index].id)
        table.remove(call_record, index)
    end
}

local function check_and_delete_quick_record(ind)
    for index, value in ipairs(quick_record) do
        local now_delete_type = 0
        local now_delete_map = {}
        local delete = false

        local function _check(type, time, message)
            delete = value.type == type and 
                    value.time == time and 
                    value.message == message

            log_debug(type, time, message, delete)
        end

        if change_name == "notice_map" then
            _check(0, notice_record[ind].time, notice_record[ind].title)
        elseif change_name == "security_map" then
            _check(1, safe_record[ind].time, (safe_record[ind].pos or "") ..'-'..
                                                (app.area_map[safe_record[ind].area + 1] or "") ..'-'..
                                                (app.type_map[safe_record[ind].type + 1] or "") ..'-'..
                                                (safe_record[ind].state == 1 and "布防" or "撤防"))
        elseif change_name == "alarm_map" then
            _check(2, alarm_record[ind].time, (app.area_map[alarm_record[ind].area + 1] or "") ..
                                                 (app.type_map[alarm_record[ind].type + 1] or ""))
        elseif change_name == "picture_map" then
            _check(3, photo_record[ind].time, photo_record[ind].position)
        elseif change_name == "phone_map" then
            _check(4, call_record[ind].time, call_record[ind].position)
        end
        
        if delete then
            db.delete_quick_record(value.id)
            table.remove(quick_record, index)
            table.print(quick_record)
            return 
        end

    end
end

local controller =
{
    data = {
        notice_color = text_color[1],
        security_color = text_color[2],
        alarm_color = text_color[2],
        picture_color = text_color[2],
        phone_color = text_color[2],
        bar_x = 90,

        edit_content = "编辑",
        delete_hidden = true,
        selete_state = utils_btn.REL,

        notice_hidden = false,
        notice_map = _notice_map,

        security_hidden = true,
        security_map = _security_map,

        alarm_hidden = true,
        alarm_map = _alarm_map,

        picture_hidden = true,
        picture_map = _picture_map,

        phone_hidden = true,
        phone_map = _phone_map,

    },
    onload = function()
        set_data({now_set = "记录中心"})
        if this.data.notice_hidden == false then
            change_map = _notice_map map_w = 6 change_name = "notice_map"
        elseif this.data.picture_hidden == false then
            change_map = _picture_map map_w = 5 change_name = "picture_map"
        end
        log_debug('record/record onload') 
    end,
    onshow = function()
        set_data({return_page = "home", return_msg = {show_act = 1}})
        log_debug('record/record onshow') 
    end,
    ondestroy = function()
        log_debug('record/record ondestroy') 
    end,

    notice_update = function(result)
        if result.result == "ok" then
            notice_record = db.get_message_record().message_record or {}
            refresh_notice()
            set_data({notice_map = _notice_map})
        end
    end,

    edit_action = function()
        selete_line = {}
        if this.data.notice_hidden == false then
            change_map = _notice_map map_w = 6 change_name = "notice_map"
        elseif this.data.security_hidden == false then
            change_map = _security_map map_w = 4 change_name = "security_map"
        elseif this.data.alarm_hidden == false then
            change_map = _alarm_map map_w = 4 change_name = "alarm_map"
        elseif this.data.picture_hidden == false then
            change_map = _picture_map map_w = 5 change_name = "picture_map"
        elseif this.data.phone_hidden == false then
            change_map = _phone_map map_w = 6 change_name = "phone_map"
        end

        for i = 0, (#change_map / map_w) - 1 do
            change_map[map_w * i + 1] = this.data.delete_hidden and "record/check_box.png" 
                                                                or (change_name == "notice_map" and "record/record_img.png" or "")
            if change_name == "notice_map" then
                change_map[map_w * i + 2] = this.data.delete_hidden and "" or ""
            end
        end

        set_data({
            [change_name] = change_map,
            edit_content = this.data.delete_hidden and "完成" or "编辑",
            delete_hidden = not this.data.delete_hidden,
            selete_state = utils_btn.REL,
        })
    end,

    all_seleted_action = function(v)
        selete_line = {}
        for i = 0, (#change_map / map_w) - 1 do
            change_map[map_w * i + 1] = this.data.selete_state == utils_btn.REL and "record/seleted.png" or "record/check_box.png"
        end

        set_data({
            [change_name] = change_map,
            selete_state = this.data.selete_state == utils_btn.REL and utils_btn.CHK_REL or utils_btn.REL 
        })

        if this.data.selete_state == utils_btn.CHK_REL then
            for i = 1, (#change_map / map_w) do
                selete_line[i] = i
            end
        end
    end,

    delete_action = function(v)
        if #selete_line == 0 then
            popups.show_popups("请选择要删除的记录？", 3, 360)
        else
            popups.show_popups_with_select("删除记录", "确定要删除选中记录？")
        end
    end,

    popups_action = function(v)
        if v.name == "popups_ok" then
            table.sort(selete_line, function(a,b) return a > b end)
            table.print(selete_line)
            for i = 1, #selete_line do
                for j = 0, map_w - 1 do
                    table.remove(change_map, map_w * (selete_line[i] - 1) + (map_w - j))
                end

                local index = tonumber(selete_line[i])
                check_and_delete_quick_record(index)
                if delete_db_record[change_name] then delete_db_record[change_name] (index) end
            end

            popups.show_popups("删除成功")
            selete_line = {}
            set_data({ [change_name] = change_map,  selete_state = utils_btn.REL})
        end
        popups.hidden_popups_with_select()
    end,

    list_up = function(v, _line)
        local line = tonumber(_line)
        if this.data.delete_hidden == false then            
            change_map[map_w * (line - 1) + 1] = change_map[map_w * (line - 1) + 1] == "record/check_box.png" and "record/seleted.png" or "record/check_box.png"
            set_data({ [change_name] = change_map })

            if change_map[map_w * (line - 1) + 1] == "record/seleted.png" then
                table.insert(selete_line, line)

                if #selete_line == (#change_map / map_w) then
                    set_data({selete_state = utils_btn.CHK_REL})
                end
            else
                for i = 1, #selete_line do
                    if selete_line[i] == line then
                        table.remove(selete_line, i)
                        break
                    end
                end
            end
        elseif v.name == "notice" then
            if notice_record[line].read == 0 then
                notice_record[line].read = 1
                db.set_message_record(notice_record[line])
            end

            set_page("notice", {
                notice_title = notice_record[line].title or "",
                notice_content = notice_record[line].content or ""
            })
        elseif v.name == "picture" then
            set_page("picture", {show_value = line - 1})
        end
    end,

    change_record = function(v)

        -- if this.data.delete_hidden == false then
        --     popups.show_popups("请完成当前操作")
        --     return
        -- end
        if this.data.delete_hidden == false then
            for i = 0, (#change_map / map_w) - 1 do
                change_map[map_w * i + 1] = (change_name == "notice_map" and "record/record_img.png" or "")
                if change_name == "notice_map" then
                    change_map[map_w * i + 2] = ""
                end
            end
        end

        local up_list = {

            edit_content = "编辑",
            delete_hidden = true,
            selete_state = utils_btn.REL,

            notice_color = text_color[2],
            security_color = text_color[2],
            alarm_color = text_color[2],
            picture_color = text_color[2],
            phone_color = text_color[2],
            bar_x = pos_list[v.name],

            notice_hidden = true,
            security_hidden = true,
            alarm_hidden = true,
            picture_hidden = true,
            phone_hidden = true,
        }
        up_list[v.name .. "_color"] = text_color[1]
        up_list[v.name .. "_hidden"] = false

        if v.name == "phone" then
            for index, value in ipairs(call_record) do
                if value.is_read == 0 then
                    value.is_read = 1
                    db.set_call_record(value)
                end
            end
        end

        set_data(up_list)
    end,

    quick_record_update = function()
        quick_record = db.get_quick_record().quick_record or {}
    end
}

return controller
