local view = {
    {
        type = "img",
        position = {align = utils_align.CENTER, alignx = 0},
        attr = {res = "{{pic_path}}",  w = 800, h = 420},
    },     
}
return view