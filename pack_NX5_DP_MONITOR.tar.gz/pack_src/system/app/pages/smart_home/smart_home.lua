local controller =
{
    data = {
    },
    onload = function()
        table.print(this.data)
        set_data({
            now_set = "智能家居", return_page = "home", return_msg = {show_act = 0},
            ["smart_state" .. this.data.now_mode] = this.data.smart_state
        })
        log_debug('smart_home/smart_home onload') 
    end,
    onshow = function()
        log_debug('smart_home/smart_home onshow') 
    end,
    ondestroy = function()
        log_debug('smart_home/smart_home ondestroy') 
    end,
}

local smart_info = get_app().smart_info

if smart_info == nil then
    return controller
end

for i = 1, #smart_info do
    controller.data["smart_state" .. i] = utils_btn.CLK
end

return controller
