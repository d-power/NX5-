local view = {
    {
        type        = "page",
        position    = {align = utils_align.IN_TOP_MID, alignx = 10, aligny = 90},
        attr        = {w = 840, h = 500, c = 0x00000000, c_bar = 0x00808080, layout = utils_page.LAYOUT_GRID,
                       round = false, mode = utils_page.MODE_OFF},
        name        = "page0",
        action       = {bind = {change = function(v, posx, posy) log_debug(3, "pos ",  posx, posy) end}}
    },
}


local smart_info = get_app().smart_info

if smart_info == nil then
    return view
end

for i = 1, #smart_info do
    view[#view + 1] = {
        type = "btn",
        position = {x = 0, y = 0},
        attr = {
            chk = true, state = "{{smart_state".. i .. "}}",
            res_rel = "smart_home/smart_rel.png", res_chk_rel = "smart_home/smart_chk.png", parent = "page0"
        },
        user_data = i,
        name = "smart" .. i
    }

    view[#view + 1] = {
        type = "img",
        position = {align = utils_align.CENTER, aligny = -18},
        attr = { res = smart_info[i].img, parent = "smart" .. i},
    }

    view[#view + 1] = {
        type = "text",
        position = {align = utils_align.CENTER, aligny = 40},
        attr = {
            w = 128, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = "smart" .. i,
            c = 0xffffffff, content = smart_info[i].name, }
    }
end

return view
