local view = {
    {
        type = "mark",
        position = {align = utils_align.CENTER},
        attr = {w = 1024, h = 600, c = 0x202C2C2C, hidden = "{{popups_hidden}}"},
        name = "popups_bg"
    },
    {
        type = "img",
        position = {align = utils_align.CENTER},
        attr = {res = "home/popup_bg.png", w = "{{popups_w}}", h = "{{popups_h}}", parent = "popups_bg"},
        name = "popups_text_bg"
    },
    {
        type = "text",
        position = {align = utils_align.CENTER},
        attr = {
            w = 480, h = 26, mode = utils_text.MODE_BREAK, align = utils_text.ALIGN_CENTER, parent = "popups_bg",
            c = 0xffffffff, content = "{{popups_content}}", }
    },


    {
        type = "mark",
        position = {align = utils_align.CENTER},
        attr = {w = 1024, h = 600, c = 0x802C2C2C, hidden = "{{popups_with_select_hidden}}"},
        name = "popups_with_select_bg"
    },
    {
        type = "img",
        position = {align = utils_align.CENTER},
        attr = {res = "popups/popup_bg.png", parent = "popups_with_select_bg"},
        name = "popups_with_select_text_bg"
    },
    {
        type = "text",
        position = {align = utils_align.IN_TOP_MID, aligny = 66},
        attr = {
            w = 380, h = 26, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = "popups_with_select_text_bg",
            c = 0xffffffff, content = "{{popups_title}}", }
    },
    {
        type = "text",
        position = {align = utils_align.IN_TOP_MID, aligny = 120},
        attr = {
            w = 380, h = 16, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = "popups_with_select_text_bg",
            c = 0xffffffff, content = "{{popups_text}}", }
    },
    {
        type = "shared",
        attr = {file = "shared_btn", func = "ctrl_btn", 
                obj = {x = 216, y = 180, name = "popups_ok",  parent = "popups_with_select_text_bg",
                        rel = "popups/btn_ok.png", act_up = "popups_btn_act",
                        content = "确定"}},
    },
    {
        type = "shared",
        attr = {file = "shared_btn", func = "ctrl_btn", 
                obj = {x = 64, y = 180, name = "popups_cancel", parent = "popups_with_select_text_bg",
                        rel = "popups/btn_cancel.png", act_up = "popups_btn_act",
                        content = "取消"}},
    },

    {
        type = "mark",
        position = {align = utils_align.CENTER},
        attr = {w = 1024, h = 600, c = 0x802C2C2C, hidden = "{{popups_upgrade}}"},
        name = "popups_upgrade_bg"
    },
    {
        type = "img",
        position = {align = utils_align.CENTER},
        attr = {res = "upgrade.png", parent = "popups_upgrade_bg"},
        name = "popups_upgrade_img"
    },
    {
        type = "text",
        position = {align = utils_align.IN_TOP_MID, aligny = 80},
        attr = {
            w = 380, h = 26, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = "popups_upgrade_img",
            c = 0xffffffff, content = "{{update_schedule}}", }
    },
    {
        type = "bar",
        position = {align = utils_align.IN_TOP_MID, aligny = 156},
        attr =
        {
            w = 300, h = 26, src = 0, dest = 100, time = 0, round = true, parent = "popups_upgrade_img",
            c = 0xFF2C2C2C, c_act = 0xFFFCAE48, value = "{{schedule_value}}",
        },
    }
}
return view