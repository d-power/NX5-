local timer_sec = 0

local controller =
{
    data = {
        popups_content = "",
        popups_hidden = true,
        timeout = 0,
        popups_w = -1,
        popups_h = -1,

        popups_with_select_hidden = true,
        popups_title = "",
        popups_text = "",
        select_timeout = 0,

        update_schedule = "系统升级中",
        popups_upgrade = true,
        hidden_timeout = 0,
        schedule_value = 50
    },
    onload = function()
    end,
    onshow = function()
    end,
    ondestroy = function()
    end,

    timer = function()

        timer_sec = timer_sec + 1
        if timer_sec == 5 then
            timer_sec = 0
            if common.popups.data.schedule_value >= 50 and common.popups.data.schedule_value < 73 then
                set_data({schedule_value = common.popups.data.schedule_value + 1})
            elseif common.popups.data.schedule_value >= 75 and common.popups.data.schedule_value < 99 then
                set_data({schedule_value = common.popups.data.schedule_value + 1})
            end
        end

        if common.popups.data.hidden_timeout > 0 then
            common.popups.data.hidden_timeout = common.popups.data.hidden_timeout - 1
            if common.popups.data.hidden_timeout == 0 then
                popups.hidden_upgrade_schedule(0)
            end
        end

        if common.popups.data.timeout > 0 then
            common.popups.data.timeout = common.popups.data.timeout - 1
            if common.popups.data.timeout == 0 then
                set_data({
                    popups_hidden = true,
                    popups_w = 0,
                    popups_h = 0,
                });
                (this.popups_hidden_action or no_fun) ()
            end
        end

        if common.popups.data.select_timeout > 0 then
            common.popups.data.select_timeout = common.popups.data.select_timeout - 1
            if common.popups.data.select_timeout == 0 then
                popups.hidden_popups_with_select();
                (this.popups_select_hidden_action or no_fun) ()
            end
        end
    end,

    popups_btn_act = function(v)
        local function default_action(v)
            if v.name == "popups_cancel" then
                popups.hidden_popups_with_select()
            end
        end

        (this.popups_action or default_action)(v)
    end
}
return controller
