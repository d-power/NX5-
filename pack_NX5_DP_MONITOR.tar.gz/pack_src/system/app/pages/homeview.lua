local view = {
    -- top
    {
        type        = "page",
        position    = {x = 10, y = 20},
        attr        = {w = 300, h = 80, c = 0x00000000, c_bar = 0x00808080, layout = utils_page.LAYOUT_ROW_TOP,
                       round = false, mode = utils_page.MODE_OFF, inner = 0},
        name        = "page_net"
    },
    {
        type = "img",
        position = {x = 0, y = 0},
        attr = {res = "home/network.png", hidden = "{{net1}}", parent = "page_net"},
    },
    {
        type = "img",
        position = {x = 0, y = 0},
        attr = {res = "home/network.png", hidden = "{{net2}}", parent = "page_net"},
    },
    {
        type = "img",
        position = {x = 0, y = 0},
        attr = {res = "home/wifi.png", hidden = "{{wifi}}", parent = "page_net"},
    },
    {
        type = "img",
        position = {x = 0, y = 0},
        attr = {res = "home/link.png", hidden = "{{link}}", parent = "page_net"},
    },

    -- 电话
    {
        type = "img",
        position = {x = 800, y = 20},
        attr = {res = "home/phone.png", hidden = "{{missed_call}}", parent = "page_net"},
    },
    -- 消息
    {
        type = "img",
        position = {x = 854, y = 20},
        attr = {res = "home/message.png", parent = "page_net"},
    },
    -- 铃声
    {
        type = "img",
        position = {x = 908, y = 20},
        attr = {res = "{{sound_img}}", parent = "page_net"},
    },
    {
        type = "btn",
        position = {x = 948, y = 8},
        attr = {res_rel = "home/setting.png", parent = "page_message"},
        action = {bind = {up = function() set_page("setting") end}}
    },
    -- tab
    {
        type = "tab",
        position = {align = utils_align.IN_TOP_MID, alignx = 0, aligny = 80},
        attr = {w = 1024, h = 520, tab = "{{show_act}}"},
        action = {bind = {up = "tab_up", down = "tab_down", change = "tab_change"}},
        name = "tab_bg"
    },
    {type = "tab", position = {}, attr = {parent = "tab_bg"}, name = "tab0"},
    {type = "tab", position = {}, attr = {parent = "tab_bg"}, name = "tab1"},
    
    {
        type = "img",
        position = {align = utils_align.IN_BOTTOM_MID, aligny = -18, alignx = -12},
        attr = {res = "{{tab_select1}}"}
    },
    {
        type = "img",
        position = {align = utils_align.IN_BOTTOM_MID, aligny = -18, alignx = 12},
        attr = {res = "{{tab_select2}}"}
    },

    {
        type = "img",
        position = {x = 16, y = 12},
        attr = {res = "home/weather_bg.png", parent = "tab0"},
        name = "weather"
    },
    {
        type = "clock",
        position = {align = utils_align.IN_TOP_MID, alignx = 0, aligny = 50},
        attr = {
            w = 240, h = 50, align = utils_clock.ALIGN_CENTER, parent = "weather",
            c = 0xffffffff, fmt = "%H:%M",}
    },
    {
        type = "img",
        position = {align = utils_align.CENTER, aligny = 10},
        attr = {res = "weather/sun.png", parent = "weather"},
    },
    {
        type = "text",
        position = {align = utils_align.IN_BOTTOM_MID, alignx = 0, aligny = -26},
        attr = {
            w = 240, h = 26, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = "weather",
            c = 0xffffffff, content = "{{date}}" }
    },
    {
        type = "btn",
        position = {x = 16, y = 386},
        attr = {res_rel = "home/callladder_bg.png", parent = "tab0"},
        action = {bind = {up = "call_ladder"}},
        name = "callladder"
    },
    {
        type = "img",
        position = {align = utils_align.IN_LEFT_MID, alignx = 30},
        attr = {res = "home/callladder.png", parent = "callladder"},
    },
    {
        type = "text",
        position = {align = utils_align.IN_LEFT_MID, alignx = 78, aligny = 0},
        attr = {
            w = 160, h = 20, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = "callladder",
            c = 0xffffffff, content = "一键呼梯", }
    },
    {
        type = "shared",
        attr = {file = "shared_btn", func = "home_shared_moudle", 
                obj = {x = 268, name = "security", text = "家庭安防", next_page = "security", parent = "tab0"}},
    },
    {
        type = "loading",
        position = {x = 18, y = 100},
        attr = {
            w = 200, w_inner = 6, src = 135, dest = 135 + 270, parent = "security",
            value = "{{loading_value}}", c = 0x00ffffff, c_bg = 0xff6E6E6E, c_act = 0xffffffff
        },
    },
    {
        type = "img",
        position = {align = utils_align.CENTER, aligny = -46 },
        attr = {res = "{{security_status_img}}", parent = "security", hidden = "{{security_hidden}}"},
    },
    {
        type = "text",
        position = {align = utils_align.CENTER, aligny = 6},
        attr = {
            w = 180, h = 18, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = "security", hidden = "{{security_hidden}}",
            c = 0xffffffff, content = "{{security_status_content}}", }
    },
    {
        type = "text",
        position = {align = utils_align.CENTER, aligny = -34},
        attr = {
            w = 180, h = 36, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = "security", hidden = "{{countdown_hidden}}",
            c = 0xffffffff, content = "{{security_countdown}}", }
    },
    {
        type = "img",
        position = {align = utils_align.CENTER, aligny = 30 },
        attr = {res = "home/point.png", parent = "security"},
    },
    {
        type = "shared",
        attr = {file = "shared_btn", func = "ctrl_btn", 
                obj = {x = 54, y = 314, parent = "security", name = "security_act", 
                        rel = "home/security_act.png", act_up = "security_change",
                        content = "{{security_act_content}}"}},
    },
    {
        type = "shared",
        attr = {file = "shared_btn", func = "home_shared_moudle", 
                obj = {x = 520, name = "smart_home", text = "智能家居", next_page = "smart_home", parent = "tab0"}},
    },
    {
        type = "img",
        position = {align = utils_align.CENTER, aligny = -26 },
        attr = {res = "home/mode_bg.png", parent = "smart_home"},
    },
    {
        type = "btn",
        position = {align = utils_align.CENTER, aligny = -26},
        attr = {
            chk = true, state = "{{smart_state}}",
            res_rel = "home/mode_switch_off.png", res_chk_rel = "home/mode_switch_on.png", parent = "smart_home"
        },
        action = {bind = {up = "smart_change"}},
        name = "security_act"
    },
    {
        type = "img",
        position = {align = utils_align.CENTER, aligny = 100 },
        attr = {res = "home/empty_btn.png", parent = "smart_home"},
        name = "mode_name_bg"
    },
    {
        type = "text",
        position = {align = utils_align.CENTER},
        attr = {
            w = 128, h = 16, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = "mode_name_bg",
            c = 0xffffffff, content = "{{mode_name}}", }
    },
    {
        type = "img",
        position = {align = utils_align.OUT_LEFT_MID, alignx = -20, ref = "mode_name_bg"},
        attr = {res = "home/left.png", parent = "smart_home"},
    },     
    {
        type = "blank",
        position = {align = utils_align.OUT_LEFT_MID, alignx = 0, ref = "mode_name_bg"},
        attr = {w = 52, h = 52, parent = "smart_home"},
        action = {bind = {up = "mode_change"}},
        user_data = -1
    },
    {
        type = "img",
        position = {align = utils_align.OUT_RIGHT_MID, alignx = 20, ref = "mode_name_bg"},
        attr = {res = "home/right.png", parent = "smart_home"},
        action = {bind = {up = "mode_change"}},
        user_data = 1
    },     
    {
        type = "blank",
        position = {align = utils_align.OUT_RIGHT_MID, alignx = 0, ref = "mode_name_bg"},
        attr = {w = 52, h = 52, parent = "smart_home"},
        action = {bind = {up = "mode_change"}},
        user_data = 1
    },

    {
        type = "shared",
        attr = {file = "shared_btn", func = "home_shared_moudle", 
                obj = {x = 772, name = "address_book", text = "可视对讲", 
                parent = "tab0", content = ""}},
    },
    {
        type = "img",
        position = {align = utils_align.IN_TOP_MID, aligny = 118 },
        attr = {res = "home/avatar.png", parent = "address_book"},
    },
    -- {
    --     type = "shared",
    --     attr = {file = "shared_btn", func = "ctrl_btn", 
    --             obj = {x = 54, y = 286, parent = "address_book", name = "house", 
    --                     rel = "home/security_act.png", act_up = "call_out",
    --                     content = "户户通话"}},
    -- },
    {
        type = "shared",
        attr = {file = "shared_btn", func = "ctrl_btn", 
                obj = {x = 54, y = 314, parent = "address_book", name = "manager", 
                        rel = "home/empty_btn.png", act_up = "call_out",
                        content = "呼叫物管"}},
    },
    {
        type = "shared",
        attr = {file = "shared_btn", func = "home_shared_moudle", 
                obj = {x = 16, name = "surveillance", text = "监视中心", next_page = "monitor", parent = "tab1"}},
    },
    {
        type = "btn",
        position = {align = utils_align.IN_TOP_MID, aligny = 120 },
        attr = {res_rel = "home/moniter.png", parent = "surveillance"},
        action = {bind = {up = "moniter_act"}},
        name = "moniter_img"
    },
    {
        type = "text",
        position = {align = utils_align.IN_BOTTOM_MID, aligny = -122},
        attr = {
            w = 230, h = 18, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = "surveillance",
            c = 0xffffffff, content = "{{moniter_default}}", }
    },

    {
        type = "shared",
        attr = {file = "shared_btn", func = "home_shared_moudle", 
                obj = {x = 268, name = "open_door_bg", text = "一键开门", next_page = "open_door", parent = "tab1"}},
    },

    {
        type = "btn",
        position = {align = utils_align.IN_TOP_MID, aligny = 120 },
        attr = {res_rel = "{{open_door_img}}", parent = "open_door_bg"},
        action = {bind = {up = "open_door_act"}},
        name = "moniter_img"
    },
    {
        type = "text",
        position = {align = utils_align.IN_BOTTOM_MID, aligny = -122},
        attr = {
            w = 230, h = 18, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = "open_door_bg",
            c = 0xffffffff, content = "{{open_door_addr}}", }
    },
    {
        type = "shared",
        attr = {file = "shared_btn", func = "home_shared_moudle", 
                obj = {x = 520, name = "open_door_bg", text = "记录中心", next_page = "record", parent = "tab1"}},
    },

    {
        type = "list",
        position = {x = 520, y = 72},
        attr =
        {
            w = 210, h = "{{list_h}}", h_line = 86, c = 0x00bcc3cd, c_def = 0x00000000, c_clk = 0x00000000, keep = true, c_bar = 0x00000000,
            map = "{{list_map}}", slidepos = 0, c_edge = 0x00ff0000, parent = "tab1",
            map_ctrl =
            {
                {
                    type = utils_list.TYPE_TEXT, x = 20, y = 18, w = 200, h = 30, c = 0xffffffff,
                    content_h = 18, content_algin = utils_list.TEXT_ALIGN_LEFT, content_mode = utils_list.TEXT_MODE_DOT,
                },
                {
                    type = utils_list.TYPE_TEXT, x = 20, y = 50, w = 200, h = 20, c = 0xffffffff,
                    content_h = 15, content_algin = utils_list.TEXT_ALIGN_LEFT, content_mode = utils_list.TEXT_MODE_SROLL_CIRC,
                },
                {
                    type = utils_list.TYPE_IMG, x = 20, y = 85
                },
            },
        },
        action = {bind = {change = "list", up = "list_up"}}
    },

    {
        type = "shared",
        attr = {file = "shared_btn", func = "home_shared_moudle", 
                obj = {x = 772, name = "sos", content = "", text = "紧急求助", parent = "tab1"}},
    },
    -- sos_act.png sos_fail.png
    {
        type = "btn",
        position = {align = utils_align.IN_TOP_MID, aligny = 120 },
        attr = {res_rel = "{{sos_status_img}}", parent = "sos"},
        action = {bind = {up = "sos_action"}},
    },
    {
        type = "img",
        position = {align = utils_align.IN_TOP_MID, aligny = 120 },
        attr = {res = "{{sos_reciprocal}}", parent = "sos", hidden = "{{sos_reciprocal_hidden}}"},
        name = "sos_bg"
    },
    {
        type = "text",
        position = {align = utils_align.IN_BOTTOM_MID, aligny = -122},
        attr = {
            w = 156, h = 18, mode = utils_text.MODE_SROLL, align = utils_text.ALIGN_CENTER, parent = "sos", hidden = "{{sos_hint}}",
            c = 0xffffffff, content = "{{sos_hint_txt}}", }
    },

    {
        type = "shared",
        attr = {file = "shared_btn", func = "ctrl_btn", 
                obj = {x = 54, y = 314, parent = "sos", name = "sos_cancel", 
                        rel = "home/security_act.png", act_up = "sos_cancel", hidden = "{{sos_reciprocal_hidden}}",
                        content = "取消报警"}},
    },

    -- {
    --     type = "img",
    --     position = {x = 520, y = 12},
    --     attr = {res = "home/moudle_bar.png", w = 486, h = 464, parent = "tab1"},
    --     name = "user_center"
    -- },
    -- {
    --     type = "img",
    --     position = {align = utils_align.IN_TOP_MID, aligny = 60},
    --     attr = {res = "home/line.png", parent = "user_center"}
    -- },
    -- {
    --     type = "text",
    --     position = {align = utils_align.IN_TOP_MID, aligny = 16},
    --     attr ={ w = 240, h = 22, align = utils_text.ALIGN_CENTER, mode = utils_text.MODE_CROP,
    --             c = 0xffffffff, content = "用户中心", parent = "user_center"}
    -- },
    -- {
    --     type = "img",
    --     position = {align = utils_align.IN_BOTTOM_MID, aligny = -60},
    --     attr = {res = "home/line.png", parent = "user_center"}
    -- },
    -- {
    --     type = "blank",
    --     position = {align = utils_align.IN_BOTTOM_MID},
    --     attr = {w = 237, h = 60, c = 0x00000000, parent = "user_center"},
    --     action = {bind = {up = function() print("user_center") end}}
    -- },
    -- {
    --     type = "text",
    --     position = {align = utils_align.IN_BOTTOM_MID, aligny = -20},
    --     attr ={ w = 240, h = 18, align = utils_text.ALIGN_CENTER, mode = utils_text.MODE_CROP,
    --             c = 0xffffffff, content = "更多 >", parent = "user_center"}
    -- },
}

return view