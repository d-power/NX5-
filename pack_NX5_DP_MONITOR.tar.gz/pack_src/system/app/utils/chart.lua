return {
    SKIP_LAST = 0,
    DRAW_LAST = 1,
    INVERSE = 2,

    MODE_NONE = 0,
    MODE_LINE = 1,
    MODE_COLUMN = 2,

    DIV_NONE = 0,
    DIV_HOR = 1,
    DIV_VER = 2,
    DIV_ALL = 3,
}