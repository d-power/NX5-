#!/bin/sh

start() {
	printf "Starting hostapd: "      
	/system/bin/hostapd -B /system/misc/wifi/hostapd.conf
	udhcpd /system/misc/wifi/udhcpd.conf
	ifconfig wlan0 192.168.10.1 netmask 255.255.255.0
}

stop() {
	printf "Stopping hostapd: "
	killall -9 udhcpd
	killall hostapd
}

case "$1" in
    start)
	start
	;;
    stop)
	stop
	;;
    restart|reload)
	stop
	start
	;;
  *)
	echo "Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $?
