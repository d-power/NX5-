#!/bin/sh

if [ ! -d "/system/app" ]; then
	echo "The program does not exist"
	if [ -d "/system/app_bak" ]; then
		echo "Restore procedure"
		mv /system/app_bak /system/app
	fi
else
	echo "run app start"
fi

export LUA_PATH="/system/app/?.lua;;"
export LD_LIBRARY_PATH=/system/usr/lib:/system/app/clib:$LD_LIBRARY_PATH

/system/app/lua /system/app/main.lua &

