﻿2021_12_31
    更新了asix.ko,mac通过efuse数据生成，如果efuse全是0,使用随机数生成
    更新了gt911.ko,使用DP_GT911_NOCFG_ONCELL分支编译，gt911电容屏打开GTP_ESD_PROTECT

2021_12_29
    更新了zImage,每次i2c传输完成或者timeout都关闭中断。否则静电测试时复位i2c会产生未知的i2c中断

2021_12_23
    更新了vou.ko,loadkol.sh,静电测试视频卡住了，复位vou恢复

2021_12_21
    更新了vdu.ko,支持解码B帧的解码驱动

2021_12_20
    更新了pack_src/system/ko/xradio_core.ko，mac通过efuse数据计算得到

2021_12_09
    增加dp_gt911_oncell.ko驱动，DP_GT911_NOCFG_ONCELL分支编译。兼容GT911和oncell电容屏驱动

2021_11_22
    增加819驱动，xradio_mac.ko xradio_core.ko,xradio_wlan.ko,boot_xr819.bin fw_xr819.bin sdd_xr819.bin
    修改loadkol.sh,加载819驱动
 
2021_11_20
    更新了uboot,zImage,dtb,pack_spinand.sh,Sinit,split_spl_uboot_for_ota支持ota升级

2021_09_26
     更新了uboot,zImage,增加MT29F1G01ABAFDWB spinand的支持，通过串口烧录uboot时先擦除整个spinand

2021_09_10
     更新了uboot,zImage,增加DS35Q1GA spinand的支持

2021_09_08
      更新了uboot,zImage,loadkol.sh,增加HYF1GQ4UDACAE HYF2GQ4UAACAE  TC58CVG1S3HxAIx TC58CVG1S3HRAIJ spinand的支持

2021_09_06
       更新了uboot,兼容不同批次DDR
       更新了dtb,打开stereo配置
       增加stereo.ko立体声驱动
       增加sdio_wifi.sh,修改loakkol.sh,启动时设置sdio1的驱动能力，uboot中去掉了，否则配置太大配覆盖了

2021_08_04
	更新了uboot,wifi_rst gpio10_2 bt_rst gpio3_3拉低
	更新了dtb,disable stereo,修改sdmmc1配置
        更新了zImage,修改了内核配置，xr829编译成模块
	增加xr829驱动和固件

2021_08_02
    	增加xr829 wifi要下载的固件文件

2021_7_31
	更新了uboot,dtb,zImage,使用V0_9_0分支，NX5_DP_MONITOR配置编译
	更新了fyfb.ko，驱动加载时可以指定分辨率
	更新了gt911.ko，使用master分支编译，不用写配置
	更新了lcm.ko DP_RGB_MIPI分支 mipiek79007 配置编译mipi 1024x600 lcd驱动
	更新了loadkol.sh增加ax88772b网络驱动加载asix.ko,删除不需要的驱动
	增加asix.ko 88772b驱动 

2021_06_17
  更新了uboot,使用V0_9_0分支编译
  更新了dtb,修改了spi配置,compatible改成spi,dev
  更新了zImage,使用V0_9_0分支编译
  更新了spidev.ko，compatible改成了spi,dev

2021_06_04
  更新了uboot,增加PWM4的配置，和NX1S DDR修改同步，增大PLL延时
  更新了dtb,增加人感em33918驱动配置
  更新了zImage,MAC使用efuse55~59 efuse61
  增加em30918.ko em33918驱动

2021_04_25
 更新了zImage,spi ok。解决打印丢失问题

2021_04_23
 更新了zImage,增加spidev.ko，loadkol.sh。将spidev编译成驱动加载,加载时可以指定最大bufsiz

2021_04_21
 更新了uboot,dtb,zImage.增加spi通信接口给应用程序调用

2021_04_12
 更新了uboot,dtb,kernel,Sinit,增加 pack_spinand.sh mkyaffs2image spinand的打包

2021_04_02
  更新了fyfb.ko,增加了锁，应用程序滑动需要用到。

2021_04_02
  更新了dtb,修改了触摸屏的配置，原来的坐标反了。

2021_04_02
  更新了 pack.sh merge_package g加打包成image.dd
  更新了uboot,dtb,logo,内核，lcm.ko vou.ko lcd显示OK gt911.ko 触摸屏驱动ok        
2021_03_27
  更新了uboot,sdio1引脚上拉ok,注释脚本里面设置上拉

2021_03_26
  更新了dpchip-v2p-chip-nx5.dtb，修改了watchdog的配置，增加reset-on-timeout
  更新了pack_src/rootfs/etc/init.d/Sinit，解决wifi ap模式连不上问题

2021_03_25
  更新了 pack_src/kernel/zImage，修改了内核配置，rtl8188 makefile kconfig,配置CONFIG_WIRELESS_EXT
  更新了 8188eu.ko，打开monitor配置
   更新了内核重新配置重新编译驱动hgic_sdio.ko pack_src/system/ko/hgicf.ko

2021_03_24
   更新了 pack_src/kernel/zImage，修改内核配置，增加网络相关的一些配置
   修改pack_src/rootfs/etc/profile，export PATH
   更新了pack_src/system/ko/8188eu.ko，修改了网络配置，重新编译wifi驱动
   增加iwconfig，将iwgetid,iwlist,iwpriv,iwspy链接文件也放到system/bin目录

2021_03_17
  更新了zImage,将HZ从100改成1000,修改了fyfb.ko，驱动加载时将framebuf清零。修改了vou.ko解决有时开机显示异常问题

2021_03_10
  更新了pack.sh,jffs2分区指定0x200000

2021_03_10
  更新了 pack_src/kernel/zImage，原来的spinor写有问题。
  增加pack_src/system/usr/lib,wifi ap模式需要的库

 
2021_02_19
  更新了hgic_sdio.ko hgicf.ko hgicf.bin 非标900M wifi驱动和固件

2021_01_29
  更新了lcm.ko，增加获取lcd分辨率和帧率接口给vou驱动调用
  更新了vou.ko,在HAL_VO_GraphicUpdate函数中增加TSK_VO_Wakeup(HAL_VO_DEVICE_DHD0)，刷新率60帧

2021_01_04
  更新了dtb,调整了分区，system分区改成8M ,data分区改成2M

2021_01_04
  更新了uboot,dtb,kernel,loadkol.sh uboot中设置sdc1 IO口上拉4.7k，loadkol.sh中注释掉sdc1 io口上拉寄存器的设置，内核增加utf8和中文的支持，dtb打开sdmmc0,sd卡挂载ok

2021_01_02
  更新了hgicf.bin 非标wifi固件更稳定

2021_01_02
  更新了dpchip-v2p-chip-nx5.dtb 增加非标wifi的配置
  修改了zImage sdio驱动
   更新了fyfb.ko，去掉打印
   加载wifi驱动loadkol.sh hgic_sdio.ko hgicf.ko

2020_12_31
  更新了uboot，dtb,显示OK,usb wifi OK

2020_12_30
  更新了dtb,uboot，增加开机logo分区，从logo分区读取开机logo解码显示

2020_12_19
 更新了dtb,内核，增加dpchip_saradc.ko adc检测电压驱动dpchip_saradc.ko at /sys/bus/iio/devices/iio:device0/in_voltage0_raw 获取电压值

2020_12_19
  更新了uboot,使用分辨率可以配置的mc_boot_logo.c编译
   更新了dtb，内核，增加adc按键驱动，av_test_key，测试adc按键ok

2020_12_10
  更新了uboot,内核，en25q128as 不用SEC_4K，block统一用64K

2020_12_10
  更新了uboot配置uart3
  更新了zImage,修改了jffs2的配置
  更新了dtb,修改了uart3的配置
  更新了fyfb.ko，用libgcc里的
  更新了lcm.ko,改成rgb lcd 驱动
  更新了loadkol.sh，修改了vram0_size
  更新了vou.ko，前一个版本不支持RGB接口LCD
  data下面增加测试网络和解码的驱动

2020_12_09
  更新了uboot,开机logo可以显示了。

2020_12_04
  更新了dtb,增加了分区，增加system分区，增加安防驱动

2020_12_04
  更新了内核，dtb,增加了wifi驱动，整理了启动脚本

2020_12_01
  更新了zImage,将audio驱动编译到内核，disp_audio 测试显示录放音

2020_11_30
  2020_11_28更新了所有的ko,libmpi.a,lcm.ko poweroff时reset设置为0，重新启动时重新初始化lcd，但是重新初始化lcd,lcd没有显示，还需要继续查原因，不影响真正的使用。
  
 报警按键：GPIO10_6
 门铃：GPIO9_2
 防拆：GPIO9_3
报警检测：GPIO9_4
指示灯1：GPIO9_5
指示灯2: GPIO9_6
人感：GPIO9_7
功放使能：GPIO0_3

慧瑞通的mipi接口lcd打包,使用2020_11_26的ko,旧的测试程序测试lcd，电容屏ok
