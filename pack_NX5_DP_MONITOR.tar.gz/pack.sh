#!/bin/sh
#
# Start the network....
#

ROOT_DIR=$PWD
TOOLS_DIR=${ROOT_DIR}/pctools
OUT_DIR=${ROOT_DIR}/out
export PATH=${TOOLS_DIR}/linux:$PATH
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${TOOLS_DIR}/libs/jffs

if [ -d ${OUT_DIR} ]; then
	rm -rf ${OUT_DIR}
fi

mkdir  ${OUT_DIR} 

cp ./pack_src/logo/logo.jpg out/ -a
cd out
#add width height jpgsize in jpgfile
convert_jpg 480 480 
mv logo_tmp.jpg logo.jpg
cd ../
cp ./pack_src/boot/* out/ -a
cp ./pack_src/kernel/zImage out/ -a
cp ./pack_src/dtb/dpchip-v2p-chip-nx5.dtb out/ -a
mksquashfs ./pack_src/rootfs out/rootfs_squashfs.img -noappend -comp xz
mksquashfs ./pack_src/system out/system_squashfs.img -noappend -comp xz
mkfs.jffs2 -d ./pack_src/data  -o out/jffs2.img  -s 0x100 -e 0x10000 -p 0x200000

#merge image.dd
cp out/u-boot-with-spl.img out/uboot
cp out/logo.jpg out/logo
cp out/dpchip-v2p-chip-nx5.dtb out/dtb
cp out/zImage out/kernel
cp out/rootfs_squashfs.img out/rootfs
cp out/system_squashfs.img out/system
cp out/jffs2.img out/data
cd out
merge_package image.dd uboot logo dtb kernel rootfs system data
rm uboot
rm logo
rm dtb
rm kernel
rm rootfs
rm system
rm data

cd ../

